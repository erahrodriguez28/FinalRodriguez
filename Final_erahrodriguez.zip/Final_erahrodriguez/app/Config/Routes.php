<?php

namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

// Load the system's routing file first, so that the app and ENVIRONMENT
// can override as needed.
if (is_file(SYSTEMPATH . 'Config/Routes.php')) {
    require SYSTEMPATH . 'Config/Routes.php';
}

/*
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Auth');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(false);

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// ==================== AUTHENTICATION ROUTES ====================

// Landing page (no authentication filter - everyone can access)
$routes->get('/', 'Auth::index');

// User login routes (no authentication required - unauthenticated users should access)
$routes->get('/login', 'Auth::userLogin');
$routes->post('/login', 'Auth::userLogin');

// Admin login routes (no authentication required - unauthenticated users should access)
$routes->get('/admin/login', 'Auth::adminLogin');
$routes->post('/admin/login', 'Auth::adminLogin');

// Registration routes (no authentication required)
$routes->get('/register', 'Auth::register');
$routes->post('/register', 'Auth::register');

// Logout (accessible to both authenticated users and admins)
$routes->get('/logout', 'Auth::logout', ['filter' => 'authenticate']);

// ==================== AUTH MANAGEMENT ROUTES ====================

// Auth routes group (requires authentication)
$routes->group('Auth', ['filter' => 'authenticate'], function($routes) {
    // Update user profile
    $routes->get('update_user', 'Auth::update_user');
    $routes->post('update_user', 'Auth::update_user');
    
    // IP Blocking routes (admin check done in controller)
    $routes->get('blockIP', 'Auth::blockIP');
    $routes->post('blockIP', 'Auth::blockIP');
    $routes->get('manageBlockedIPs', 'Auth::manageBlockedIPs');
    $routes->get('unblockIP/(:num)', 'Auth::unblockIP/$1');
    $routes->get('userIPs', 'Auth::getUserIPs');
    $routes->post('userIPs', 'Auth::getUserIPs');
    $routes->get('userIPs/(:num)', 'Auth::getUserIPs/$1');
});

// ==================== MAIN USER DASHBOARD ROUTES ====================

// Main routes group for regular users
$routes->group('Main', ['filter' => 'authenticate'], function($routes) {
    $routes->get('', 'Main::index');
    $routes->get('(:segment)', 'Main::$1');
    $routes->get('(:segment)/(:any)', 'Main::$1/$2');
    $routes->post('user_edit/(:num)', 'Main::user_edit/$1');
});

// ==================== ADMIN ROUTES ====================

// Admin routes group (requires authentication - admin check in controllers)
$routes->group('admin', ['filter' => 'authenticate'], function($routes) {
    // Admin Dashboard
    $routes->get('dashboard', 'Admin\Dashboard::index');
    
    // Pensioner management
    $routes->get('pensioners', 'Admin\Pensioners::index');
    $routes->get('pensioners/create', 'Admin\Pensioners::create');
    $routes->post('pensioners/store', 'Admin\Pensioners::store');
    $routes->get('pensioners/edit/(:num)', 'Admin\Pensioners::edit/$1');
    $routes->post('pensioners/update/(:num)', 'Admin\Pensioners::update/$1');
    $routes->get('pensioners/delete/(:num)', 'Admin\Pensioners::delete/$1');
    
    // Reports
    $routes->get('pensioners/report', 'Admin\Pensioners::report');
    $routes->post('pensioners/report', 'Admin\Pensioners::report');
    $routes->get('pensioners/detailed_report', 'Admin\Pensioners::detailed_report');
    $routes->get('pensioners/export_pdf', 'Admin\Pensioners::export_pdf');
    $routes->get('pensioners/export_excel', 'Admin\Pensioners::export_excel');
    
    // User management (admin only)
    $routes->get('users', 'Admin\Users::index');
    $routes->get('users/create', 'Admin\Users::create');
    $routes->post('users/store', 'Admin\Users::store');
    $routes->get('users/edit/(:num)', 'Admin\Users::edit/$1');
    $routes->post('users/update/(:num)', 'Admin\Users::update/$1');
    $routes->get('users/delete/(:num)', 'Admin\Users::delete/$1');
    $routes->get('users/activate/(:num)', 'Admin\Users::activate/$1');
    $routes->get('users/deactivate/(:num)', 'Admin\Users::deactivate/$1');
    
    // Admin Help
    $routes->get('help', 'Admin\Help::index');
    $routes->get('help/index', 'Admin\Help::index');
    $routes->get('help/faq', 'Admin\Help::faq');
    $routes->get('help/documentation', 'Admin\Help::documentation');
    $routes->get('help/tutorials', 'Admin\Help::tutorials');
    $routes->match(['get', 'post'], 'help/contact', 'Admin\Help::contact');
    
    // Notifications (admin view)
    $routes->get('notifications', 'Admin\Notifications::index');
    $routes->get('notifications/getNotifications', 'Admin\Notifications::getNotifications');
    $routes->post('notifications/markAsRead/(:num)', 'Admin\Notifications::markAsRead/$1');
    $routes->post('notifications/markAllAsRead', 'Admin\Notifications::markAllAsRead');
});

// ==================== HELP ROUTES ====================

// Main Help routes (for regular users)
$routes->group('help', ['filter' => 'authenticate'], function($routes) {
    $routes->get('', 'HelpController::index');
    $routes->get('index', 'HelpController::index');
    $routes->get('faq', 'HelpController::faq');
    $routes->get('documentation', 'HelpController::documentation');
    $routes->get('tutorials', 'HelpController::tutorials');
    $routes->match(['get', 'post'], 'contact', 'HelpController::contact');
});

// Help routes under Main group
$routes->get('Main/help', 'HelpController::index', ['filter' => 'authenticate']);
$routes->get('Main/help/index', 'HelpController::index', ['filter' => 'authenticate']);

// ==================== NOTIFICATION ROUTES ====================

// Notification routes (for regular users)
$routes->get('notifications', 'Notifications::index', ['filter' => 'authenticate']);
$routes->get('notifications/getNotifications', 'Notifications::getNotifications', ['filter' => 'authenticate']);
$routes->post('notifications/markAsRead/(:num)', 'Notifications::markAsRead/$1', ['filter' => 'authenticate']);
$routes->post('notifications/markAllAsRead', 'Notifications::markAllAsRead', ['filter' => 'authenticate']);

// ==================== USER VIEW-ONLY ROUTES ====================

// User view-only pensioner data
$routes->get('user/pensioners/view', 'Admin\Pensioners::view', ['filter' => 'authenticate']);
// To this:
$routes->get('user/pensioners/edit/(:num)', 'Admin\Pensioners::user_edit/$1', ['filter' => 'authenticate']);
$routes->post('user/pensioners/update/(:num)', 'Admin\Pensioners::update/$1', ['filter' => 'authenticate']);

// ==================== SYSTEM ROUTES ====================

// Always accessible routes (even during maintenance)
$routes->get('/toggle_mode', 'Main::toggleMaintenanceMode');
$routes->get('/maintenance_warning', 'Pages::maintenance_warning');

// ==================== REDIRECTS FOR LEGACY URLS ====================

// Redirect old Auth URLs
$routes->get('/Auth', function() {
    return redirect()->to('/');
});

$routes->get('/Auth/index', function() {
    return redirect()->to('/');
});

$routes->get('/Auth/userLogin', function() {
    return redirect()->to('/login');
});

$routes->get('/Auth/adminLogin', function() {
    return redirect()->to('/admin/login');
});

// Redirect old help URLs
$routes->get('admin/pensioners/help/(:any)', function() {
    return redirect()->to('/admin/help');
});

$routes->get('user/pensioners/help/index', function() {
    return redirect()->to('/help');
});

// ==================== ERROR HANDLING ====================

// 404 Page
$routes->set404Override(function() {
    return view('errors/html/error_404');
});

/*
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 */
if (is_file(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}