<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\PensionerModel;
use App\Models\Auth;
use App\Models\NotificationModel;

class Pensioners extends BaseController
{
    protected $pensionerModel;
    protected $notificationModel;
    protected $isAdmin;

    public function __construct()
    {
        $this->pensionerModel = new PensionerModel();
        $this->notificationModel = new NotificationModel();
        $this->isAdmin = session()->login_type == 1;
    }

    // ADMIN ONLY
    // ADMIN ONLY - sees all pensioners
    public function index()
    {
        if (!$this->isAdmin) {
            return redirect()->to('/Main')->with('error', 'Access denied. Admin only.');
        }

        $data = [
            'page_title' => 'All Pensioners',
            'pensioners' => $this->pensionerModel->getAllPensioners(),
            'isAdmin' => true,
            'stats' => $this->pensionerModel->getUserDashboardStats(null, true)
        ];
        return view('admin/pensioners/index', $data);
    }

    public function edit($id)
    {
        if (!$this->isAdmin) {
            return redirect()->to('/Main')->with('error', 'Access denied. Admin only.');
        }
    
        $pensioner = $this->pensionerModel->find($id);
        
        if (!$pensioner) {
            return redirect()->to('/admin/pensioners')->with('error', 'Pensioner not found.');
        }
    
        $data = [
            'page_title' => 'Edit Pensioner',
            'pensioner'  => $pensioner,
            'isAdmin' => true,
            'form_action' => site_url('/admin/pensioners/update/'.$id), // Add this
            'cancel_url' => site_url('/admin/pensioners') // Add this
        ];
        return view('admin/pensioners/edit', $data); // Note: This uses admin edit view
    }

    // USER ONLY - sees only their pensioners
    public function view()
    {
        if (session()->login_type != 2) {
            return redirect()->to('/Main')->with('error', 'Access denied. Users only.');
        }

        $userId = session()->login_id;
        
        $data = [
            'page_title' => 'My Pensioners',
            'pensioners' => $this->pensionerModel->getUserPensioners($userId),
            'isAdmin' => false,
            'stats' => $this->pensionerModel->getUserDashboardStats($userId, false)
        ];

        return view('user/pensioners/view', $data);
    }

    // User can edit their own pensioner
    public function user_edit($id)
    {
        if (session()->login_type != 2) {
            return redirect()->to('/Main')->with('error', 'Access denied.');
        }
    
        $userId = session()->login_id;
        $pensioner = $this->pensionerModel->getPensioner($id, $userId, false);
        
        if (!$pensioner) {
            return redirect()->to('/user/pensioners/view')->with('error', 'Pensioner not found or you do not have permission to edit.');
        }
    
        $data = [
            'page_title' => 'Edit My Pensioner',
            'pensioner'  => $pensioner,
            'isAdmin' => false,
            'form_action' => site_url('/user/pensioners/update/'.$id), // Add this
            'cancel_url' => site_url('/user/pensioners/view') // Add this
        ];
        return view('user/pensioners/edit', $data);
    }

    // ADMIN + NORMAL USER
    public function create()
    {
        if (!in_array(session()->login_type, [1, 2])) {
            return redirect()->to('/')->with('error', 'Access denied');
        }

        $data = [
            'page_title' => 'Create Pensioner',
            'isAdmin' => $this->isAdmin
        ];
        return view('pensioners/create', $data); // Shared view
    }

    // ADMIN + NORMAL USER
    public function store()
    {
        if (!in_array(session()->login_type, [1, 2])) {
            if ($this->request->isAJAX()) {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'Access denied'
                ]);
            }
            return redirect()->to('/')->with('error', 'Access denied');
        }

        try {
            $userId = session()->login_id;
            $isAdmin = session()->login_type == 1;
            
            $data = [
                'full_name'          => $this->request->getPost('full_name'),
                'date_of_birth'      => $this->request->getPost('date_of_birth'),
                'gender'             => $this->request->getPost('gender'),
                'marital_status'     => $this->request->getPost('marital_status'),
                'id_number'          => $this->request->getPost('id_number'),
                'address'            => $this->request->getPost('address'),
                'contact_number'     => $this->request->getPost('contact_number'),
                'email'              => $this->request->getPost('email'),
                'bank_account'       => $this->request->getPost('bank_account'),
                'bank_name'          => $this->request->getPost('bank_name'),
                'next_of_kin'        => $this->request->getPost('next_of_kin'),
                'next_of_kin_contact'=> $this->request->getPost('next_of_kin_contact'),
                'pension_type'       => $this->request->getPost('pension_type') ?? 'retirement',
                'pension_amount'     => $this->request->getPost('pension_amount'),
                'pension_start_date' => $this->request->getPost('pension_start_date'),
                'status'             => $this->request->getPost('status') ?? 'active',
                'notes'              => $this->request->getPost('notes'),
                'medical_conditions' => $this->request->getPost('medical_conditions'),
                'created_by'         => $userId,
                'created_at'         => date('Y-m-d H:i:s')
            ];
            
            // Only admin can set created_by to someone else
            if ($isAdmin && $this->request->getPost('assigned_to')) {
                $data['created_by'] = $this->request->getPost('assigned_to');
            }
            
            $this->pensionerModel->save($data);
            $pensionerId = $this->pensionerModel->getInsertID();
            
            // Create notification
            $this->notificationModel->createNotification([
                'user_id'    => $userId,
                'title'      => 'New Pensioner Registered',
                'message'    => "Pensioner {$data['full_name']} has been registered",
                'type'       => 'success',
                'for_admin'  => $isAdmin ? 0 : 1, // Notify admin if user created it
                'for_user'   => 1,
                'action_url' => $isAdmin ? 
                    base_url('/admin/pensioners/edit/' . $pensionerId) : 
                    base_url('/user/pensioners/edit/' . $pensionerId)
            ]);
            
            if ($this->request->isAJAX()) {
                return $this->response->setJSON([
                    'success' => true,
                    'message' => 'Pensioner registered successfully',
                    'data' => ['id' => $pensionerId]
                ]);
            }
            
            // Redirect based on user type
            if ($isAdmin) {
                return redirect()->to('/admin/pensioners')->with('success', 'Pensioner added successfully.');
            } else {
                return redirect()->to('/user/pensioners/view')->with('success', 'Pensioner added successfully.');
            }
            
        } catch (\Exception $e) {
            if ($this->request->isAJAX()) {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'Error: ' . $e->getMessage()
                ]);
            }
            
            return redirect()->back()->withInput()->with('error', 'Error: ' . $e->getMessage());
        }
    }

    // Update pensioner (with ownership check)
    public function update($id)
    {
        $userId = session()->login_id;
        $isAdmin = session()->login_type == 1;
        
        // Check ownership for non-admin users
        if (!$isAdmin && !$this->pensionerModel->isOwner($id, $userId)) {
            return redirect()->to('/user/pensioners/view')->with('error', 'You do not have permission to update this pensioner.');
        }
        
        $updateData = [
            'full_name'           => $this->request->getPost('full_name'),
            'date_of_birth'       => $this->request->getPost('date_of_birth'),
            'gender'              => $this->request->getPost('gender'),
            'marital_status'      => $this->request->getPost('marital_status'),
            'id_number'           => $this->request->getPost('id_number'),
            'address'             => $this->request->getPost('address'),
            'contact_number'      => $this->request->getPost('contact_number'),
            'email'               => $this->request->getPost('email'),
            'bank_account'        => $this->request->getPost('bank_account'),
            'bank_name'           => $this->request->getPost('bank_name'),
            'next_of_kin'         => $this->request->getPost('next_of_kin'),
            'next_of_kin_contact' => $this->request->getPost('next_of_kin_contact'),
            'pension_type'        => $this->request->getPost('pension_type') ?? 'retirement',
            'pension_amount'      => $this->request->getPost('pension_amount'),
            'pension_start_date'  => $this->request->getPost('pension_start_date'),
            'status'              => $this->request->getPost('status') ?? 'active',
            'notes'               => $this->request->getPost('notes'),
            'medical_conditions'  => $this->request->getPost('medical_conditions'),
            'updated_at'          => date('Y-m-d H:i:s')
        ];
        
        // Only admin can change ownership
        if ($isAdmin && $this->request->getPost('created_by')) {
            $updateData['created_by'] = $this->request->getPost('created_by');
        }
        
        $this->pensionerModel->update($id, $updateData);
        
        // Create update notification
        $this->notificationModel->createNotification([
            'user_id'    => $userId,
            'title'      => 'Pensioner Updated',
            'message'    => "Pensioner {$updateData['full_name']} has been updated",
            'type'       => 'info',
            'for_admin'  => $isAdmin ? 0 : 1,
            'for_user'   => $isAdmin ? 0 : 1,
            'action_url' => $isAdmin ? 
                base_url('/admin/pensioners/edit/' . $id) : 
                base_url('/user/pensioners/edit/' . $id)
        ]);

        // Redirect based on user type
        if ($isAdmin) {
            return redirect()->to('/admin/pensioners')->with('success', 'Pensioner updated successfully.');
        } else {
            return redirect()->to('/user/pensioners/view')->with('success', 'Pensioner updated successfully.');
        }
    }

    // Delete pensioner (with ownership check)
    public function delete($id)
    {
        $userId = session()->login_id;
        $isAdmin = session()->login_type == 1;
        
        // Check ownership for non-admin users
        if (!$isAdmin && !$this->pensionerModel->isOwner($id, $userId)) {
            return redirect()->to('/user/pensioners/view')->with('error', 'You do not have permission to delete this pensioner.');
        }
        
        $pensioner = $this->pensionerModel->find($id);
        
        if (!$pensioner) {
            return redirect()->back()->with('error', 'Pensioner not found.');
        }
        
        $this->pensionerModel->delete($id);
        
        // Create delete notification
        $this->notificationModel->createNotification([
            'user_id'    => $userId,
            'title'      => 'Pensioner Deleted',
            'message'    => "Pensioner {$pensioner['full_name']} has been deleted",
            'type'       => 'warning',
            'for_admin'  => $isAdmin ? 0 : 1,
            'for_user'   => $isAdmin ? 0 : 1
        ]);
        
        // Redirect based on user type
        if ($isAdmin) {
            return redirect()->to('/admin/pensioners')->with('success', 'Pensioner deleted successfully.');
        } else {
            return redirect()->to('/user/pensioners/view')->with('success', 'Pensioner deleted successfully.');
        }
    }
    
    // REPORT AND ANALYTICS
    public function report()
    {
        if (session()->login_type != 1) {
            return redirect()->to('/')->with('error', 'Access denied');
        }
        
        // Add notification
        $this->notificationModel->notifyReportGenerated(
            'PDF Report',
            session()->login_id
        );

        $year = $this->request->getGet('year') ?? date('Y');
        
        $data = [
            'page_title' => 'Reports & Analytics',
            'pension_type_stats' => $this->pensionerModel->getPensionTypeStats(),
            'age_group_stats' => $this->pensionerModel->getAgeGroupStats(),
            'registration_trends' => $this->pensionerModel->getRegistrationTrends($year),
            'location_stats' => $this->pensionerModel->getLocationStats(),
            'yearly_summary' => $this->pensionerModel->getYearlySummary($year),
            'selected_year' => $year,
            'available_years' => $this->getAvailableYears(),
            'pensionerModel' => $this->pensionerModel
        ];
        
        return view('admin/pensioners/report', $data);
    }
    
    /**
     * Generate detailed report
     */
    public function detailed_report()
    {
        if (session()->login_type != 1) {
            return redirect()->to('/')->with('error', 'Access denied');
        }
        
        $filters = [
            'pension_type' => $this->request->getGet('pension_type'),
            'start_date' => $this->request->getGet('start_date'),
            'end_date' => $this->request->getGet('end_date'),
            'search' => $this->request->getGet('search')
        ];
        
        $data = [
            'page_title' => 'Detailed Report',
            'pensioners' => $this->pensionerModel->generateDetailedReport($filters),
            'filters' => $filters,
            'pension_types' => [
                '' => 'All Types',
                'retirement' => 'Retirement',
                'disability' => 'Disability',
                'survivor' => 'Survivor',
                'other' => 'Other'
            ]
        ];
        
        return view('admin/pensioners/detailed_report', $data);
    }
    
    /**
     * Export report to PDF
     */
    public function export_pdf()
    {
        if (session()->login_type != 1) {
            return redirect()->to('/')->with('error', 'Access denied');
        }
        
        $filters = [
            'pension_type' => $this->request->getGet('pension_type'),
            'start_date' => $this->request->getGet('start_date'),
            'end_date' => $this->request->getGet('end_date')
        ];
        
        $data = [
            'report_title' => 'Pensioners Report',
            'pensioners' => $this->pensionerModel->generateDetailedReport($filters),
            'filters' => $filters,
            'generated_date' => date('Y-m-d H:i:s')
        ];
        
        return view('admin/pensioners/export_pdf', $data);
    }
    
    /**
     * Export report to Excel
     */
    public function export_excel()
    {
        if (session()->login_type != 1) {
            return redirect()->to('/')->with('error', 'Access denied');
        }
        
        $filters = [
            'pension_type' => $this->request->getGet('pension_type'),
            'start_date' => $this->request->getGet('start_date'),
            'end_date' => $this->request->getGet('end_date')
        ];
        
        $pensioners = $this->pensionerModel->generateDetailedReport($filters);
        
        $filename = "pensioners_report_" . date('Y-m-d') . ".csv";
        
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        
        $output = fopen('php://output', 'w');
        
        // Add headers
        fputcsv($output, ['ID', 'Full Name', 'Date of Birth', 'Address', 'Contact Number', 'Email', 'Pension Type', 'Created Date']);
        
        // Add data
        foreach ($pensioners as $pensioner) {
            fputcsv($output, [
                $pensioner['pensioner_id'],
                $pensioner['full_name'],
                $pensioner['date_of_birth'],
                $pensioner['address'],
                $pensioner['contact_number'],
                $pensioner['email'],
                $this->pensionerModel->getPensionTypeLabel($pensioner['pension_type']),
                $pensioner['created_at']
            ]);
        }
        
        // Add notification
        $this->notificationModel->notifyReportGenerated(
            'PDF Report',
            session()->login_id
        );
        
        fclose($output);
        exit;
    }
    
    /**
     * Get available years for filtering
     */
    private function getAvailableYears()
    {
        $query = $this->pensionerModel->query("
            SELECT DISTINCT YEAR(created_at) as year 
            FROM pensioners 
            WHERE created_at IS NOT NULL 
            ORDER BY year DESC
        ");
        
        $years = [];
        foreach ($query->getResultArray() as $row) {
            $years[] = $row['year'];
        }
        
        // Add current year if not present
        $currentYear = date('Y');
        if (!in_array($currentYear, $years)) {
            array_unshift($years, $currentYear);
        }
        
        return $years;
    }
}