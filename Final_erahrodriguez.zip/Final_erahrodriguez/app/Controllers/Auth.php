<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\Auth as Auth_Model;
use App\Models\NotificationModel;
use App\Models\BlockedIPModel;

class Auth extends BaseController
{
    protected $request;
    protected $auth_model;
    protected $notification_model;
    protected $blocked_ip_model;
    protected $data;

    public function __construct()
    {
        $this->request = \Config\Services::request();
        $this->auth_model = new Auth_Model;
        $this->notification_model = new NotificationModel();
        $this->blocked_ip_model = new \App\Models\BlockedIPModel();
        $this->data = []; // Initialize data array
    }

    /**
     * Landing Page
     */
    public function index()
    {
        $session = session();
        
        // If user is already logged in, redirect to appropriate dashboard
        if ($session->get('login_id')) {
            if ($session->get('login_type') == 1) {
                return redirect()->to('/Main');
            } else {
                return redirect()->to('/Main');
            }
        }
        
        // If not logged in, show landing page
        return view('auth/landing');
    }

    /**
     * User Login Page
     */
    public function userLogin()
    {   
        $data = [];
        $data['page_title'] = "User Login";
        $data['data'] = $this->request;
        $session = session();

        // Check if IP is blocked
        $ip_address = $this->request->getIPAddress();
        $blocked = $this->blocked_ip_model->isBlocked($ip_address);
        
        if ($blocked) {
            $message = "Your IP address ($ip_address) has been blocked";
            if (!$blocked['is_permanent'] && $blocked['block_until']) {
                $message .= " until " . date('F j, Y, g:i a', strtotime($blocked['block_until']));
            }
            if ($blocked['reason']) {
                $message .= ". Reason: " . $blocked['reason'];
            }
            $session->setFlashdata('error', $message);
            return view('auth/user_login', $data);
        }

        if ($this->request->getMethod() == 'post') {
            $user = $this->auth_model->where('email', $this->request->getPost('email'))->first();

            if ($user) {
                $verify_password = password_verify($this->request->getPost('password'), $user['password']);

                if ($verify_password) {
                    if ($user['status'] == 0) {
                        $session->setFlashdata('error', 'Your Account is not yet validated.');
                    } elseif ($user['status'] == 2) {
                        $session->setFlashdata('error', 'Your Account has been banned.');
                    } elseif ($user['status'] == 1) {
                        // Check if user is not admin (type != 1)
                        if ($user['type'] == 1) {
                            $session->setFlashdata('error', 'Please use admin login portal for admin access.');
                        } else {
                            // Store user data in session
                            foreach ($user as $k => $v) {
                                $session->set('login_'.$k, $v);
                            }

                            // Record login details
                            $this->auth_model->update($user['id'], [
                                'last_login'  => date('Y-m-d H:i:s'),
                                'ip_address'  => $this->request->getIPAddress(),
                                'mac_address' => $this->request->getUserAgent()
                            ]);

                            // Create login notification for admin
                            $this->notification_model->notifyLogin(
                                $user['id'],
                                $user['name'],
                                $this->request->getIPAddress()
                            );

                            return redirect()->to('/Main');
                        }
                    } else {
                        $session->setFlashdata('error', 'User Account Status invalid.');
                    }
                } else {
                    $session->setFlashdata('error', 'Incorrect Password');
                }
            } else {
                $session->setFlashdata('error', 'Incorrect Email or Password');
            }
        }

        $data['session'] = $session;
        return view('auth/user_login', $data);
    }

    /**
     * Admin Login Page
     */
    public function adminLogin()
    {   
        $data = [];
        $data['page_title'] = "Admin Login";
        $data['data'] = $this->request;
        $session = session();

        // Check if IP is blocked
        $ip_address = $this->request->getIPAddress();
        $blocked = $this->blocked_ip_model->isBlocked($ip_address);
        
        if ($blocked) {
            $message = "Your IP address ($ip_address) has been blocked";
            if (!$blocked['is_permanent'] && $blocked['block_until']) {
                $message .= " until " . date('F j, Y, g:i a', strtotime($blocked['block_until']));
            }
            if ($blocked['reason']) {
                $message .= ". Reason: " . $blocked['reason'];
            }
            $session->setFlashdata('error', $message);
            return view('auth/admin_login', $data);
        }

        if ($this->request->getMethod() == 'post') {
            $user = $this->auth_model->where('email', $this->request->getPost('email'))->first();

            if ($user) {
                $verify_password = password_verify($this->request->getPost('password'), $user['password']);

                if ($verify_password) {
                    if ($user['status'] == 0) {
                        $session->setFlashdata('error', 'Your Account is not yet validated.');
                    } elseif ($user['status'] == 2) {
                        $session->setFlashdata('error', 'Your Account has been banned.');
                    } elseif ($user['status'] == 1) {
                        // Check if user is admin (type == 1)
                        if ($user['type'] != 1) {
                            $session->setFlashdata('error', 'Access denied. Admin credentials required.');
                        } else {
                            // Store user data in session
                            foreach ($user as $k => $v) {
                                $session->set('login_'.$k, $v);
                            }

                            // Record login details
                            $this->auth_model->update($user['id'], [
                                'last_login'  => date('Y-m-d H:i:s'),
                                'ip_address'  => $this->request->getIPAddress(),
                                'mac_address' => $this->request->getUserAgent()
                            ]);

                            // Create login notification for admin
                            $this->notification_model->notifyLogin(
                                $user['id'],
                                $user['name'],
                                $this->request->getIPAddress()
                            );

                            return redirect()->to('/Main');
                        }
                    } else {
                        $session->setFlashdata('error', 'User Account Status invalid.');
                    }
                } else {
                    $session->setFlashdata('error', 'Incorrect Password');
                }
            } else {
                $session->setFlashdata('error', 'Incorrect Email or Password');
            }
        }

        $data['session'] = $session;
        return view('auth/admin_login', $data);
    }

    public function logout()
    {
        $session = session();
        $userId = $session->login_id;
        $userName = $session->login_name;

        // Save logout time
        $this->auth_model->update($userId, [
            'last_logout' => date('Y-m-d H:i:s')
        ]);

        // Create logout notification for admin
        $this->notification_model->notifyLogout($userId, $userName);

        $session->destroy();
        return redirect()->to('/Auth/index');
    }

    public function register()
    {
        $session = session();
        $data = [];
        $data['session'] = $session;
        $data['data'] = $this->request;
        $data['page_title'] = "Registration";

        if ($this->request->getMethod() == 'post') {

            $name = $this->request->getPost('name');
            $email = $this->request->getPost('email');
            $password = $this->request->getPost('password');
            $cpassword = $this->request->getPost('cpassword');

            $checkEmail = $this->auth_model->where('email', $email)->countAllResults();

            if ($checkEmail > 0) {
                $session->setFlashdata('error', 'Email is already taken.');
            } elseif ($password !== $cpassword) {
                $session->setFlashdata('error', 'Password do not match.');
            } else {

                $idata = [
                    'name'     => $name,
                    'email'    => $email,
                    'password' => password_hash($password, PASSWORD_DEFAULT),
                    'status'   => 0,
                    'type'     => 2
                ];

                $save = $this->auth_model->save($idata);

                if ($save) {
                    $userId = $this->auth_model->insertID();
                    
                    // Create registration notification
                    $this->notification_model->notifyNewRegistration($userId, $name, $email);
                    
                    $session->setFlashdata('success', 'Your Account has been registered successfully.');
                    return redirect()->to('/Auth');
                }
            }
        }

        return view('auth/register', $data);
    }

    public function update_user()
    {
        $session = session();

        if ($this->request->getMethod() == 'post') {

            extract($this->request->getPost());
            $verify_password = password_verify($current_password, $session->login_password);

            if ($password !== $cpassword) {
                $session->setFlashdata('error', "Password does not match.");
            } elseif (!$verify_password) {
                $session->setFlashdata('error', "Current Password is Incorrect.");
            } else {

                $udata = [];
                $udata['name'] = $name;
                $udata['email'] = $email;

                if (!empty($password)) {
                    $udata['password'] = password_hash($password, PASSWORD_DEFAULT);
                }

                $update = $this->auth_model->where('id', $session->login_id)->set($udata)->update();

                if ($update) {
                    $session->setFlashdata('success', "Your Account has been updated successfully.");

                    // Refresh session data
                    $user = $this->auth_model->where("id ='{$session->login_id}'")->first();
                    foreach ($user as $k => $v) {
                        $session->set('login_'.$k, $v);
                    }

                    return redirect()->to('update_user');
                } else {
                    $session->setFlashdata('error', "Your Account has failed to update.");
                }
            }
        }

        // Use $this->data instead of creating a new array
        $this->data['session'] = $session;
        $this->data['page_title'] = "Users";
        $this->data['user'] = $this->auth_model->where("id ='{$session->login_id}'")->first();

        return view('pages/users/update_account', $this->data);
    }

    /**
     * Block an IP address (Admin only)
     */
    public function blockIP()
    {
        // Check if user is admin (type 1)
        if (session()->get('login_type') != 1) {
            return redirect()->to('/Main')->with('error', 'Access denied. Admin only.');
        }

        $session = session();
        $data = [];
        $data['page_title'] = "Block IP Address";
        $data['session'] = $session;

        if ($this->request->getMethod() == 'post') {
            $rules = [
                'ip_address' => 'required|valid_ip',
                'reason' => 'permit_empty',
                'is_permanent' => 'required|in_list[0,1]',
            ];

            if (!$this->validate($rules)) {
                $session->setFlashdata('error', $this->validator->listErrors());
            } else {
                $post = $this->request->getPost();
                
                $blockData = [
                    'ip_address' => $post['ip_address'],
                    'reason' => $post['reason'],
                    'blocked_by' => $session->get('login_id'),
                    'is_permanent' => $post['is_permanent'],
                    'status' => 1
                ];

                // If temporary, add block_until date
                if ($post['is_permanent'] == 0 && !empty($post['block_duration'])) {
                    $duration = $post['block_duration']; // in hours
                    $blockData['block_until'] = date('Y-m-d H:i:s', strtotime("+{$duration} hours"));
                }

                $save = $this->blocked_ip_model->save($blockData);

                if ($save) {
                    // Create notification about blocked IP
                    $this->notification_model->save([
                        'user_id' => $session->get('login_id'),
                        'type' => 'ip_blocked',
                        'title' => 'IP Address Blocked',
                        'message' => "IP address {$post['ip_address']} has been blocked" . 
                                    ($post['reason'] ? " for: {$post['reason']}" : ""),
                        'is_read' => 0,
                        'created_at' => date('Y-m-d H:i:s')
                    ]);

                    $session->setFlashdata('success', 'IP address has been blocked successfully');
                    return redirect()->to('/Auth/blockIP');
                } else {
                    $session->setFlashdata('error', 'Failed to block IP address');
                }
            }
        }

        return view('auth/block_ip', $data);
    }
    
    /**
     * Manage blocked IPs (Admin only)
     */
    public function manageBlockedIPs()
    {
        // Check if user is admin (type 1)
        if (session()->get('login_type') != 1) {
            return redirect()->to('/Main')->with('error', 'Access denied. Admin only.');
        }

        $session = session();
        $data = [];
        $data['page_title'] = "Manage Blocked IPs";
        $data['session'] = $session;
        $data['blocked_ips'] = $this->blocked_ip_model->getAllBlockedIPs();

        return view('auth/manage_blocked_ips', $data);
    }
    
    /**
     * Unblock an IP address (Admin only)
     */
    public function unblockIP($id)
    {
        // Check if user is admin (type 1)
        if (session()->get('login_type') != 1) {
            return redirect()->to('/Main')->with('error', 'Access denied. Admin only.');
        }

        $session = session();
        
        $update = $this->blocked_ip_model->update($id, ['status' => 0]);

        if ($update) {
            // Create notification about unblocked IP
            $blocked_ip = $this->blocked_ip_model->find($id);
            if ($blocked_ip) {
                $this->notification_model->save([
                    'user_id' => $session->get('login_id'),
                    'type' => 'ip_unblocked',
                    'title' => 'IP Address Unblocked',
                    'message' => "IP address {$blocked_ip['ip_address']} has been unblocked",
                    'is_read' => 0,
                    'created_at' => date('Y-m-d H:i:s')
                ]);
            }

            $session->setFlashdata('success', 'IP address has been unblocked successfully');
        } else {
            $session->setFlashdata('error', 'Failed to unblock IP address');
        }

        return redirect()->to('/Auth/manageBlockedIPs');
    }
    
    /**
     * Get user IPs for selection (admin feature)
     */
    public function getUserIPs($user_id = null)
    {
        // Check if user is admin (type 1)
        if (session()->get('login_type') != 1) {
            return redirect()->to('/Main')->with('error', 'Access denied. Admin only.');
        }

        $session = session();
        $data = [];
        $data['page_title'] = "User IP Addresses";
        $data['session'] = $session;

        if ($this->request->getMethod() == 'post') {
            $user_id = $this->request->getPost('user_id');
        }

        if ($user_id) {
            // Get unique IP addresses used by this user
            $data['user'] = $this->auth_model->find($user_id);
            $data['user_ips'] = $this->auth_model
                ->select('ip_address, MAX(last_login) as last_used, COUNT(*) as login_count')
                ->where('id', $user_id)
                ->where('ip_address IS NOT NULL')
                ->where('ip_address !=', '')
                ->groupBy('ip_address')
                ->orderBy('last_used', 'DESC')
                ->findAll();
        }

        // Get all users for dropdown
        $data['users'] = $this->auth_model->findAll();

        return view('auth/user_ips', $data);
    }
}