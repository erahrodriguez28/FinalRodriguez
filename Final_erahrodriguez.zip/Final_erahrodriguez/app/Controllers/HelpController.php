<?php

namespace App\Controllers;

class HelpController extends BaseController
{
    public function index()
    {
        // Check current URL and redirect if wrong
        $currentUrl = current_url();
        
        // If someone tries to access /admin/pensioners/help/*, redirect to /admin/help
        if (strpos($currentUrl, '/admin/pensioners/help/') !== false) {
            return redirect()->to(base_url('/admin/help'));
        }
        
        // Determine if we're in admin context
        $isAdmin = strpos($currentUrl, '/admin/') !== false;
        
        // Set base URL for links
        $baseHelpUrl = $isAdmin ? '/admin/help' : '/help';
        
        $data = [
            'title' => 'Help & Support',
            'page_title' => $isAdmin ? 'Admin Help & Support Center' : 'Help & Support Center',
            'isAdmin' => $isAdmin,
            'baseHelpUrl' => $baseHelpUrl,
            'breadcrumbs' => $isAdmin ? [
                ['title' => 'Admin Dashboard', 'url' => base_url('/admin')],
                ['title' => 'Admin Help', 'url' => base_url('/admin/help')]
            ] : [
                ['title' => 'Dashboard', 'url' => base_url('/Main')],
                ['title' => 'Help & Support', 'url' => base_url('/help')]
            ],
            'sections' => [
                [
                    'title' => $isAdmin ? 'Administrator FAQs' : 'Frequently Asked Questions',
                    'items' => $isAdmin ? [
                        'How do I add a new administrator?' => 'Only Super Administrators can add new administrators. Contact system administrator.',
                        'How do I manage user permissions?' => 'Navigate to Admin → User Management → Permissions.',
                        'How do I generate financial reports?' => 'Go to Admin → Reports → Financial Reports.',
                        'How do I backup the system?' => 'Use the Backup utility under Admin → System Tools.',
                        'How do I restore from backup?' => 'Go to Admin → System Tools → Restore Backup.',
                    ] : [
                        'How do I register a new pensioner?' => 'Navigate to Admin → Pensioners → Create New Pensioner. Fill in all required fields and save.',
                        'How do I generate reports?' => 'Go to Admin → Pensioners → Reports. Select your criteria and generate the report.',
                        'How do I update user information?' => 'Go to your profile page from the user menu and click "Edit Profile".',
                        'How do I export data?' => 'In the reports section, you can export to PDF or Excel format.',
                        'What should I do if I forget my password?' => 'Contact your system administrator to reset your password.',
                    ]
                ],
                [
                    'title' => $isAdmin ? 'Admin System Guides' : 'System Guides',
                    'items' => $isAdmin ? [
                        'Admin User Manual' => 'Complete guide for system administrators.',
                        'Permission Management' => 'Guide on managing user roles and permissions.',
                        'System Maintenance' => 'Regular maintenance tasks and schedules.',
                        'Data Management' => 'How to manage, backup, and restore system data.',
                    ] : [
                        'User Manual' => 'Detailed guide on using all system features.',
                        'Administrator Guide' => 'Complete guide for system administrators.',
                        'Reporting Guide' => 'Step-by-step guide for generating reports.',
                        'Data Import Guide' => 'How to import pensioner data from Excel files.',
                    ]
                ],
                [
                    'title' => 'Contact Support',
                    'items' => $isAdmin ? [
                        'Technical Support Email' => 'tech-support@pensioner-association.org',
                        'Emergency Technical Line' => '+1 (555) 999-8888',
                        'System Administrator' => 'Contact your system administrator for critical issues.',
                        'Database Support' => 'For database-related issues, contact DBA team.',
                    ] : [
                        'Email Support' => 'support@pensioner-association.org',
                        'Phone Support' => '+1 (555) 123-4567',
                        'Office Hours' => 'Monday to Friday, 9:00 AM to 5:00 PM',
                        'Emergency Contact' => 'For urgent issues, call +1 (555) 987-6543',
                    ]
                ]
            ],
            'contact_form_enabled' => true
        ];

        return view('help/index', $data);
    }

    // Add this method to handle wrong URLs in all methods
    private function checkAndRedirectWrongUrl()
    {
        $currentUrl = current_url();
        
        // If someone tries to access /admin/pensioners/help/*, redirect to /admin/help
        if (strpos($currentUrl, '/admin/pensioners/help/') !== false) {
            $method = $this->request->getMethod();
            $redirectUrl = str_replace('/admin/pensioners/help/', '/admin/help/', $currentUrl);
            return redirect()->to($redirectUrl);
        }
        
        return false;
    }

    public function documentation()
    {
        // Check for wrong URLs first
        $redirect = $this->checkAndRedirectWrongUrl();
        if ($redirect) return $redirect;
        
        $currentUrl = current_url();
        $isAdmin = strpos($currentUrl, '/admin/') !== false;
        $baseHelpUrl = $isAdmin ? '/admin/help' : '/help';
        
        $data = [
            'title' => $isAdmin ? 'Admin Documentation' : 'System Documentation',
            'page_title' => $isAdmin ? 'Administrator Documentation' : 'Complete System Documentation',
            'isAdmin' => $isAdmin,
            'baseHelpUrl' => $baseHelpUrl,
            'breadcrumbs' => $isAdmin ? [
                ['title' => 'Admin Dashboard', 'url' => base_url('/admin')],
                ['title' => 'Admin Help', 'url' => base_url('/admin/help')],
                ['title' => 'Documentation', 'url' => base_url('/admin/help/documentation')]
            ] : [
                ['title' => 'Dashboard', 'url' => base_url('/Main')],
                ['title' => 'Help & Support', 'url' => base_url('/help')],
                ['title' => 'Documentation', 'url' => base_url('/help/documentation')]
            ]
        ];

        return view('help/documentation', $data);
    }

    // Update other methods similarly...
    
    public function contact()
    {
        // Check for wrong URLs first
        $redirect = $this->checkAndRedirectWrongUrl();
        if ($redirect) return $redirect;
        
        if ($this->request->getMethod() === 'post') {
            $rules = [
                'name' => 'required|min_length[3]',
                'email' => 'required|valid_email',
                'subject' => 'required',
                'message' => 'required|min_length[10]'
            ];

            if (!$this->validate($rules)) {
                return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
            }

            $currentUrl = current_url();
            $isAdmin = strpos($currentUrl, '/admin/') !== false;
            $redirectUrl = $isAdmin ? '/admin/help' : '/help';
            
            return redirect()->to($redirectUrl)->with('success', 'Your message has been sent successfully! We will get back to you within 24 hours.');
        }

        $currentUrl = current_url();
        $isAdmin = strpos($currentUrl, '/admin/') !== false;
        $baseHelpUrl = $isAdmin ? '/admin/help' : '/help';
        
        $data = [
            'title' => 'Contact Support',
            'page_title' => 'Contact Support Team',
            'isAdmin' => $isAdmin,
            'baseHelpUrl' => $baseHelpUrl,
            'breadcrumbs' => $isAdmin ? [
                ['title' => 'Admin Dashboard', 'url' => base_url('/admin')],
                ['title' => 'Admin Help', 'url' => base_url('/admin/help')],
                ['title' => 'Contact', 'url' => base_url('/admin/help/contact')]
            ] : [
                ['title' => 'Dashboard', 'url' => base_url('/Main')],
                ['title' => 'Help & Support', 'url' => base_url('/help')],
                ['title' => 'Contact', 'url' => base_url('/help/contact')]
            ]
        ];

        return view('help/contact', $data);
    }
    
    // Update faq() and tutorials() methods similarly...
}