<?php

namespace App\Controllers;

use App\Models\Auth;
use App\Models\SettingModel;

class Main extends BaseController
{   
    protected $request;
    protected $session;
    protected $auth_model;
    protected $data;

    public function __construct()
    {
        $this->request = \Config\Services::request();
        $this->session = session();
        $this->auth_model = new Auth();
        $this->data = ['session' => $this->session];
    }

    public function index()
    {
        // Admin
        if ($this->session->login_type == 1) {
            $this->data['page_title'] = "Admin Home";
            return view('pages/home', $this->data);
        }
    
        // Normal user
        $this->data['page_title'] = "Home";
        return view('pages/user_home', $this->data);
    }

    // Admin-only toggle
    public function toggleMaintenanceMode()
    {
        if ($this->session->login_type != 1) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }
    
        $settingModel = new SettingModel();
        $current = $settingModel->getMode();
    
        $newMode = ($current === 'online') ? 'maintenance' : 'online';
        $settingModel->updateMode($newMode);
    
        return redirect()->back()->with('success', 'System mode updated successfully!');
    }
    
    public function users()
    {
        if ($this->session->login_type != 1) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        $this->data['page_title'] = "Users";
        $this->data['page'] = !empty($this->request->getVar('page')) ? $this->request->getVar('page') : 1;
        $this->data['perPage'] = 10;

        $this->data['total'] = $this->auth_model
            ->where("id !=", $this->session->login_id)
            ->countAllResults();

        $this->data['users'] = $this->auth_model
            ->where("id !=", $this->session->login_id)
            ->paginate($this->data['perPage']);

        $this->data['total_res'] = is_array($this->data['users']) ? count($this->data['users']) : 0;
        $this->data['pager'] = $this->auth_model->pager;

        return view('pages/users/list', $this->data);
    }

    public function user_edit($id = '')
    {
        if ($this->session->login_type != 1) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        if (empty($id))
            return redirect()->to('Main/users');

        if ($this->request->getMethod() == 'post') {
            $name = $this->request->getPost('name');
            $email = $this->request->getPost('email');
            $type = $this->request->getPost('type');
            $status = $this->request->getPost('status');
            $password = $this->request->getPost('password');
            $cpassword = $this->request->getPost('cpassword');

            if ($password !== $cpassword) {
                $this->session->setFlashdata('error', "Password does not match.");
            } else {
                $udata = [
                    'name' => $name,
                    'email' => $email,
                    'type' => $type,
                    'status' => $status,
                ];

                if (!empty($password)) {
                    $udata['password'] = password_hash($password, PASSWORD_DEFAULT);
                }

                $update = $this->auth_model->where('id', $id)->set($udata)->update();

                if ($update) {
                    $this->session->setFlashdata('success', "User Details has been updated successfully.");
                    return redirect()->to('Main/user_edit/' . $id);
                } else {
                    $this->session->setFlashdata('error', "User Details has failed to update.");
                }
            }
        }

        $this->data['page_title'] = "Users";
        $this->data['user'] = $this->auth_model->where("id", $id)->first();

        return view('pages/users/edit', $this->data);
    }

    public function user_delete($id = '')
    {
        if ($this->session->login_type != 1) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        if (empty($id)) {
            $this->session->setFlashdata('main_error', "User deletion failed due to unknown ID.");
            return redirect()->to('Main/users');
        }

        $delete = $this->auth_model->where('id', $id)->delete();

        if ($delete) {
            $this->session->setFlashdata('main_success', "User has been deleted successfully.");
        } else {
            $this->session->setFlashdata('main_error', "User deletion failed due to unknown ID.");
        }

        return redirect()->to('Main/users');
    }
}
