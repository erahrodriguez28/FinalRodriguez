<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\NotificationModel;

class Notifications extends BaseController
{
    protected $notificationModel;

    public function __construct()
    {
        $this->notificationModel = new NotificationModel();
    }

    /**
     * Get notifications (AJAX endpoint)
     */
    public function getNotifications()
    {
        if (!$this->request->isAJAX()) {
            return $this->response->setStatusCode(403)->setJSON(['error' => 'Forbidden']);
        }

        $session = session();
        $isAdmin = ($session->login_type == 1);
        $userId = $session->login_id;

        if ($isAdmin) {
            $notifications = $this->notificationModel->getAdminNotifications(10, true);
        } else {
            $notifications = $this->notificationModel->getUserNotifications($userId, 10, true);
        }

        $unreadCount = $this->notificationModel->getUnreadCount($isAdmin ? null : $userId, $isAdmin);

        return $this->response->setJSON([
            'success' => true,
            'notifications' => $notifications,
            'unreadCount' => $unreadCount
        ]);
    }

    /**
     * Mark notification as read
     */
    public function markAsRead($id)
    {
        $this->notificationModel->markAsRead($id);
        
        if ($this->request->isAJAX()) {
            return $this->response->setJSON(['success' => true]);
        }
        
        return redirect()->back();
    }

    /**
     * Mark all as read
     */
    public function markAllAsRead()
    {
        $session = session();
        $isAdmin = ($session->login_type == 1);
        $userId = $session->login_id;

        if ($isAdmin) {
            $this->notificationModel->markAllAsRead();
        } else {
            $this->notificationModel->markAllAsRead($userId);
        }
        
        if ($this->request->isAJAX()) {
            return $this->response->setJSON(['success' => true]);
        }
        
        return redirect()->back();
    }

    /**
     * View all notifications
     */
    public function index()
    {
        $session = session();
        $isAdmin = ($session->login_type == 1);
        $userId = $session->login_id;

        if ($isAdmin) {
            $notifications = $this->notificationModel->getAdminNotifications(50);
        } else {
            $notifications = $this->notificationModel->getUserNotifications($userId, 50);
        }

        $data = [
            'page_title' => 'Notifications',
            'notifications' => $notifications,
            'isAdmin' => $isAdmin
        ];

        return view($isAdmin ? 'admin/notifications/index' : 'user/notifications/index', $data);
    }
}