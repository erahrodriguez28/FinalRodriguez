<?php

namespace App\Controllers;

use CodeIgniter\Controller;

class Pages extends Controller
{
    // Show maintenance warning for normal users
    public function maintenance_warning()
    {
        return view('pages/maintenance_warning');
    }
}
