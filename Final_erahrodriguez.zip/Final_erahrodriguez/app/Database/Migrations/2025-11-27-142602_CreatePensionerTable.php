<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreatePensionersTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'pensioner_id' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
                'auto_increment' => true,
            ],
            'full_name' => [
                'type' => 'VARCHAR',
                'constraint' => '255',
            ],
            'date_of_birth' => [
                'type' => 'DATE',
                'null' => true,
            ],
            'address' => [
                'type' => 'VARCHAR',
                'constraint' => '255',
                'null' => true,
            ],
            'contact_number' => [
                'type' => 'VARCHAR',
                'constraint' => '20',
                'null' => true,
            ],
            'email' => [
                'type' => 'VARCHAR',
                'constraint' => '255',
                'null' => true,
            ],
                'pension_type' => [
                'type' => 'ENUM',
                'constraint' => ['retirement', 'disability', 'survivor', 'other'],
                'default' => 'retirement',
                'null' => true,
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'deleted_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);

        $this->forge->addKey('pensioner_id', true);
        $this->forge->createTable('pensioners');
    }

    public function down()
    {
        $this->forge->dropTable('pensioners');
    }
}
