<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

class IPBlockerFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        $blockedIPModel = new \App\Models\BlockedIPModel();
        $ip_address = $request->getIPAddress();
        
        // Check if IP is blocked
        $blocked = $blockedIPModel->isBlocked($ip_address);
        
        if ($blocked) {
            // You can redirect to a custom blocked page or show error
            $response = service('response');
            $response->setStatusCode(403);
            
            return view('errors/blocked_ip', [
                'ip_address' => $ip_address,
                'block_info' => $blocked
            ]);
        }
        
        return;
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // Do something after the response
    }
}