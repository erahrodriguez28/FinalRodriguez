<?php

namespace App\Filters;

use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\Filters\FilterInterface;
use App\Models\SettingModel;

class MaintenanceFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        $session = session();
        $settingModel = new SettingModel();
        $mode = $settingModel->getMode();

        // 🚀 If user is admin (login_type == 1), DO NOT apply maintenance mode
        if ($session->get('login_type') == 1) {
            return; // admin not affected
        }

        $uri = service('uri');
        try {
            $controller = $uri->getSegment(1) ?? '';
            $method     = $uri->getSegment(2) ?? '';
        } catch (\CodeIgniter\HTTP\Exceptions\HTTPException $e) {
            $controller = '';
            $method = '';
        }

        // Allowed controllers/methods for normal users during maintenance
        $allowedControllers = ['Auth', 'Main'];
        $allowedMethods = ['toggleMaintenanceMode', 'maintenance_warning', 'index'];

        if ($mode === 'maintenance') {
            $isAllowedController = in_array($controller, $allowedControllers);
            $isAllowedMethod = in_array($method, $allowedMethods);

            // Normal users blocked if not allowed
            if (!($isAllowedController && $isAllowedMethod)) {
                return redirect()->to('/maintenance_warning');
            }
        }
    }

    public function after(RequestInterface $request, $response, $arguments = null)
    {
        // No post-processing needed
    }
}
