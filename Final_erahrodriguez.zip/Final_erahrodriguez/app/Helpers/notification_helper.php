<?php

use App\Models\NotificationModel;

if (!function_exists('create_notification')) {
    /**
     * Helper function to create notifications easily
     */
    function create_notification($data)
    {
        $notificationModel = new NotificationModel();
        return $notificationModel->createNotification($data);
    }
}

if (!function_exists('notify_login')) {
    /**
     * Notify admin about user login
     */
    function notify_login($userId, $userName, $ipAddress)
    {
        $notificationModel = new NotificationModel();
        return $notificationModel->notifyLogin($userId, $userName, $ipAddress);
    }
}

if (!function_exists('notify_new_pensioner')) {
    /**
     * Notify about new pensioner
     */
    function notify_new_pensioner($pensionerId, $pensionerName, $createdBy)
    {
        $notificationModel = new NotificationModel();
        return $notificationModel->notifyPensionerCreated($pensionerId, $pensionerName, $createdBy);
    }
}