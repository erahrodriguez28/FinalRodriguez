<?php

namespace App\Models;

use CodeIgniter\Model;

class BlockedIPModel extends Model
{
    protected $DBGroup          = 'default';
    protected $table            = 'blocked_ips';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $insertID         = 0;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = [
        'ip_address',
        'reason',
        'blocked_by',
        'is_permanent',
        'block_until',
        'status'
    ];

    // Dates
    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    // Validation
    protected $validationRules      = [
        'ip_address' => 'required|valid_ip',
        'reason'     => 'permit_empty',
        'blocked_by' => 'required|is_natural_no_zero',
    ];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    /**
     * Check if IP is blocked
     */
    public function isBlocked($ip_address)
    {
        $now = date('Y-m-d H:i:s');
        
        $builder = $this->where('ip_address', $ip_address)
                       ->where('status', 1);
        
        // Check permanent blocks
        $permanent = $builder->where('is_permanent', 1)->first();
        
        if ($permanent) {
            return $permanent;
        }
        
        // Check temporary blocks that haven't expired
        $temporary = $builder->where('is_permanent', 0)
                           ->where('block_until >=', $now)
                           ->first();
        
        return $temporary ?: false;
    }

    /**
     * Get all blocked IPs with user info
     */
    public function getAllBlockedIPs()
    {
        $authModel = new Auth();
        
        return $this->select('blocked_ips.*, users.name as blocked_by_name, users.email as blocked_by_email')
                   ->join('users', 'users.id = blocked_ips.blocked_by')
                   ->orderBy('created_at', 'DESC')
                   ->findAll();
    }

    /**
     * Get login attempts for an IP (optional for logging attempts)
     */
    public function getLoginAttempts($ip_address, $hours = 24)
    {
        $time = date('Y-m-d H:i:s', strtotime("-{$hours} hours"));
        
        // You need to create a login_attempts table first
        // return $this->db->table('login_attempts')
        //     ->where('ip_address', $ip_address)
        //     ->where('attempt_time >=', $time)
        //     ->countAllResults();
        
        return 0; // Placeholder
    }
}