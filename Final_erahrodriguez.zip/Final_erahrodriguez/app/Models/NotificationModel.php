<?php

namespace App\Models;

use CodeIgniter\Model;

class NotificationModel extends Model
{
    protected $table = 'notifications';
    protected $primaryKey = 'notification_id';
    
    protected $allowedFields = [
        'user_id',
        'title',
        'message',
        'type',
        'is_read',
        'for_admin',
        'for_user',
        'action_url',
        'created_at'
    ];

    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    
    /**
     * Get notifications for user
     */
    public function getUserNotifications($userId = null, $limit = 10, $unreadOnly = false)
    {
        $builder = $this->builder();
        
        // For specific user or general user notifications
        if ($userId) {
            $builder->groupStart()
                   ->where('user_id', $userId)
                   ->orWhere('for_user', 1)
                   ->groupEnd();
        } else {
            $builder->where('for_user', 1);
        }
        
        if ($unreadOnly) {
            $builder->where('is_read', 0);
        }
        
        $builder->orderBy('created_at', 'DESC');
        
        if ($limit) {
            $builder->limit($limit);
        }
        
        return $builder->get()->getResultArray();
    }
    
    /**
     * Get notifications for admin
     */
    public function getAdminNotifications($limit = 10, $unreadOnly = false)
    {
        $builder = $this->builder();
        $builder->where('for_admin', 1);
        
        if ($unreadOnly) {
            $builder->where('is_read', 0);
        }
        
        $builder->orderBy('created_at', 'DESC');
        
        if ($limit) {
            $builder->limit($limit);
        }
        
        return $builder->get()->getResultArray();
    }
    
    /**
     * Mark notification as read
     */
    public function markAsRead($notificationId)
    {
        return $this->update($notificationId, ['is_read' => 1]);
    }
    
    /**
     * Mark all as read for user
     */
    public function markAllAsRead($userId = null)
    {
        $builder = $this->builder();
        
        if ($userId) {
            $builder->where('user_id', $userId)
                   ->orWhere('for_user', 1);
        } else {
            $builder->where('for_admin', 1);
        }
        
        return $builder->set('is_read', 1)
                      ->where('is_read', 0)
                      ->update();
    }
    
    /**
     * Create a new notification
     */
    public function createNotification($data)
    {
        if (!isset($data['created_at'])) {
            $data['created_at'] = date('Y-m-d H:i:s');
        }
        
        return $this->insert($data);
    }
    
    /**
     * Get unread count for user
     */
    public function getUnreadCount($userId = null, $isAdmin = false)
    {
        $builder = $this->builder();
        $builder->where('is_read', 0);
        
        if ($isAdmin) {
            $builder->where('for_admin', 1);
        } else {
            if ($userId) {
                $builder->groupStart()
                       ->where('user_id', $userId)
                       ->orWhere('for_user', 1)
                       ->groupEnd();
            } else {
                $builder->where('for_user', 1);
            }
        }
        
        return $builder->countAllResults();
    }
    
    /**
     * Create login notification
     */
    public function notifyLogin($userId, $userName, $ipAddress)
    {
        $data = [
            'user_id'    => $userId,
            'title'      => 'User Login',
            'message'    => "User {$userName} logged in from IP: {$ipAddress}",
            'type'       => 'info',
            'for_admin'  => 1,
            'for_user'   => 0,
            'action_url' => base_url('/admin/users')
        ];
        
        return $this->createNotification($data);
    }
    
    /**
     * Create logout notification
     */
    public function notifyLogout($userId, $userName)
    {
        $data = [
            'user_id'    => $userId,
            'title'      => 'User Logout',
            'message'    => "User {$userName} logged out",
            'type'       => 'info',
            'for_admin'  => 1,
            'for_user'   => 0
        ];
        
        return $this->createNotification($data);
    }
    
    /**
     * Create new registration notification
     */
    public function notifyNewRegistration($userId, $userName, $email)
    {
        $data = [
            'user_id'    => $userId,
            'title'      => 'New User Registration',
            'message'    => "New user registered: {$userName} ({$email})",
            'type'       => 'success',
            'for_admin'  => 1,
            'for_user'   => 1,
            'action_url' => base_url('/admin/users/edit/' . $userId)
        ];
        
        return $this->createNotification($data);
    }
    
    /**
     * Create pensioner created notification
     */
    public function notifyPensionerCreated($pensionerId, $pensionerName, $createdBy)
    {
        $data = [
            'user_id'    => $createdBy,
            'title'      => 'New Pensioner Added',
            'message'    => "New pensioner added: {$pensionerName}",
            'type'       => 'success',
            'for_admin'  => 1,
            'for_user'   => 1,
            'action_url' => base_url('/admin/pensioners/edit/' . $pensionerId)
        ];
        
        return $this->createNotification($data);
    }
    
    /**
     * Create report generated notification
     */
    public function notifyReportGenerated($reportType, $generatedBy)
    {
        $data = [
            'user_id'    => $generatedBy,
            'title'      => 'Report Generated',
            'message'    => "{$reportType} report has been generated",
            'type'       => 'info',
            'for_admin'  => 1,
            'for_user'   => 0,
            'action_url' => base_url('/admin/pensioners/report')
        ];
        
        return $this->createNotification($data);
    }
    
    // Add to NotificationModel.php
public function notifyIPBlocked($blockedBy, $ipAddress, $reason)
{
    $notification = [
        'user_id' => $blockedBy, // Admin who blocked
        'title' => 'IP Address Blocked',
        'message' => "IP Address {$ipAddress} has been blocked. Reason: {$reason}",
        'type' => 'security',
        'is_read' => 0
    ];
    
    return $this->insert($notification);
}

public function notifyIPUnblocked($unblockedBy, $ipAddress)
{
    $notification = [
        'user_id' => $unblockedBy, // Admin who unblocked
        'title' => 'IP Address Unblocked',
        'message' => "IP Address {$ipAddress} has been unblocked.",
        'type' => 'security',
        'is_read' => 0
    ];
    
    return $this->insert($notification);
}
}