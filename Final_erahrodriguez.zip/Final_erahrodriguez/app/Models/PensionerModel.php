<?php

namespace App\Models;

use CodeIgniter\Model;

class PensionerModel extends Model
{
    protected $table = 'pensioners';
    protected $primaryKey = 'pensioner_id';
    
    protected $allowedFields = [
        'full_name', 
        'date_of_birth',
        'gender',
        'marital_status',
        'id_number',
        'address', 
        'contact_number',
        'email',
        'bank_account',
        'bank_name',
        'next_of_kin',
        'next_of_kin_contact',
        'pension_type',
        'pension_amount',
        'pension_start_date',
        'status',
        'notes',
        'medical_conditions',
        'created_by',
        'created_at', 
        'updated_at', 
        'deleted_at'
    ];

    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';
    protected $useSoftDeletes = true;
    
    /**
     * Get all pensioners for ADMIN (sees all)
     */
    public function getAllPensioners()
    {
        return $this->orderBy('created_at', 'DESC')->findAll();
    }
    
    /**
     * Get pensioners for REGULAR USER (only their own)
     */
    public function getUserPensioners($userId)
    {
        return $this->where('created_by', $userId)
                   ->orderBy('created_at', 'DESC')
                   ->findAll();
    }
    
    /**
     * Get single pensioner with ownership check
     */
    public function getPensioner($id, $userId = null, $isAdmin = false)
    {
        $query = $this->where('pensioner_id', $id);
        
        // If not admin, check ownership
        if (!$isAdmin && $userId) {
            $query->where('created_by', $userId);
        }
        
        return $query->first();
    }
    
    /**
     * Check if user owns this pensioner
     */
    public function isOwner($pensionerId, $userId)
    {
        $pensioner = $this->select('created_by')
                         ->where('pensioner_id', $pensionerId)
                         ->first();
        
        return $pensioner && $pensioner['created_by'] == $userId;
    }
    
    // Get pension type labels
    public function getPensionTypeLabel($type)
    {
        $types = [
            'retirement' => 'Retirement',
            'disability' => 'Disability',
            'survivor' => 'Survivor',
            'other' => 'Other'
        ];
        
        return $types[$type] ?? $type;
    }
    
    /**
     * Get status labels with colors
     */
    public function getStatusLabel($status)
    {
        $statuses = [
            'active' => ['label' => 'Active', 'class' => 'bg-success-subtle text-success'],
            'suspended' => ['label' => 'Suspended', 'class' => 'bg-warning-subtle text-warning'],
            'deceased' => ['label' => 'Deceased', 'class' => 'bg-danger-subtle text-danger'],
            'inactive' => ['label' => 'Inactive', 'class' => 'bg-secondary-subtle text-secondary'],
        ];
        
        return $statuses[$status] ?? ['label' => ucfirst($status), 'class' => 'bg-light text-dark'];
    }
    
    /**
     * Get gender labels
     */
    public function getGenderLabel($gender)
    {
        $genders = [
            'male' => 'Male',
            'female' => 'Female',
            'other' => 'Other'
        ];
        
        return $genders[$gender] ?? $gender;
    }
    
    /**
     * Get marital status labels
     */
    public function getMaritalStatusLabel($status)
    {
        $statuses = [
            'single' => 'Single',
            'married' => 'Married',
            'divorced' => 'Divorced',
            'widowed' => 'Widowed'
        ];
        
        return $statuses[$status] ?? $status;
    }
    
    // ANALYTICS & REPORT METHODS
    
    /**
     * Get pension type statistics (alias for backward compatibility)
     */
    public function getPensionTypeStats($userId = null, $isAdmin = false)
    {
        return $this->getUserPensionTypeStats($userId, $isAdmin);
    }
    
    /**
     * Get statistics by pension type for specific user
     */
    public function getUserPensionTypeStats($userId, $isAdmin = false)
    {
        $builder = $this->builder();
        $builder->select('pension_type, COUNT(*) as count');
        
        if (!$isAdmin) {
            $builder->where('created_by', $userId);
        }
        
        $builder->groupBy('pension_type');
        $builder->orderBy('count', 'DESC');
        
        return $builder->get()->getResultArray();
    }
    
    /**
     * Get age group statistics
     */
    public function getAgeGroupStats($userId = null, $isAdmin = false)
    {
        $currentYear = date('Y');
        $builder = $this->builder();
        
        $builder->select("
            CASE
                WHEN YEAR(CURDATE()) - YEAR(date_of_birth) < 60 THEN 'Under 60'
                WHEN YEAR(CURDATE()) - YEAR(date_of_birth) BETWEEN 60 AND 69 THEN '60-69'
                WHEN YEAR(CURDATE()) - YEAR(date_of_birth) BETWEEN 70 AND 79 THEN '70-79'
                WHEN YEAR(CURDATE()) - YEAR(date_of_birth) BETWEEN 80 AND 89 THEN '80-89'
                ELSE '90+'
            END as age_group,
            COUNT(*) as count
        ");
        
        if (!$isAdmin && $userId) {
            $builder->where('created_by', $userId);
        }
        
        $builder->groupBy('age_group')
               ->orderBy('age_group');
        
        return $builder->get()->getResultArray();
    }
    
    /**
     * Get registration trends (alias for monthly enrollment stats)
     */
    public function getRegistrationTrends($year = null, $userId = null, $isAdmin = false)
    {
        return $this->getMonthlyEnrollmentStats($year, $userId, $isAdmin);
    }
    
    /**
     * Get monthly enrollment trends
     */
    public function getMonthlyEnrollmentStats($year = null, $userId = null, $isAdmin = false)
    {
        $year = $year ?? date('Y');
        $builder = $this->builder();
        
        $builder->select("
            MONTH(created_at) as month,
            COUNT(*) as count
        ");
        
        $builder->where('YEAR(created_at)', $year);
        
        if (!$isAdmin && $userId) {
            $builder->where('created_by', $userId);
        }
        
        $builder->groupBy('MONTH(created_at)')
               ->orderBy('month');
        
        $result = $builder->get()->getResultArray();
        
        // Fill in missing months with zero
        $monthlyData = [];
        for ($i = 1; $i <= 12; $i++) {
            $monthlyData[$i] = 0;
        }
        
        foreach ($result as $row) {
            $monthlyData[$row['month']] = (int)$row['count'];
        }
        
        return $monthlyData;
    }
    
    /**
     * Get location statistics (by address)
     */
    public function getLocationStats()
    {
        // Assuming address contains city information
        // You might need to adjust this based on your address format
        $builder = $this->builder();
        $builder->select('SUBSTRING_INDEX(SUBSTRING_INDEX(address, ",", -2), ",", 1) as city, COUNT(*) as count');
        $builder->where('address IS NOT NULL');
        $builder->where('address !=', '');
        $builder->groupBy('city');
        $builder->orderBy('count', 'DESC');
        $builder->limit(10);
        
        return $builder->get()->getResultArray();
    }
    
    /**
     * Get yearly summary statistics
     */
/**
 * Get yearly summary statistics
 */
public function getYearlySummary($year = null, $userId = null, $isAdmin = false)
{
    $year = $year ?? date('Y');
    $builder = $this->builder();
    
    if (!$isAdmin && $userId) {
        $builder->where('created_by', $userId);
    }
    
    $builder->where('YEAR(created_at)', $year);
    
    $total = $builder->countAllResults();
    
    // Get counts by pension type for this year
    $typeBuilder = $this->builder();
    $typeBuilder->select('pension_type, COUNT(*) as count');
    
    if (!$isAdmin && $userId) {
        $typeBuilder->where('created_by', $userId);
    }
    
    $typeBuilder->where('YEAR(created_at)', $year)
               ->groupBy('pension_type');
    
    $typeStats = $typeBuilder->get()->getResultArray();
    
    // Initialize counts
    $retirementCount = 0;
    $disabilityCount = 0;
    $survivorCount = 0;
    $otherCount = 0;
    
    foreach ($typeStats as $stat) {
        switch ($stat['pension_type']) {
            case 'retirement':
                $retirementCount = (int)$stat['count'];
                break;
            case 'disability':
                $disabilityCount = (int)$stat['count'];
                break;
            case 'survivor':
                $survivorCount = (int)$stat['count'];
                break;
            case 'other':
                $otherCount = (int)$stat['count'];
                break;
        }
    }
    
    $activeCount = $this->where('YEAR(created_at)', $year)
                       ->where('status', 'active');
    
    if (!$isAdmin && $userId) {
        $activeCount->where('created_by', $userId);
    }
    
    $active = $activeCount->countAllResults();
    
    $totalAmount = $this->selectSum('pension_amount')
                       ->where('YEAR(created_at)', $year)
                       ->where('status', 'active');
    
    if (!$isAdmin && $userId) {
        $totalAmount->where('created_by', $userId);
    }
    
    $totalAmount = $totalAmount->get()->getRow()->pension_amount ?? 0;
    
    return [
        'total_pensioners' => $total,
        'total_registered' => $total, // Keep for backward compatibility
        'retirement_count' => $retirementCount,
        'disability_count' => $disabilityCount,
        'survivor_count' => $survivorCount,
        'other_count' => $otherCount,
        'active_count' => $active,
        'total_pension_amount' => $totalAmount,
        'average_amount' => $active > 0 ? round($totalAmount / $active, 2) : 0
    ];
}
    
    /**
     * Get gender distribution statistics
     */
    public function getGenderStats($userId = null, $isAdmin = false)
    {
        $builder = $this->builder();
        $builder->select('gender, COUNT(*) as count');
        
        if (!$isAdmin && $userId) {
            $builder->where('created_by', $userId);
        }
        
        $builder->groupBy('gender');
        
        return $builder->get()->getResultArray();
    }
    
    /**
     * Get status distribution statistics
     */
    public function getStatusStats($userId = null, $isAdmin = false)
    {
        $builder = $this->builder();
        $builder->select('status, COUNT(*) as count');
        
        if (!$isAdmin && $userId) {
            $builder->where('created_by', $userId);
        }
        
        $builder->groupBy('status');
        
        return $builder->get()->getResultArray();
    }
    
    /**
     * Get total pension amount by type
     */
    public function getPensionAmountByType($userId = null, $isAdmin = false)
    {
        $builder = $this->builder();
        $builder->select('pension_type, SUM(pension_amount) as total_amount');
        
        if (!$isAdmin && $userId) {
            $builder->where('created_by', $userId);
        }
        
        $builder->where('status', 'active')
               ->groupBy('pension_type');
        
        return $builder->get()->getResultArray();
    }
    
    /**
     * Get average pension amount
     */
    public function getAveragePensionAmount($userId = null, $isAdmin = false)
    {
        $builder = $this->builder();
        $builder->selectAvg('pension_amount', 'average_amount');
        
        if (!$isAdmin && $userId) {
            $builder->where('created_by', $userId);
        }
        
        $builder->where('status', 'active');
        
        return $builder->get()->getRow()->average_amount ?? 0;
    }
    
    /**
     * Generate detailed report with user filter
     */
    public function generateDetailedReport($filters = [], $userId = null, $isAdmin = false)
    {
        $builder = $this->builder();
        
        // Apply user filter if not admin
        if (!$isAdmin && $userId) {
            $builder->where('created_by', $userId);
        }
        
        // Apply other filters
        if (!empty($filters['pension_type'])) {
            $builder->where('pension_type', $filters['pension_type']);
        }
        
        if (!empty($filters['status'])) {
            $builder->where('status', $filters['status']);
        }
        
        if (!empty($filters['start_date'])) {
            $builder->where('DATE(created_at) >=', $filters['start_date']);
        }
        
        if (!empty($filters['end_date'])) {
            $builder->where('DATE(created_at) <=', $filters['end_date']);
        }
        
        if (!empty($filters['search'])) {
            $builder->groupStart()
                   ->like('full_name', $filters['search'])
                   ->orLike('email', $filters['search'])
                   ->orLike('address', $filters['search'])
                   ->orLike('contact_number', $filters['search'])
                   ->orLike('id_number', $filters['search'])
                   ->groupEnd();
        }
        
        $builder->orderBy('created_at', 'DESC');
        
        return $builder->get()->getResultArray();
    }
    
    /**
     * Get user dashboard statistics
     */
    public function getUserDashboardStats($userId, $isAdmin = false)
    {
        $builder = $this->builder();
        
        if (!$isAdmin) {
            $builder->where('created_by', $userId);
        }
        
        return [
            'total' => $builder->countAllResults(),
            'active' => $builder->where('status', 'active')->countAllResults(),
            'monthly_added' => $this->where('created_by', $userId)
                                   ->where('MONTH(created_at)', date('m'))
                                   ->where('YEAR(created_at)', date('Y'))
                                   ->countAllResults(),
            'total_amount' => $this->selectSum('pension_amount')
                                  ->where('created_by', $userId)
                                  ->where('status', 'active')
                                  ->get()
                                  ->getRow()->pension_amount ?? 0,
        ];
    }
    
    /**
     * Get all analytics data for dashboard
     */
    public function getDashboardAnalytics($userId = null, $isAdmin = false)
    {
        return [
            'age_groups' => $this->getAgeGroupStats($userId, $isAdmin),
            'pension_types' => $this->getPensionTypeStats($userId, $isAdmin),
            'gender_stats' => $this->getGenderStats($userId, $isAdmin),
            'status_stats' => $this->getStatusStats($userId, $isAdmin),
            'monthly_enrollment' => $this->getMonthlyEnrollmentStats(null, $userId, $isAdmin),
            'pension_amounts' => $this->getPensionAmountByType($userId, $isAdmin),
            'average_pension' => $this->getAveragePensionAmount($userId, $isAdmin),
        ];
    }
}