<?php

namespace App\Models;

use CodeIgniter\Model;

class SettingModel extends Model
{
    protected $table = 'settings';
    protected $primaryKey = 'id';
    protected $allowedFields = ['mode'];

    public function getMode()
    {
        $setting = $this->first();
        return $setting ? $setting['mode'] : 'online';
    }

    public function toggleMode()
    {
        $setting = $this->first();
        if ($setting) {
            $newMode = ($setting['mode'] === 'online') ? 'maintenance' : 'online';
            $this->update($setting['id'], ['mode' => $newMode]);
            return $newMode;
        }
        return false;
    }

    public function updateMode($mode)
    {
        $setting = $this->first();
        return $this->update($setting['id'], ['mode' => $mode]);
    }
}
