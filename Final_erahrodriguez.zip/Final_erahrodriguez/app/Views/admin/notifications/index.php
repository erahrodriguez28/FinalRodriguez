<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title ?> - Notifications | <?= env('system_name') ?></title>
    
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --primary: #2c5aa0;
            --primary-dark: #1e3a6f;
            --primary-light: #4a7fd4;
            --light-bg: #f8fafc;
            --card-bg: #ffffff;
            --border-color: #e2e8f0;
            --text-dark: #1e293b;
            --text-medium: #475569;
            --text-light: #64748b;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --info: #3b82f6;
        }
        
        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--light-bg);
            color: var(--text-dark);
            font-size: 15px;
            line-height: 1.6;
            font-weight: 400;
            min-height: 100vh;
        }
        
        .main-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 30px 20px;
        }
        
        /* Header Styles */
        .page-header {
            background: var(--card-bg);
            border-radius: 12px;
            padding: 24px 30px;
            margin-bottom: 30px;
            border: 1px solid var(--border-color);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.04);
        }
        
        .page-title {
            font-size: 28px;
            font-weight: 700;
            color: var(--text-dark);
            margin: 0;
            letter-spacing: -0.3px;
        }
        
        .page-subtitle {
            color: var(--text-light);
            font-size: 14px;
            margin-top: 8px;
            font-weight: 500;
        }
        
        /* Back Button */
        .back-btn {
            background: transparent;
            border: 1px solid var(--border-color);
            color: var(--primary);
            border-radius: 8px;
            padding: 10px 20px;
            font-weight: 600;
            font-size: 14px;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s ease;
            margin-bottom: 20px;
        }
        
        .back-btn:hover {
            background: rgba(44, 90, 160, 0.05);
            border-color: var(--primary);
            color: var(--primary-dark);
            transform: translateY(-1px);
            text-decoration: none;
        }
        
        /* Notification Card Styles */
        .notification-container {
            background: var(--card-bg);
            border-radius: 12px;
            border: 1px solid var(--border-color);
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.04);
        }
        
        .notification-header {
            padding: 20px 24px;
            border-bottom: 1px solid var(--border-color);
            background: rgba(44, 90, 160, 0.02);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }
        
        .notification-actions {
            display: flex;
            gap: 12px;
            align-items: center;
        }
        
        .notification-count {
            background: var(--primary);
            color: white;
            border-radius: 20px;
            padding: 4px 12px;
            font-size: 12px;
            font-weight: 600;
        }
        
        /* Notification Item Styles */
        .notification-item {
            padding: 20px 24px;
            border-bottom: 1px solid var(--border-color);
            text-decoration: none;
            display: block;
            transition: all 0.2s ease;
            position: relative;
        }
        
        .notification-item:last-child {
            border-bottom: none;
        }
        
        .notification-item:hover {
            background: rgba(44, 90, 160, 0.03);
            text-decoration: none;
        }
        
        .notification-item.unread {
            background: rgba(44, 90, 160, 0.05);
            border-left: 3px solid var(--primary);
        }
        
        .notification-item.unread:hover {
            background: rgba(44, 90, 160, 0.08);
        }
        
        .notification-item.read {
            border-left: 3px solid transparent;
        }
        
        .notification-icon {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            flex-shrink: 0;
        }
        
        .notification-icon.info {
            background: rgba(59, 130, 246, 0.1);
            color: var(--info);
        }
        
        .notification-icon.success {
            background: rgba(16, 185, 129, 0.1);
            color: var(--success);
        }
        
        .notification-icon.warning {
            background: rgba(245, 158, 11, 0.1);
            color: var(--warning);
        }
        
        .notification-icon.error {
            background: rgba(239, 68, 68, 0.1);
            color: var(--danger);
        }
        
        .notification-icon.system {
            background: rgba(44, 90, 160, 0.1);
            color: var(--primary);
        }
        
        .notification-content {
            flex: 1;
            min-width: 0;
        }
        
        .notification-title {
            font-weight: 600;
            font-size: 15px;
            color: var(--text-dark);
            margin-bottom: 4px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .notification-message {
            color: var(--text-medium);
            font-size: 14px;
            line-height: 1.5;
            margin-bottom: 8px;
        }
        
        .notification-meta {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px;
        }
        
        .notification-time {
            font-size: 12px;
            color: var(--text-light);
            font-weight: 500;
        }
        
        .notification-action {
            font-size: 12px;
            color: var(--primary);
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.3px;
        }
        
        .notification-empty {
            padding: 50px 30px;
            text-align: center;
        }
        
        .empty-icon {
            font-size: 48px;
            color: var(--text-light);
            opacity: 0.5;
            margin-bottom: 20px;
        }
        
        .empty-title {
            font-size: 18px;
            font-weight: 600;
            color: var(--text-dark);
            margin-bottom: 10px;
        }
        
        .empty-subtitle {
            color: var(--text-light);
            font-size: 14px;
            max-width: 400px;
            margin: 0 auto;
        }
        
        /* Button Styles */
        .btn-primary {
            background: var(--primary);
            border: none;
            border-radius: 8px;
            padding: 10px 20px;
            font-weight: 600;
            color: white;
            font-size: 14px;
            transition: all 0.2s ease;
        }
        
        .btn-primary:hover {
            background: var(--primary-dark);
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(44, 90, 160, 0.2);
            color: white;
        }
        
        .btn-outline-primary {
            border: 1px solid var(--primary);
            color: var(--primary);
            border-radius: 8px;
            padding: 9px 18px;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.2s ease;
        }
        
        .btn-outline-primary:hover {
            background: var(--primary);
            color: white;
        }
        
        /* Badge Styles */
        .notification-badge {
            position: absolute;
            top: 24px;
            right: 24px;
            background: var(--primary);
            color: white;
            border-radius: 50%;
            width: 8px;
            height: 8px;
        }
        
        /* Responsive Design */
        @media (max-width: 768px) {
            .main-container {
                padding: 20px 15px;
            }
            
            .page-header {
                padding: 20px;
            }
            
            .page-title {
                font-size: 24px;
            }
            
            .notification-header {
                padding: 16px 20px;
                flex-direction: column;
                align-items: flex-start;
            }
            
            .notification-actions {
                width: 100%;
                justify-content: space-between;
            }
            
            .notification-item {
                padding: 16px 20px;
            }
            
            .notification-meta {
                flex-direction: column;
                align-items: flex-start;
            }
        }
        
        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .notification-item {
            animation: fadeIn 0.3s ease;
        }
        
        /* Hover Effects */
        .notification-item {
            transition: all 0.2s ease;
        }
        
        .notification-item:hover .notification-title {
            color: var(--primary);
        }
        
        .mark-read-btn {
            opacity: 0;
            transition: opacity 0.2s ease;
        }
        
        .notification-item:hover .mark-read-btn {
            opacity: 1;
        }
    </style>
</head>
<body>
    <div class="main-container">
        <!-- Back Button -->
        <a href="<?= base_url() ?>" class="back-btn">
            <i class="fas fa-arrow-left"></i>
            Back to Dashboard
        </a>
        
        <!-- Page Header -->
        <div class="page-header">
            <div>
                <h1 class="page-title">
                    <i class="fas fa-bell me-2 text-primary"></i>
                    Notifications
                </h1>
                <p class="page-subtitle">
                    Stay updated with the latest activities and important alerts
                </p>
            </div>
        </div>
        
        <!-- Notifications Container -->
        <div class="notification-container">
            <div class="notification-header">
                <div>
                    <span class="text-muted">Total Notifications:</span>
                    <span class="notification-count ms-2">
                        <?= count($notifications) ?>
                    </span>
                    <?php 
                    $unreadCount = array_reduce($notifications, function($carry, $item) {
                        return $carry + (!$item['is_read'] ? 1 : 0);
                    }, 0);
                    ?>
                    <?php if($unreadCount > 0): ?>
                    <span class="ms-3 text-muted">Unread:</span>
                    <span class="notification-count ms-2 bg-danger">
                        <?= $unreadCount ?>
                    </span>
                    <?php endif; ?>
                </div>
                
                <div class="notification-actions">
                    <?php if($unreadCount > 0): ?>
                    <button class="btn btn-outline-primary" onclick="markAllAsRead()">
                        <i class="fas fa-check-double me-2"></i>
                        Mark all as read
                    </button>
                    <?php endif; ?>
                    
                    <div class="dropdown">
                        <button class="btn btn-outline-secondary dropdown-toggle" type="button" 
                                data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-filter me-2"></i>
                            Filter
                        </button>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="?filter=all">All Notifications</a></li>
                            <li><a class="dropdown-item" href="?filter=unread">Unread Only</a></li>
                            <li><a class="dropdown-item" href="?filter=read">Read Only</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="?type=success">Success</a></li>
                            <li><a class="dropdown-item" href="?type=warning">Warning</a></li>
                            <li><a class="dropdown-item" href="?type=error">Error</a></li>
                            <li><a class="dropdown-item" href="?type=info">Info</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            
            <!-- Notifications List -->
            <?php if (empty($notifications)): ?>
                <div class="notification-empty">
                    <div class="empty-icon">
                        <i class="fas fa-bell-slash"></i>
                    </div>
                    <h3 class="empty-title">No Notifications</h3>
                    <p class="empty-subtitle">
                        You're all caught up! There are no notifications to display at the moment.
                    </p>
                </div>
            <?php else: ?>
                <?php foreach ($notifications as $notification): ?>
                    <a href="<?= $notification['action_url'] ? base_url($notification['action_url']) : 'javascript:void(0)' ?>" 
                       class="notification-item <?= $notification['is_read'] ? 'read' : 'unread' ?>"
                       onclick="<?= !$notification['is_read'] ? "markAsRead({$notification['notification_id']}, this)" : '' ?>"
                       id="notification-<?= $notification['notification_id'] ?>">
                        
                        <div class="d-flex align-items-start">
                            <!-- Notification Icon -->
                            <div class="notification-icon <?= $notification['type'] ?> me-3">
                                <i class="fas fa-<?= getNotificationIcon($notification['type']) ?>"></i>
                            </div>
                            
                            <!-- Notification Content -->
                            <div class="notification-content">
                                <div class="d-flex justify-content-between align-items-start">
                                    <h5 class="notification-title">
                                        <?= esc($notification['title']) ?>
                                        <?php if(!$notification['is_read']): ?>
                                            <span class="badge bg-primary" style="font-size: 10px; padding: 2px 6px;">NEW</span>
                                        <?php endif; ?>
                                    </h5>
                                    
                                    <?php if(!$notification['is_read']): ?>
                                    <button type="button" 
                                            class="btn btn-sm btn-outline-primary mark-read-btn"
                                            onclick="event.stopPropagation(); markAsRead(<?= $notification['notification_id'] ?>, this.closest('.notification-item'))">
                                        <small>Mark as read</small>
                                    </button>
                                    <?php endif; ?>
                                </div>
                                
                                <p class="notification-message">
                                    <?= esc($notification['message']) ?>
                                </p>
                                
                                <div class="notification-meta">
                                    <span class="notification-time">
                                        <i class="far fa-clock me-1"></i>
                                        <?= time_ago($notification['created_at']) ?>
                                    </span>
                                    
                                    <?php if ($notification['action_url']): ?>
                                        <span class="notification-action">
                                            <i class="fas fa-external-link-alt me-1"></i>
                                            View Details
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        
                        <?php if(!$notification['is_read']): ?>
                            <div class="notification-badge"></div>
                        <?php endif; ?>
                    </a>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        
        <!-- Pagination (Optional) -->
        <?php if(isset($pager)): ?>
        <nav aria-label="Notification navigation" class="mt-4">
            <?= $pager->links() ?>
        </nav>
        <?php endif; ?>
    </div>

    <!-- Bootstrap & jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Toast for feedback -->
    <div class="toast-container position-fixed top-0 end-0 p-3" style="z-index: 1060">
        <div id="successToast" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="toast-header bg-success text-white">
                <i class="fas fa-check-circle me-2"></i>
                <strong class="me-auto">Success</strong>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast"></button>
            </div>
            <div class="toast-body">
                Notification marked as read
            </div>
        </div>
        
        <div id="allReadToast" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="toast-header bg-primary text-white">
                <i class="fas fa-check-double me-2"></i>
                <strong class="me-auto">Success</strong>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast"></button>
            </div>
            <div class="toast-body">
                All notifications marked as read
            </div>
        </div>
    </div>

    <script>
    function markAsRead(notificationId, element) {
        $.ajax({
            url: '<?= base_url('notifications/markAsRead') ?>/' + notificationId,
            method: 'POST',
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    // Update UI
                    $(element).removeClass('unread').addClass('read');
                    $(element).find('.badge.bg-primary').remove();
                    $(element).find('.notification-badge').remove();
                    $(element).find('.mark-read-btn').remove();
                    
                    // Update unread count
                    updateUnreadCount(-1);
                    
                    // Show toast
                    var toast = new bootstrap.Toast(document.getElementById('successToast'));
                    toast.show();
                    
                    // If there's an action URL, follow it after a short delay
                    var href = $(element).attr('href');
                    if (href && href !== 'javascript:void(0)') {
                        setTimeout(function() {
                            window.location.href = href;
                        }, 300);
                    }
                }
            },
            error: function() {
                alert('Failed to mark notification as read. Please try again.');
            }
        });
    }
    
    function markAllAsRead() {
        if (confirm('Are you sure you want to mark all notifications as read?')) {
            $.ajax({
                url: '<?= base_url('notifications/markAllAsRead') ?>',
                method: 'POST',
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        // Update all notifications to read state
                        $('.notification-item').each(function() {
                            $(this).removeClass('unread').addClass('read');
                            $(this).find('.badge.bg-primary').remove();
                            $(this).find('.notification-badge').remove();
                            $(this).find('.mark-read-btn').remove();
                        });
                        
                        // Reset unread count
                        updateUnreadCount('all');
                        
                        // Show success toast
                        var toast = new bootstrap.Toast(document.getElementById('allReadToast'));
                        toast.show();
                        
                        // Reload page after 2 seconds
                        setTimeout(function() {
                            window.location.reload();
                        }, 2000);
                    }
                },
                error: function() {
                    alert('Failed to mark all notifications as read. Please try again.');
                }
            });
        }
    }
    
    function updateUnreadCount(change) {
        var $unreadCount = $('.notification-count.bg-danger');
        
        if (change === 'all') {
            $unreadCount.remove();
            return;
        }
        
        if ($unreadCount.length > 0) {
            var currentCount = parseInt($unreadCount.text());
            var newCount = currentCount + change;
            
            if (newCount <= 0) {
                $unreadCount.remove();
            } else {
                $unreadCount.text(newCount);
            }
        }
    }
    
    // Keyboard shortcuts
    $(document).keydown(function(e) {
        // Alt + M to mark all as read
        if (e.altKey && e.key === 'm') {
            markAllAsRead();
            e.preventDefault();
        }
        
        // Escape key to go back
        if (e.key === 'Escape') {
            window.location.href = '<?= base_url() ?>';
        }
    });
    
    // Auto-refresh notifications every 30 seconds
    setInterval(function() {
        $.get('<?= base_url('notifications/countUnread') ?>', function(count) {
            var currentCount = parseInt($('.notification-count.bg-danger').text()) || 0;
            if (count != currentCount) {
                // Reload if count changed
                window.location.reload();
            }
        });
    }, 30000);
    
    // Highlight new notifications
    $(document).ready(function() {
        $('.notification-item.unread').each(function(i) {
            $(this).css('animation-delay', (i * 0.05) + 's');
        });
    });
    </script>
</body>
</html>

<?php
function getNotificationIcon($type) {
    $icons = [
        'info' => 'info-circle',
        'success' => 'check-circle',
        'warning' => 'exclamation-triangle',
        'error' => 'times-circle',
        'system' => 'cog'
    ];
    return $icons[$type] ?? 'bell';
}

function time_ago($datetime) {
    $time = strtotime($datetime);
    $now = time();
    $diff = $now - $time;
    
    if ($diff < 60) {
        return 'Just now';
    } elseif ($diff < 3600) {
        $minutes = floor($diff / 60);
        return $minutes . ' minute' . ($minutes > 1 ? 's' : '') . ' ago';
    } elseif ($diff < 86400) {
        $hours = floor($diff / 3600);
        return $hours . ' hour' . ($hours > 1 ? 's' : '') . ' ago';
    } elseif ($diff < 604800) {
        $days = floor($diff / 86400);
        return $days . ' day' . ($days > 1 ? 's' : '') . ' ago';
    } else {
        return date('M d, Y', $time);
    }
}
?>