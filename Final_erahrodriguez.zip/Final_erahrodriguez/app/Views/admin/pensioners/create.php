<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>

<div class="container-fluid px-3 px-md-4 py-4">
    <div class="row justify-content-center">
        <div class="col-12 col-lg-10">
            <div class="content-card">
                <div class="card-header">
                    <h5 class="card-title">
                        <i class="fas fa-user-plus me-2"></i>
                        <?= isset($pensioner) ? 'Edit Pensioner' : 'Register New Pensioner' ?>
                    </h5>
                </div>
                
                <form action="<?= isset($pensioner) ? site_url('admin/pensioners/update/' . $pensioner['pensioner_id']) : site_url('admin/pensioners/store') ?>" method="POST" id="pensionerForm">
                    <?= csrf_field() ?>
                    
                    <?php if(isset($pensioner)): ?>
                        <input type="hidden" name="_method" value="PUT">
                    <?php endif; ?>
                    
                    <!-- Personal Information -->
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <h6 class="mb-3"><i class="fas fa-id-card me-2"></i>Personal Information</h6>
                            
                            <div class="mb-3">
                                <label class="form-label">Full Name <span class="text-danger">*</span></label>
                                <input type="text" name="full_name" class="form-control" 
                                       value="<?= old('full_name', $pensioner['full_name'] ?? '') ?>" 
                                       required>
                            </div>
                            
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label">Date of Birth</label>
                                    <input type="date" name="date_of_birth" class="form-control" 
                                           value="<?= old('date_of_birth', $pensioner['date_of_birth'] ?? '') ?>">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">ID Number</label>
                                    <input type="text" name="id_number" class="form-control" 
                                           value="<?= old('id_number', $pensioner['id_number'] ?? '') ?>">
                                </div>
                            </div>
                            
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label">Gender <span class="text-danger">*</span></label>
                                    <select name="gender" class="form-select" required>
                                        <option value="">Select Gender</option>
                                        <option value="male" <?= old('gender', $pensioner['gender'] ?? '') == 'male' ? 'selected' : '' ?>>Male</option>
                                        <option value="female" <?= old('gender', $pensioner['gender'] ?? '') == 'female' ? 'selected' : '' ?>>Female</option>
                                        <option value="other" <?= old('gender', $pensioner['gender'] ?? '') == 'other' ? 'selected' : '' ?>>Other</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Marital Status</label>
                                    <select name="marital_status" class="form-select">
                                        <option value="">Select Status</option>
                                        <option value="single" <?= old('marital_status', $pensioner['marital_status'] ?? '') == 'single' ? 'selected' : '' ?>>Single</option>
                                        <option value="married" <?= old('marital_status', $pensioner['marital_status'] ?? '') == 'married' ? 'selected' : '' ?>>Married</option>
                                        <option value="divorced" <?= old('marital_status', $pensioner['marital_status'] ?? '') == 'divorced' ? 'selected' : '' ?>>Divorced</option>
                                        <option value="widowed" <?= old('marital_status', $pensioner['marital_status'] ?? '') == 'widowed' ? 'selected' : '' ?>>Widowed</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <h6 class="mb-3"><i class="fas fa-address-book me-2"></i>Contact Information</h6>
                            
                            <div class="mb-3">
                                <label class="form-label">Address</label>
                                <textarea name="address" class="form-control" rows="3"><?= old('address', $pensioner['address'] ?? '') ?></textarea>
                            </div>
                            
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label">Contact Number</label>
                                    <input type="tel" name="contact_number" class="form-control" 
                                           value="<?= old('contact_number', $pensioner['contact_number'] ?? '') ?>">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Email Address</label>
                                    <input type="email" name="email" class="form-control" 
                                           value="<?= old('email', $pensioner['email'] ?? '') ?>">
                                </div>
                            </div>
                            
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label">Bank Account</label>
                                    <input type="text" name="bank_account" class="form-control" 
                                           value="<?= old('bank_account', $pensioner['bank_account'] ?? '') ?>">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Bank Name</label>
                                    <input type="text" name="bank_name" class="form-control" 
                                           value="<?= old('bank_name', $pensioner['bank_name'] ?? '') ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Next of Kin Information -->
                    <div class="row mb-4">
                        <div class="col-12">
                            <h6 class="mb-3"><i class="fas fa-user-friends me-2"></i>Next of Kin Information</h6>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Next of Kin Name</label>
                                        <input type="text" name="next_of_kin" class="form-control" 
                                               value="<?= old('next_of_kin', $pensioner['next_of_kin'] ?? '') ?>">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Next of Kin Contact</label>
                                        <input type="tel" name="next_of_kin_contact" class="form-control" 
                                               value="<?= old('next_of_kin_contact', $pensioner['next_of_kin_contact'] ?? '') ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Pension Information -->
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <h6 class="mb-3"><i class="fas fa-piggy-bank me-2"></i>Pension Information</h6>
                            
                            <div class="mb-3">
                                <label class="form-label">Pension Type <span class="text-danger">*</span></label>
                                <select name="pension_type" class="form-select" required>
                                    <option value="">Select Pension Type</option>
                                    <option value="retirement" <?= old('pension_type', $pensioner['pension_type'] ?? '') == 'retirement' ? 'selected' : '' ?>>Retirement</option>
                                    <option value="disability" <?= old('pension_type', $pensioner['pension_type'] ?? '') == 'disability' ? 'selected' : '' ?>>Disability</option>
                                    <option value="survivor" <?= old('pension_type', $pensioner['pension_type'] ?? '') == 'survivor' ? 'selected' : '' ?>>Survivor</option>
                                    <option value="other" <?= old('pension_type', $pensioner['pension_type'] ?? '') == 'other' ? 'selected' : '' ?>>Other</option>
                                </select>
                            </div>
                            
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label">Pension Amount <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <span class="input-group-text">₱</span>
                                        <input type="number" name="pension_amount" class="form-control" step="0.01" min="0"
                                               value="<?= old('pension_amount', $pensioner['pension_amount'] ?? '0.00') ?>" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Pension Start Date</label>
                                    <input type="date" name="pension_start_date" class="form-control" 
                                           value="<?= old('pension_start_date', $pensioner['pension_start_date'] ?? '') ?>">
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <h6 class="mb-3"><i class="fas fa-clipboard-check me-2"></i>Additional Information</h6>
                            
                            <div class="mb-3">
                                <label class="form-label">Status <span class="text-danger">*</span></label>
                                <select name="status" class="form-select" required>
                                    <option value="">Select Status</option>
                                    <option value="active" <?= old('status', $pensioner['status'] ?? '') == 'active' ? 'selected' : '' ?>>Active</option>
                                    <option value="suspended" <?= old('status', $pensioner['status'] ?? '') == 'suspended' ? 'selected' : '' ?>>Suspended</option>
                                    <option value="deceased" <?= old('status', $pensioner['status'] ?? '') == 'deceased' ? 'selected' : '' ?>>Deceased</option>
                                    <option value="inactive" <?= old('status', $pensioner['status'] ?? '') == 'inactive' ? 'selected' : '' ?>>Inactive</option>
                                </select>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Medical Conditions</label>
                                <textarea name="medical_conditions" class="form-control" rows="2"><?= old('medical_conditions', $pensioner['medical_conditions'] ?? '') ?></textarea>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Notes</label>
                                <textarea name="notes" class="form-control" rows="2"><?= old('notes', $pensioner['notes'] ?? '') ?></textarea>
                            </div>
                        </div>
                    </div>
                    
                    <div class="alert alert-info">
                        <div class="d-flex">
                            <i class="fas fa-info-circle me-3 mt-1"></i>
                            <div>
                                <h6 class="alert-heading">Important Information</h6>
                                <p class="mb-0">Fields marked with <span class="text-danger">*</span> are required. 
                                Ensure all information is accurate before submitting.</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="d-flex justify-content-between mt-4">
                        <a href="<?= site_url('admin/pensioners') ?>" class="btn btn-outline-secondary">
                            <i class="fas fa-arrow-left me-2"></i>Cancel
                        </a>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i>
                            <?= isset($pensioner) ? 'Update Pensioner' : 'Save Pensioner' ?>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>

<?= $this->section('custom_js') ?>
<script>
$(document).ready(function() {
    // Form validation
    $('#pensionerForm').on('submit', function(e) {
        let isValid = true;
        
        // Check required fields
        $(this).find('[required]').each(function() {
            if (!$(this).val().trim()) {
                $(this).addClass('is-invalid');
                isValid = false;
            } else {
                $(this).removeClass('is-invalid');
            }
        });
        
        if (!isValid) {
            e.preventDefault();
            alert('Please fill in all required fields.');
        }
    });
    
    // Remove validation on input
    $('input, select, textarea').on('input change', function() {
        $(this).removeClass('is-invalid');
    });
});
</script>
<?= $this->endSection() ?>