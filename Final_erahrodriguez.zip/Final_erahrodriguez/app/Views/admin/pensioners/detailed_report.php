<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title ?> | Pensioner Association Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        .filter-section {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .report-header {
            background: #e9ecef;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <?= $this->include('admin/layout/header') ?>
    
    <div class="container-fluid">
        <div class="row">
            <?= $this->include('admin/layout/sidebar') ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2"><?= $page_title ?></h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <div class="btn-group me-2">
                            <a href="<?= site_url('admin/pensioners/report') ?>" class="btn btn-sm btn-outline-secondary">
                                <i class="bi bi-graph-up"></i> Analytics Dashboard
                            </a>
                            <button onclick="window.print()" class="btn btn-sm btn-outline-primary">
                                <i class="bi bi-printer"></i> Print
                            </button>
                            <a href="<?= site_url('admin/pensioners/export_excel?' . http_build_query($filters)) ?>" class="btn btn-sm btn-outline-success">
                                <i class="bi bi-file-excel"></i> Export Excel
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Filters -->
                <div class="filter-section">
                    <form method="get" class="row g-3">
                        <div class="col-md-3">
                            <label class="form-label">Pension Type</label>
                            <select name="pension_type" class="form-select">
                                <?php foreach ($pension_types as $value => $label): ?>
                                    <option value="<?= $value ?>" <?= $filters['pension_type'] == $value ? 'selected' : '' ?>>
                                        <?= $label ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Start Date</label>
                            <input type="date" name="start_date" class="form-control" value="<?= $filters['start_date'] ?>">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">End Date</label>
                            <input type="date" name="end_date" class="form-control" value="<?= $filters['end_date'] ?>">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Search</label>
                            <input type="text" name="search" class="form-control" placeholder="Search..." value="<?= $filters['search'] ?>">
                        </div>
                        <div class="col-12">
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-filter"></i> Apply Filters
                            </button>
                            <a href="<?= site_url('admin/pensioners/detailed_report') ?>" class="btn btn-secondary">
                                <i class="bi bi-x-circle"></i> Clear Filters
                            </a>
                        </div>
                    </form>
                </div>

                <!-- Report Summary -->
                <div class="report-header">
                    <h5>Report Summary</h5>
                    <p class="mb-0">
                        Found <?= count($pensioners) ?> pensioner(s)
                        <?php if ($filters['pension_type']): ?>
                            with pension type: <strong><?= $pension_types[$filters['pension_type']] ?></strong>
                        <?php endif; ?>
                        <?php if ($filters['start_date'] && $filters['end_date']): ?>
                            between <strong><?= $filters['start_date'] ?></strong> and <strong><?= $filters['end_date'] ?></strong>
                        <?php endif; ?>
                    </p>
                </div>

                <!-- Report Table -->
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Full Name</th>
                                        <th>Date of Birth</th>
                                        <th>Age</th>
                                        <th>Address</th>
                                        <th>Contact</th>
                                        <th>Email</th>
                                        <th>Pension Type</th>
                                        <th>Created Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($pensioners)): ?>
                                        <tr>
                                            <td colspan="9" class="text-center">No records found</td>
                                        </tr>
                                    <?php else: ?>
                                        <?php foreach ($pensioners as $pensioner): 
                                            $age = date_diff(date_create($pensioner['date_of_birth']), date_create('today'))->y;
                                        ?>
                                            <tr>
                                                <td><?= $pensioner['pensioner_id'] ?></td>
                                                <td><?= $pensioner['full_name'] ?></td>
                                                <td><?= date('M d, Y', strtotime($pensioner['date_of_birth'])) ?></td>
                                                <td><?= $age ?> years</td>
                                                <td><?= $pensioner['address'] ?></td>
                                                <td><?= $pensioner['contact_number'] ?></td>
                                                <td><?= $pensioner['email'] ?></td>
                                                <td>
                                                    <span class="badge bg-info">
                                                        <?= $this->pensionerModel->getPensionTypeLabel($pensioner['pension_type']) ?>
                                                    </span>
                                                </td>
                                                <td><?= date('M d, Y', strtotime($pensioner['created_at'])) ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>