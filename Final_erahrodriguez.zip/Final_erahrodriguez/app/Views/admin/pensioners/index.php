<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>

<div class="container-fluid px-3 px-md-4 py-4">

<div class="container-fluid px-3 px-md-4 py-4">
    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#registerPensionerModal">
            <i class="fas fa-plus-circle me-1"></i>Add New
        </button>
    </div>

    <!-- Stats Cards -->
    <div class="row g-3 mb-4">
        <div class="col-md-3 col-sm-6">
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-users"></i>
                </div>
                <div class="stat-number"><?= $stats['total'] ?? 0 ?></div>
                <div class="stat-label">Total Pensioners</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6">
            <div class="stat-card">
                <div class="stat-icon" style="background: rgba(16, 185, 129, 0.1); color: var(--success);">
                    <i class="fas fa-user-check"></i>
                </div>
                <div class="stat-number"><?= $stats['active'] ?? 0 ?></div>
                <div class="stat-label">Active</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6">
            <div class="stat-card">
                <div class="stat-icon" style="background: rgba(59, 130, 246, 0.1); color: var(--info);">
                    <i class="fas fa-calendar-alt"></i>
                </div>
                <div class="stat-number"><?= $stats['monthly_added'] ?? 0 ?></div>
                <div class="stat-label">This Month</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6">
            <div class="stat-card">
                <div class="stat-icon" style="background: rgba(245, 158, 11, 0.1); color: var(--warning);">
                    <i class="fas fa-money-bill-wave"></i>
                </div>
                <div class="stat-number">₱<?= number_format($stats['total_amount'] ?? 0, 2) ?></div>
                <div class="stat-label">Total Amount</div>
            </div>
        </div>
    </div>
    
    <!-- Pensioners Table -->
    <div class="card border">
        <div class="card-body p-0">
            <?php if(!empty($pensioners)): ?>
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Date of Birth</th>
                                <th>Gender</th>
                                <th>Contact</th>
                                <th>Pension Type</th>
                                <th>Amount</th>
                                <th>Status</th>
                                <th>Created By</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $model = new \App\Models\PensionerModel();
                            foreach($pensioners as $p): 
                                $status = $model->getStatusLabel($p['status']);
                                $pensionType = $model->getPensionTypeLabel($p['pension_type']);
                                $gender = $model->getGenderLabel($p['gender']);
                                $maritalStatus = $model->getMaritalStatusLabel($p['marital_status']);
                            ?>
                                <tr>
                                    <td>#<?= $p['pensioner_id'] ?></td>
                                    <td>
                                        <div class="fw-medium"><?= $p['full_name'] ?></div>
                                        <small class="text-muted">ID: <?= $p['id_number'] ?? 'N/A' ?></small>
                                    </td>
                                    <td>
                                        <?= $p['date_of_birth'] ? date('d M Y', strtotime($p['date_of_birth'])) : 'N/A' ?>
                                        <?php if($p['date_of_birth']): ?>
                                        <br><small class="text-muted">
                                            <?php 
                                            $age = floor((time() - strtotime($p['date_of_birth'])) / 31556926);
                                            echo $age . ' years';
                                            ?>
                                        </small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="badge bg-light text-dark"><?= $gender ?></span>
                                        <?php if($maritalStatus): ?>
                                        <br><small class="text-muted"><?= $maritalStatus ?></small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?= $p['contact_number'] ?? 'N/A' ?><br>
                                        <small class="text-muted"><?= $p['email'] ?? '' ?></small>
                                    </td>
                                    <td>
                                        <?php if($p['pension_type'] == 'retirement'): ?>
                                            <span class="badge bg-success-subtle text-success">
                                                <i class="fas fa-user-tie me-1"></i><?= $pensionType ?>
                                            </span>
                                        <?php elseif($p['pension_type'] == 'disability'): ?>
                                            <span class="badge bg-warning-subtle text-warning">
                                                <i class="fas fa-wheelchair me-1"></i><?= $pensionType ?>
                                            </span>
                                        <?php elseif($p['pension_type'] == 'survivor'): ?>
                                            <span class="badge bg-danger-subtle text-danger">
                                                <i class="fas fa-user-injured me-1"></i><?= $pensionType ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-info-subtle text-info">
                                                <i class="fas fa-user me-1"></i><?= $pensionType ?>
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="fw-medium">
                                        ₱<?= number_format($p['pension_amount'] ?? 0, 2) ?>
                                    </td>
                                    <td>
                                        <?php if($p['status'] == 'active'): ?>
                                            <span class="badge bg-success">
                                                <i class="fas fa-check-circle me-1"></i><?= $status['label'] ?>
                                            </span>
                                        <?php elseif($p['status'] == 'suspended'): ?>
                                            <span class="badge bg-warning">
                                                <i class="fas fa-pause-circle me-1"></i><?= $status['label'] ?>
                                            </span>
                                        <?php elseif($p['status'] == 'deceased'): ?>
                                            <span class="badge bg-danger">
                                                <i class="fas fa-times-circle me-1"></i><?= $status['label'] ?>
                                            </span>
                                        <?php elseif($p['status'] == 'inactive'): ?>
                                            <span class="badge bg-secondary">
                                                <i class="fas fa-minus-circle me-1"></i><?= $status['label'] ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-light text-dark"><?= $status['label'] ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <small class="text-muted">User #<?= $p['created_by'] ?? 'System' ?></small>
                                    </td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <a href="<?= site_url('admin/pensioners/edit/' . $p['pensioner_id']) ?>" 
                                               class="btn btn-outline-primary" title="Edit">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="<?= site_url('admin/pensioners/delete/' . $p['pensioner_id']) ?>" 
                                               class="btn btn-outline-danger" title="Delete"
                                               onclick="return confirm('Are you sure you want to delete this pensioner?')">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Pagination -->
                <?php if(isset($pager)): ?>
                <div class="card-footer">
                    <?= $pager->links() ?>
                </div>
                <?php endif; ?>
            <?php else: ?>
                <div class="text-center py-5">
                    <i class="fas fa-people-carry text-muted" style="font-size: 3rem;"></i>
                    <h5 class="fw-semibold mt-3">No Pensioners Found</h5>
                    <p class="text-muted mb-4">There are no pensioners registered in the system yet.</p>
                    <a href="<?= site_url('admin/pensioners/create') ?>" class="btn btn-primary">
                        <i class="fas fa-plus-circle me-1"></i>Add First Pensioner
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
/* Mobile Responsive Styles - Added to make the page mobile friendly */
@media (max-width: 768px) {
    /* Fix duplicate container padding */
    .container-fluid.px-3.px-md-4.py-4 .container-fluid.px-3.px-md-4.py-4 {
        padding: 0 !important;
    }
    
    /* Adjust main container padding */
    .container-fluid.px-3.px-md-4.py-4 {
        padding: 1rem !important;
    }
    
    /* Page header adjustments */
    .d-flex.justify-content-between.align-items-center.mb-4 {
        flex-direction: column;
        align-items: stretch !important;
        gap: 1rem;
    }
    
    .d-flex.justify-content-between.align-items-center.mb-4 > button {
        width: 100%;
    }
    
    /* Stats cards - 2 per row on mobile */
    .row.g-3.mb-4 {
        margin-left: -0.5rem !important;
        margin-right: -0.5rem !important;
    }
    
    .row.g-3.mb-4 > .col-md-3.col-sm-6 {
        padding-left: 0.5rem !important;
        padding-right: 0.5rem !important;
        width: 50% !important;
        flex: 0 0 50% !important;
        max-width: 50% !important;
    }
    
    /* On very small screens, stack stats cards */
    @media (max-width: 576px) {
        .row.g-3.mb-4 > .col-md-3.col-sm-6 {
            width: 100% !important;
            flex: 0 0 100% !important;
            max-width: 100% !important;
        }
    }
    
    /* Make table horizontally scrollable */
    .table-responsive {
        margin: 0 -1rem !important;
        padding: 0 1rem !important;
        width: calc(100% + 2rem) !important;
        overflow-x: auto !important;
        -webkit-overflow-scrolling: touch !important;
    }
    
    .table.table-hover.mb-0 {
        min-width: 1000px !important;
        font-size: 0.875rem !important;
    }
    
    /* Compact table cells */
    .table.table-hover.mb-0 th,
    .table.table-hover.mb-0 td {
        padding: 0.5rem !important;
    }
    
    /* Make badges more compact */
    .badge {
        font-size: 0.75rem !important;
        padding: 0.25em 0.5em !important;
    }
    
    /* Adjust action buttons */
    .btn-group.btn-group-sm {
        display: flex !important;
    }
    
    .btn-group.btn-group-sm .btn {
        padding: 0.25rem 0.5rem !important;
        font-size: 0.75rem !important;
    }
    
    /* Empty state adjustments */
    .text-center.py-5 {
        padding: 2rem 1rem !important;
    }
    
    .text-center.py-5 i {
        font-size: 2.5rem !important;
    }
    
    /* Pagination adjustments */
    .card-footer {
        padding: 1rem !important;
    }
    
    .pagination {
        flex-wrap: wrap;
        justify-content: center;
    }
    
    .pagination .page-link {
        padding: 0.375rem 0.5rem !important;
        font-size: 0.875rem !important;
        margin: 0.125rem !important;
    }
    
    /* Touch-friendly tap targets */
    .btn,
    .btn-group .btn,
    .pagination .page-link {
        min-height: 44px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
    }
    
    .btn-group.btn-group-sm .btn {
        min-height: 36px;
        min-width: 36px;
    }
}

/* Medium screens (tablets) */
@media (max-width: 992px) and (min-width: 769px) {
    .table.table-hover.mb-0 {
        font-size: 0.9rem !important;
    }
    
    /* Hide less important columns on tablets */
    .table.table-hover.mb-0 th:nth-child(9),
    .table.table-hover.mb-0 td:nth-child(9) {
        display: none;
    }
}

/* Small phones */
@media (max-width: 480px) {
    /* Hide more columns on very small screens */
    .table.table-hover.mb-0 th:nth-child(1),
    .table.table-hover.mb-0 td:nth-child(1),
    .table.table-hover.mb-0 th:nth-child(5),
    .table.table-hover.mb-0 td:nth-child(5),
    .table.table-hover.mb-0 th:nth-child(9),
    .table.table-hover.mb-0 td:nth-child(9) {
        display: none;
    }
    
    /* Adjust stat cards for very small screens */
    .stat-card {
        padding: 0.75rem !important;
    }
    
    .stat-number {
        font-size: 1.25rem !important;
    }
    
    .stat-label {
        font-size: 0.75rem !important;
    }
}

/* Ensure all icons scale properly */
.fas, .fa {
    max-width: 100%;
    height: auto;
}
</style>

<?= $this->endSection() ?>