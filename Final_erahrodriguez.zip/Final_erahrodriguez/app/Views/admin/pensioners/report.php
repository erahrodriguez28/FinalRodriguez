<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>

<div class="container-fluid">
    <!-- Year Filter -->
    <div class="filter-bar mb-4">
        <div class="row g-3 align-items-center">
            <div class="col-md-4">
                <label class="form-label"><i class="fas fa-filter me-1"></i> Select Analysis Year</label>
                <select name="year" class="form-select" onchange="this.form.submit()">
                    <?php foreach ($available_years as $available_year): ?>
                        <option value="<?= $available_year ?>" <?= $selected_year == $available_year ? 'selected' : '' ?>>
                            <?= $available_year ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-4">
                <div class="form-text">
                    <i class="fas fa-chart-line me-1"></i>
                    Showing pension analysis for <?= $selected_year ?>
                </div>
            </div>
            <div class="col-md-4 text-md-end text-start mt-md-0 mt-2">
                <div class="form-text">
                    <i class="fas fa-database me-1"></i>
                    Last updated: <?= date('H:i:s') ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Summary Statistics Cards -->
    <div class="row mb-4">
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-users"></i>
                </div>
                <div class="stat-number"><?= $yearly_summary['total_pensioners'] ?></div>
                <div class="stat-label">Total Pensioners</div>
                <div class="stat-trend trend-up">
                    <i class="fas fa-calendar me-1"></i><?= $selected_year ?>
                </div>
            </div>
        </div>
        
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="stat-card">
                <div class="stat-icon" style="background: rgba(16, 185, 129, 0.1); color: var(--success);">
                    <i class="fas fa-user-tie"></i>
                </div>
                <div class="stat-number"><?= $yearly_summary['retirement_count'] ?></div>
                <div class="stat-label">Retirement</div>
                <div class="stat-trend">
                    <?php 
                    $retirementPercent = $yearly_summary['total_pensioners'] > 0 ? 
                        round(($yearly_summary['retirement_count'] / $yearly_summary['total_pensioners']) * 100, 1) : 0;
                    ?>
                    <i class="fas fa-percentage me-1"></i><?= $retirementPercent ?>%
                </div>
            </div>
        </div>
        
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="stat-card">
                <div class="stat-icon" style="background: rgba(59, 130, 246, 0.1); color: var(--info);">
                    <i class="fas fa-wheelchair"></i>
                </div>
                <div class="stat-number"><?= $yearly_summary['disability_count'] ?></div>
                <div class="stat-label">Disability</div>
                <div class="stat-trend">
                    <?php 
                    $disabilityPercent = $yearly_summary['total_pensioners'] > 0 ? 
                        round(($yearly_summary['disability_count'] / $yearly_summary['total_pensioners']) * 100, 1) : 0;
                    ?>
                    <i class="fas fa-percentage me-1"></i><?= $disabilityPercent ?>%
                </div>
            </div>
        </div>
        
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="stat-card">
                <div class="stat-icon" style="background: rgba(245, 158, 11, 0.1); color: var(--warning);">
                    <i class="fas fa-user-injured"></i>
                </div>
                <div class="stat-number"><?= $yearly_summary['survivor_count'] ?></div>
                <div class="stat-label">Survivor</div>
                <div class="stat-trend">
                    <?php 
                    $survivorPercent = $yearly_summary['total_pensioners'] > 0 ? 
                        round(($yearly_summary['survivor_count'] / $yearly_summary['total_pensioners']) * 100, 1) : 0;
                    ?>
                    <i class="fas fa-percentage me-1"></i><?= $survivorPercent ?>%
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content Section -->
    <div class="row">
        <!-- Geographic Distribution -->
        <div class="col-lg-6 mb-4">
            <div class="content-card">
                <div class="card-header d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center">
                    <h5 class="card-title mb-2 mb-md-0">
                        <i class="fas fa-map-marked-alt me-2"></i>Geographic Distribution
                    </h5>
                    <span class="badge badge-pensioner">Regional Analysis</span>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th class="border-0"><i class="fas fa-location-dot me-1"></i> Location</th>
                                    <th class="text-end border-0">Pensioners</th>
                                    <th class="text-end border-0 d-none d-md-table-cell">Percentage</th>
                                    <th class="text-center border-0 d-none d-lg-table-cell">Distribution</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $totalLocation = array_sum(array_column($location_stats, 'count'));
                                foreach ($location_stats as $index => $location): 
                                    $locPercent = $totalLocation > 0 ? round(($location['count'] / $totalLocation) * 100, 1) : 0;
                                ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <span class="badge bg-secondary me-2 d-none d-sm-inline">#<?= $index + 1 ?></span>
                                                <i class="fas fa-city me-2" style="color: var(--primary);"></i>
                                                <span class="fw-medium text-truncate" style="max-width: 150px;"><?= $location['city'] ?? 'Unknown Region' ?></span>
                                            </div>
                                        </td>
                                        <td class="text-end">
                                            <span class="fw-bold"><?= $location['count'] ?></span>
                                            <small class="text-muted d-block d-md-none"><?= $locPercent ?>%</small>
                                        </td>
                                        <td class="text-end d-none d-md-table-cell">
                                            <span class="fw-bold text-primary"><?= $locPercent ?>%</span>
                                        </td>
                                        <td class="d-none d-lg-table-cell">
                                            <div class="progress" style="height: 10px;">
                                                <div class="progress-bar" 
                                                     role="progressbar" 
                                                     style="width: <?= $locPercent ?>%; background-color: var(--primary);"
                                                     aria-valuenow="<?= $locPercent ?>" 
                                                     aria-valuemin="0" 
                                                     aria-valuemax="100">
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                            <?php if($totalLocation > 0): ?>
                            <tfoot class="table-light">
                                <tr>
                                    <td class="fw-bold border-0"><i class="fas fa-total me-1"></i> Total Locations</td>
                                    <td class="text-end fw-bold border-0"><?= $totalLocation ?></td>
                                    <td class="text-end fw-bold border-0 d-none d-md-table-cell">100%</td>
                                    <td class="d-none d-lg-table-cell border-0">
                                        <div class="progress" style="height: 10px;">
                                            <div class="progress-bar bg-success" role="progressbar" style="width: 100%"></div>
                                        </div>
                                    </td>
                                </tr>
                            </tfoot>
                            <?php endif; ?>
                        </table>
                    </div>
                    <?php if($totalLocation > 0): ?>
                    <div class="mt-3 pt-3 border-top">
                        <div class="d-flex align-items-center">
                            <i class="fas fa-info-circle fa-lg me-3 text-primary d-none d-md-block"></i>
                            <div>
                                <small class="text-muted">
                                    Analysis covers <strong><?= count($location_stats) ?></strong> regions with 
                                    <strong><?= $totalLocation ?></strong> total pensioners in <?= $selected_year ?>
                                </small>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Pension Type Analysis -->
        <div class="col-lg-6 mb-4">
            <div class="content-card">
                <div class="card-header d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center">
                    <h5 class="card-title mb-2 mb-md-0">
                        <i class="fas fa-chart-pie me-2"></i>Pension Type Analysis
                    </h5>
                    <span class="badge badge-pensioner">Category Breakdown</span>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th class="border-0">Pension Category</th>
                                    <th class="text-center border-0">Count</th>
                                    <th class="text-center border-0 d-none d-md-table-cell">Share</th>
                                    <th class="text-center border-0 d-none d-lg-table-cell">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $total = array_sum(array_column($pension_type_stats, 'count'));
                                foreach ($pension_type_stats as $stat): 
                                    $percentage = $total > 0 ? round(($stat['count'] / $total) * 100, 1) : 0;
                                    $icons = [
                                        'retirement' => ['icon' => 'user-tie', 'color' => 'var(--success)'],
                                        'disability' => ['icon' => 'wheelchair', 'color' => 'var(--info)'],
                                        'survivor' => ['icon' => 'user-injured', 'color' => 'var(--warning)'],
                                        'other' => ['icon' => 'user', 'color' => 'var(--secondary)']
                                    ];
                                    $iconData = $icons[$stat['pension_type']] ?? ['icon' => 'user', 'color' => 'var(--secondary)'];
                                ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="icon-circle me-3 d-none d-md-flex" style="background-color: <?= $iconData['color'] ?>20; color: <?= $iconData['color'] ?>;">
                                                    <i class="fas fa-<?= $iconData['icon'] ?>"></i>
                                                </div>
                                                <div>
                                                    <div class="fw-medium">
                                                        <?php
                                                        echo match($stat['pension_type']) {
                                                            'retirement' => 'Retirement',
                                                            'disability' => 'Disability',
                                                            'survivor' => 'Survivor',
                                                            'other' => 'Other',
                                                            default => 'Unknown'
                                                        };
                                                        ?>
                                                    </div>
                                                    <small class="text-muted d-none d-md-block">Pension category</small>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="text-center align-middle">
                                            <span class="fw-bold" style="font-size: 1.25rem;"><?= $stat['count'] ?></span>
                                        </td>
                                        <td class="text-center align-middle d-none d-md-table-cell">
                                            <div class="d-flex flex-column align-items-center">
                                                <span class="fw-bold text-primary"><?= $percentage ?>%</span>
                                                <div class="progress mt-1" style="width: 60px; height: 6px;">
                                                    <div class="progress-bar" 
                                                         style="width: <?= $percentage ?>%; background-color: <?= $iconData['color'] ?>;"></div>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="text-center align-middle d-none d-lg-table-cell">
                                            <?php if($percentage > 40): ?>
                                                <span class="badge bg-success py-1 px-2">
                                                    <i class="fas fa-chart-line me-1"></i>Dominant
                                                </span>
                                            <?php elseif($percentage > 20): ?>
                                                <span class="badge bg-info py-1 px-2">
                                                    <i class="fas fa-balance-scale me-1"></i>Significant
                                                </span>
                                            <?php elseif($percentage > 10): ?>
                                                <span class="badge bg-warning py-1 px-2">
                                                    <i class="fas fa-chart-bar me-1"></i>Moderate
                                                </span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary py-1 px-2">
                                                    <i class="fas fa-chart-area me-1"></i>Minor
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                            <?php if($total > 0): ?>
                            <tfoot class="table-light">
                                <tr>
                                    <td class="fw-bold border-0"><i class="fas fa-total me-1"></i> Total Analysis</td>
                                    <td class="text-center fw-bold border-0" style="font-size: 1.25rem;"><?= $total ?></td>
                                    <td class="text-center fw-bold border-0 d-none d-md-table-cell" style="font-size: 1.25rem;">100%</td>
                                    <td class="text-center border-0 d-none d-lg-table-cell">
                                        <span class="badge bg-primary py-1 px-2">
                                            <i class="fas fa-chart-pie me-1"></i>Complete
                                        </span>
                                    </td>
                                </tr>
                            </tfoot>
                            <?php endif; ?>
                        </table>
                    </div>
                    
                    <!-- Mobile Insights -->
                    <div class="mt-3 d-block d-md-none">
                        <?php 
                        $largestType = '';
                        $largestCount = 0;
                        foreach ($pension_type_stats as $stat) {
                            if ($stat['count'] > $largestCount) {
                                $largestCount = $stat['count'];
                                $largestType = $stat['pension_type'];
                            }
                        }
                        $largestTypeLabel = match($largestType) {
                            'retirement' => 'Retirement',
                            'disability' => 'Disability',
                            'survivor' => 'Survivor',
                            'other' => 'Other',
                            default => 'No Data'
                        };
                        $largestPercent = $total > 0 ? round(($largestCount / $total) * 100, 1) : 0;
                        ?>
                        <div class="alert alert-primary">
                            <div class="d-flex">
                                <div class="flex-shrink-0">
                                    <i class="fas fa-lightbulb"></i>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <h6 class="alert-heading mb-1">Key Insight</h6>
                                    <p class="mb-0 small">
                                        <strong><?= $largestTypeLabel ?></strong> is largest with <?= $largestPercent ?>% (<?= $largestCount ?>)
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Desktop Insights -->
                    <div class="mt-4 d-none d-md-block">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <div class="card border-primary h-100">
                                    <div class="card-body">
                                        <h6 class="card-title text-primary mb-3">
                                            <i class="fas fa-lightbulb me-2"></i>Key Insight
                                        </h6>
                                        <?php 
                                        $largestType = '';
                                        $largestCount = 0;
                                        foreach ($pension_type_stats as $stat) {
                                            if ($stat['count'] > $largestCount) {
                                                $largestCount = $stat['count'];
                                                $largestType = $stat['pension_type'];
                                            }
                                        }
                                        $largestTypeLabel = match($largestType) {
                                            'retirement' => 'Retirement Pension',
                                            'disability' => 'Disability Pension',
                                            'survivor' => 'Survivor Pension',
                                            'other' => 'Other Pension',
                                            default => 'No Data'
                                        };
                                        $largestPercent = $total > 0 ? round(($largestCount / $total) * 100, 1) : 0;
                                        ?>
                                        <p class="card-text small">
                                            <strong><?= $largestTypeLabel ?></strong> is the predominant category, 
                                            comprising <strong><?= $largestPercent ?>%</strong> of all pensioners 
                                            with <strong><?= $largestCount ?></strong> individuals.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="card border-info h-100">
                                    <div class="card-body">
                                        <h6 class="card-title text-info mb-3">
                                            <i class="fas fa-chart-bar me-2"></i>Analysis Summary
                                        </h6>
                                        <ul class="list-unstyled mb-0 small">
                                            <li class="mb-2">
                                                <i class="fas fa-calendar-check me-2 text-success"></i>
                                                <span class="text-muted">Year:</span> <strong><?= $selected_year ?></strong>
                                            </li>
                                            <li class="mb-2">
                                                <i class="fas fa-users me-2 text-primary"></i>
                                                <span class="text-muted">Total:</span> <strong><?= $total ?></strong> pensioners
                                            </li>
                                            <li>
                                                <i class="fas fa-layer-group me-2 text-warning"></i>
                                                <span class="text-muted">Categories:</span> <strong><?= count($pension_type_stats) ?></strong>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Data Quality Summary -->
    <div class="content-card mt-4">
        <div class="card-header">
            <h5 class="card-title mb-0"><i class="fas fa-clipboard-check me-2"></i>Data Quality & Summary</h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-4 mb-3 mb-md-0">
                    <div class="d-flex align-items-center">
                        <div class="icon-circle bg-success text-white me-3 flex-shrink-0">
                            <i class="fas fa-check-circle"></i>
                        </div>
                        <div>
                            <h6 class="mb-0">Data Accuracy</h6>
                            <small class="text-muted">Verified records</small>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3 mb-md-0">
                    <div class="d-flex align-items-center">
                        <div class="icon-circle bg-info text-white me-3 flex-shrink-0">
                            <i class="fas fa-sync-alt"></i>
                        </div>
                        <div>
                            <h6 class="mb-0">Real-time Updates</h6>
                            <small class="text-muted">Live synchronization</small>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="d-flex align-items-center">
                        <div class="icon-circle bg-primary text-white me-3 flex-shrink-0">
                            <i class="fas fa-shield-alt"></i>
                        </div>
                        <div>
                            <h6 class="mb-0">Security Compliance</h6>
                            <small class="text-muted">Data Protection</small>
                        </div>
                    </div>
                </div>
            </div>
            
            <hr class="my-4">
            
            <div class="alert alert-light">
                <div class="d-flex flex-column flex-md-row align-items-start align-items-md-center">
                    <div class="flex-shrink-0 mb-3 mb-md-0">
                        <i class="fas fa-file-excel fa-2x text-success"></i>
                    </div>
                    <div class="flex-grow-1 ms-md-3">
                        <h6 class="alert-heading">Export Options Available</h6>
                        <p class="mb-2 small">
                            This report can be exported to Excel format for further analysis or sharing.
                            Click the "Export to Excel" button to download the complete dataset.
                        </p>
                        <div class="small text-muted">
                            <i class="fas fa-clock me-1"></i>
                            Generated on <?= date('F j, Y \a\t H:i:s') ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.icon-circle {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 18px;
}

.table tbody tr:hover {
    background-color: rgba(44, 90, 160, 0.05);
    transition: background-color 0.2s ease;
}

.stat-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.08);
    transition: all 0.3s ease;
}

/* Mobile optimizations */
@media (max-width: 768px) {
    .stat-card {
        padding: 15px;
    }
    
    .stat-number {
        font-size: 24px;
    }
    
    .stat-label {
        font-size: 12px;
    }
    
    .content-card {
        padding: 20px;
    }
    
    .table {
        font-size: 14px;
    }
    
    .icon-circle {
        width: 32px;
        height: 32px;
        font-size: 14px;
    }
}

@media (max-width: 576px) {
    .filter-bar .form-text {
        font-size: 12px;
    }
    
    .badge {
        font-size: 11px;
        padding: 3px 6px;
    }
    
    .card-header h5 {
        font-size: 16px;
    }
}
</style>

<script>
// Initialize tooltips
document.addEventListener('DOMContentLoaded', function() {
    // Initialize Bootstrap tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Add hover effects to table rows
    const tableRows = document.querySelectorAll('.table tbody tr');
    tableRows.forEach(row => {
        row.addEventListener('mouseenter', function() {
            this.style.transform = 'translateX(3px)';
            this.style.transition = 'transform 0.2s ease';
        });
        row.addEventListener('mouseleave', function() {
            this.style.transform = 'translateX(0)';
        });
    });
    
    // Auto-refresh notification
    setInterval(function() {
        console.log('Report data is up-to-date. Last checked: ' + new Date().toLocaleTimeString());
    }, 300000);
});

// Print report function
function printReport() {
    window.print();
}

// Export report function
function exportReport(format) {
    alert(`Exporting report in ${format} format...`);
}
</script>

<!-- Print Button -->
<div class="position-fixed bottom-0 end-0 m-3 d-none d-md-block">
    <button class="btn btn-outline-primary btn-lg rounded-circle shadow" onclick="printReport()" 
            data-bs-toggle="tooltip" data-bs-placement="left" title="Print Report">
        <i class="fas fa-print"></i>
    </button>
</div>

<!-- Mobile Export Button -->
<div class="d-block d-md-none mt-4 text-center">
    <a href="<?= site_url('admin/pensioners/export_excel') ?>" class="btn btn-primary w-100">
        <i class="fas fa-file-export me-2"></i>Export to Excel
    </a>
</div>

<?= $this->endSection() ?>

<?= $this->section('custom_js') ?>
<script>
// Additional custom JavaScript can go here
</script>
<?= $this->endSection() ?>