<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="container-fluid px-0 px-md-3">

    <!-- Alerts -->
    <?php if(session()->getFlashdata('success')): ?>
        <div class="alert alert-success alert-dismissible fade show mb-4" role="alert">
            <i class="fas fa-check-circle me-2"></i>
            <?= session()->getFlashdata('success') ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    
    <?php if(session()->getFlashdata('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show mb-4" role="alert">
            <i class="fas fa-exclamation-circle me-2"></i>
            <?= session()->getFlashdata('error') ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="row justify-content-center">
        <div class="col-12 col-lg-8">
            <!-- Main Card -->
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-primary text-white py-3">
                    <h5 class="mb-0">
                        <i class="fas fa-shield-alt me-2"></i>Block IP Address
                    </h5>
                    <a href="<?= base_url('/Auth/manageBlockedIPs') ?>" class="btn btn-outline-primary btn-sm">
                        <i class="fas fa-list me-1"></i>View Blocked
                    </a>
                </div>
                <div class="card-body p-3 p-md-4">
                    <form method="post" action="<?= base_url('/Auth/blockIP') ?>" id="blockIPForm">
                        <?= csrf_field() ?>
                        
                        <!-- IP Address Field -->
                        <div class="mb-4">
                            <label class="form-label fw-semibold">
                                IP Address <span class="text-danger">*</span>
                            </label>
                            <input type="text" name="ip_address" class="form-control" required 
                                   placeholder="e.g., 192.168.1.1">
                            <div class="form-text text-muted">
                                Enter a valid IPv4 or IPv6 address
                            </div>
                        </div>

                        <!-- Reason Field -->
                        <div class="mb-4">
                            <label class="form-label fw-semibold">
                                Reason for Blocking (Optional)
                            </label>
                            <textarea name="reason" class="form-control" rows="2" 
                                      placeholder="Enter reason for blocking..."></textarea>
                        </div>

                        <!-- Block Type -->
                        <div class="mb-4">
                            <label class="form-label fw-semibold d-block">
                                Block Type <span class="text-danger">*</span>
                            </label>
                            <div class="row g-2">
                                <div class="col-6">
                                    <div class="form-check form-check-inline-block w-100">
                                        <input class="form-check-input" type="radio" name="is_permanent" 
                                               id="permanent" value="1" checked>
                                        <label class="form-check-label w-100 border rounded p-3" for="permanent">
                                            <i class="fas fa-infinity text-danger me-2"></i>
                                            <strong>Permanent</strong>
                                            <small class="d-block text-muted mt-1">Block indefinitely</small>
                                        </label>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-check form-check-inline-block w-100">
                                        <input class="form-check-input" type="radio" name="is_permanent" 
                                               id="temporary" value="0">
                                        <label class="form-check-label w-100 border rounded p-3" for="temporary">
                                            <i class="fas fa-clock text-warning me-2"></i>
                                            <strong>Temporary</strong>
                                            <small class="d-block text-muted mt-1">Block for duration</small>
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Duration Field -->
                        <div class="mb-4" id="durationField" style="display: none;">
                            <label class="form-label fw-semibold">
                                Block Duration (hours) <span class="text-danger">*</span>
                            </label>
                            <input type="number" name="block_duration" class="form-control" 
                                   min="1" max="8760" placeholder="Enter hours" id="durationInput">
                            <div class="form-text text-muted">
                                Block expires automatically after duration
                            </div>
                        </div>

                        <!-- Action Buttons -->
                        <div class="d-flex flex-column flex-md-row justify-content-between align-items-center gap-3 mt-4 pt-4 border-top">
                            <a href="<?= base_url('/Main') ?>" class="btn btn-outline-secondary order-2 order-md-1">
                                <i class="fas fa-arrow-left me-2"></i>Back
                            </a>
                            <div class="d-flex gap-2 order-1 order-md-2">
                                <button type="reset" class="btn btn-outline-danger">
                                    <i class="fas fa-redo me-2"></i>Reset
                                </button>
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-ban me-2"></i>Block IP
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    /* Page Header */
    .page-header {
        background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
        color: Black;
        padding: 1.5rem;
        border-radius: 10px;
        margin-bottom: 1.5rem;
    }
    
    .page-title {
        color: Black;
        font-weight: 600;
        font-size: 1.5rem;
        margin: 0;
    }
    
    .breadcrumb {
        background: transparent;
        padding: 0;
        margin: 0;
    }
    
    .breadcrumb-item a {
        color: black;
        text-decoration: none;
        font-size: 0.875rem;
    }
    
    .breadcrumb-item.active {
        color: Black;
        font-weight: 500;
    }
    
    .breadcrumb-item + .breadcrumb-item::before {
        color: rgba(255, 255, 255, 0.6);
    }
    
    /* Form Styling */
    .form-check-inline-block {
        display: inline-block;
    }
    
    .form-check-input:checked + .form-check-label {
        border-color: var(--primary) !important;
        background-color: rgba(44, 90, 160, 0.05);
    }
    
    .form-check-label {
        cursor: pointer;
        transition: all 0.2s ease;
    }
    
    .form-check-label:hover {
        border-color: var(--primary-light) !important;
    }
    
    /* Mobile Responsive Additions - No HTML changes */
    
    /* Card header responsive */
    .card-header {
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        align-items: center;
        gap: 1rem;
    }
    
    .card-header h5 {
        flex: 1;
        min-width: 200px;
    }
    
    /* Form elements responsive */
    .form-control, textarea.form-control {
        width: 100%;
        box-sizing: border-box;
    }
    
    /* Radio button cards responsive */
    .form-check-label {
        box-sizing: border-box;
    }
    
    /* Button group responsive */
    .d-flex.gap-2, .d-flex.gap-3 {
        flex-wrap: wrap;
    }
    
    /* Main responsive breakpoints */
    
    /* Large tablets and small desktops */
    @media (max-width: 992px) {
        .container-fluid {
            padding-left: 0.5rem;
            padding-right: 0.5rem;
        }
        
        .col-lg-8 {
            width: 95%;
        }
    }
    
    /* Tablets */
    @media (max-width: 768px) {
        .page-header {
            padding: 1rem;
            border-radius: 8px;
        }
        
        .page-title {
            font-size: 1.25rem;
        }
        
        .card-body {
            padding: 1rem !important;
        }
        
        .form-check-label {
            padding: 0.75rem !important;
            font-size: 0.875rem;
        }
        
        /* Adjust card header for tablets */
        .card-header {
            flex-direction: column;
            align-items: flex-start;
            gap: 0.75rem;
        }
        
        .card-header h5 {
            width: 100%;
            margin-bottom: 0.5rem;
        }
        
        /* Adjust radio button layout */
        .row.g-2 .col-6 {
            width: 100%;
            margin-bottom: 0.75rem;
        }
        
        /* Button adjustments */
        .btn {
            padding: 0.5rem 1rem;
            font-size: 0.9rem;
        }
        
        .btn-sm {
            padding: 0.375rem 0.75rem;
            font-size: 0.85rem;
        }
        
        /* Action buttons */
        .d-flex.flex-column.flex-md-row {
            flex-direction: column !important;
            gap: 1rem !important;
        }
        
        .order-1, .order-2 {
            width: 100%;
            text-align: center;
        }
        
        .d-flex.gap-2 {
            justify-content: center;
        }
    }
    
    /* Mobile phones */
    @media (max-width: 576px) {
        .container-fluid {
            padding-left: 0.25rem;
            padding-right: 0.25rem;
        }
        
        .page-header {
            padding: 0.75rem;
        }
        
        .btn {
            padding: 0.375rem 0.75rem;
            font-size: 0.875rem;
            width: 100%;
            margin-bottom: 0.5rem;
        }
        
        .form-label {
            font-size: 0.875rem;
        }
        
        .form-control, .form-select {
            font-size: 0.875rem;
            padding: 0.5rem;
        }
        
        /* Card adjustments */
        .card {
            margin: 0 0.125rem;
        }
        
        .card-body {
            padding: 0.75rem !important;
        }
        
        /* Radio button cards - stack vertically */
        .row.g-2 {
            flex-direction: column;
        }
        
        .row.g-2 .col-6 {
            width: 100%;
            margin-bottom: 0.5rem;
        }
        
        .form-check-label {
            padding: 0.625rem !important;
            font-size: 0.85rem;
        }
        
        .form-check-label i {
            font-size: 1rem;
        }
        
        .form-check-label strong {
            font-size: 0.9rem;
        }
        
        .form-check-label small {
            font-size: 0.8rem;
        }
        
        /* Button groups - stack vertically */
        .d-flex.gap-2 {
            flex-direction: column;
            width: 100%;
        }
        
        .d-flex.gap-2 .btn {
            width: 100%;
            margin-bottom: 0.5rem;
        }
        
        /* Alerts */
        .alert {
            margin: 0 0.25rem 1rem 0.25rem;
            font-size: 0.85rem;
            padding: 0.75rem;
        }
        
        .alert i {
            font-size: 0.9rem;
        }
        
        /* Form text */
        .form-text {
            font-size: 0.8rem;
        }
        
        /* Spacing adjustments */
        .mb-4 {
            margin-bottom: 1rem !important;
        }
        
        .mt-4 {
            margin-top: 1.25rem !important;
        }
        
        .pt-4 {
            padding-top: 1.25rem !important;
        }
        
        .gap-3 {
            gap: 0.75rem !important;
        }
    }
    
    /* Small phones */
    @media (max-width: 375px) {
        .card-body {
            padding: 0.5rem !important;
        }
        
        .form-check-label {
            padding: 0.5rem !important;
            font-size: 0.8rem;
        }
        
        .btn {
            padding: 0.25rem 0.5rem;
            font-size: 0.8rem;
        }
        
        .form-control {
            font-size: 0.8rem;
            padding: 0.375rem;
        }
        
        textarea.form-control {
            min-height: 70px;
        }
        
        /* Reduce icon sizes */
        .form-check-label i,
        .btn i,
        .alert i {
            font-size: 0.9rem;
        }
    }
    
    /* Ensure form elements don't overflow */
    input, textarea, select {
        max-width: 100%;
    }
    
    /* Prevent horizontal scrolling */
    body {
        overflow-x: hidden;
    }
    
    /* Improve touch targets on mobile */
    @media (max-width: 768px) {
        .form-check-label,
        .btn,
        input[type="radio"],
        input[type="checkbox"] {
            min-height: 44px; /* Apple's recommended minimum touch target */
        }
        
        .form-check-input {
            width: 20px;
            height: 20px;
        }
    }
</style>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const permanentRadio = document.getElementById('permanent');
        const temporaryRadio = document.getElementById('temporary');
        const durationField = document.getElementById('durationField');
        const durationInput = document.getElementById('durationInput');
        
        // Show/hide duration field based on radio selection
        function toggleDurationField() {
            if (temporaryRadio.checked) {
                durationField.style.display = 'block';
                durationInput.setAttribute('required', 'required');
            } else {
                durationField.style.display = 'none';
                durationInput.removeAttribute('required');
            }
        }
        
        // Add event listeners to radio buttons
        permanentRadio.addEventListener('change', toggleDurationField);
        temporaryRadio.addEventListener('change', toggleDurationField);
        
        // Form validation
        document.getElementById('blockIPForm').addEventListener('submit', function(e) {
            const ipAddress = document.querySelector('input[name="ip_address"]').value;
            
            // Simple IP validation (basic pattern)
            const ipPattern = /^(\d{1,3}\.){3}\d{1,3}$/;
            
            if (!ipPattern.test(ipAddress)) {
                e.preventDefault();
                alert('Please enter a valid IP address (e.g., 192.168.1.1)');
                return false;
            }
            
            if (temporaryRadio.checked && !durationInput.value) {
                e.preventDefault();
                alert('Please specify block duration for temporary blocks');
                return false;
            }
            
            if (!confirm('Are you sure you want to block this IP address?')) {
                e.preventDefault();
                return false;
            }
        });
        
        // Initialize
        toggleDurationField();
    });
</script>

<?= $this->endSection() ?>