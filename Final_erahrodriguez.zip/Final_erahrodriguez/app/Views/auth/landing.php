<?= $this->extend('layouts/login_base') ?>

<?= $this->section('content') ?>

<style>
    :root {
        --primary: #2c3e50;
        --secondary: #3498db;
        --accent: #1abc9c;
        --danger: #e74c3c;
        --light: #f8f9fa;
        --dark: #343a40;
        --gray: #7f8c8d;
        --light-gray: #95a5a6;
    }
    
    body {
        margin: 0;
        padding: 0;
        font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
    }
    
    .landing-container {
        min-height: 100vh;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 20px;
        box-sizing: border-box;
    }
    
    .landing-card {
        background: rgba(255, 255, 255, 0.95);
        border-radius: 20px;
        padding: 50px;
        max-width: 800px;
        width: 100%;
        text-align: center;
        box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
        box-sizing: border-box;
    }
    
    .landing-logo {
        font-size: 4rem;
        color: var(--primary);
        margin-bottom: 20px;
    }
    
    .landing-title {
        font-size: 2.5rem;
        color: var(--primary);
        margin-bottom: 10px;
        font-weight: 600;
        line-height: 1.2;
    }
    
    .landing-subtitle {
        font-size: 1.2rem;
        color: var(--gray);
        margin-bottom: 40px;
        line-height: 1.5;
    }
    
    .login-options {
        display: flex;
        gap: 30px;
        justify-content: center;
        margin-top: 40px;
        flex-wrap: wrap;
    }
    
    .login-card {
        background: white;
        padding: 30px;
        border-radius: 15px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        width: 300px;
        min-width: 280px;
        transition: all 0.3s ease;
        box-sizing: border-box;
        display: flex;
        flex-direction: column;
        align-items: center;
    }
    
    .login-card:hover {
        transform: translateY(-10px);
        box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
    }
    
    .login-icon {
        font-size: 3rem;
        margin-bottom: 20px;
        display: flex;
        align-items: center;
        justify-content: center;
        height: 80px;
        width: 80px;
        border-radius: 50%;
        background: rgba(52, 152, 219, 0.1);
    }
    
    .user-login .login-icon {
        color: var(--secondary);
        background: rgba(52, 152, 219, 0.1);
    }
    
    .admin-login .login-icon {
        color: var(--danger);
        background: rgba(231, 76, 60, 0.1);
    }
    
    .login-card h3 {
        margin-bottom: 15px;
        color: var(--primary);
        font-size: 1.5rem;
        font-weight: 600;
    }
    
    .login-card p {
        color: var(--gray);
        margin-bottom: 25px;
        font-size: 0.95rem;
        line-height: 1.5;
        flex-grow: 1;
    }
    
    .btn-login {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 12px 30px;
        border-radius: 8px;
        text-decoration: none;
        font-weight: 600;
        transition: all 0.3s;
        border: none;
        cursor: pointer;
        font-size: 1rem;
        width: 100%;
        box-sizing: border-box;
    }
    
    .user-login .btn-login {
        background: var(--secondary);
        color: white;
    }
    
    .user-login .btn-login:hover {
        background: #2980b9;
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(52, 152, 219, 0.3);
    }
    
    .admin-login .btn-login {
        background: var(--primary);
        color: white;
        border: 2px solid var(--danger);
    }
    
    .admin-login .btn-login:hover {
        background: #34495e;
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(44, 62, 80, 0.3);
    }
    
    .btn-login i {
        margin-right: 8px;
    }
    
    .additional-links {
        margin-top: 50px;
        padding-top: 20px;
        border-top: 1px solid #eee;
    }
    
    .register-link {
        color: var(--gray);
        margin-bottom: 20px;
        font-size: 1rem;
    }
    
    .register-link a {
        color: var(--secondary);
        text-decoration: none;
        font-weight: 600;
        transition: color 0.3s;
    }
    
    .register-link a:hover {
        color: var(--primary);
        text-decoration: underline;
    }
    
    .security-note {
        font-size: 0.9rem;
        color: var(--light-gray);
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        margin-top: 10px;
    }
    
    .security-note i {
        color: var(--accent);
    }
    
    /* Tablet Responsive */
    @media (max-width: 1024px) {
        .landing-card {
            padding: 40px 30px;
            max-width: 90%;
        }
        
        .landing-title {
            font-size: 2.2rem;
        }
        
        .landing-subtitle {
            font-size: 1.1rem;
        }
        
        .login-options {
            gap: 25px;
        }
        
        .login-card {
            width: calc(50% - 25px);
            min-width: auto;
        }
    }
    
    /* Mobile Landscape */
    @media (max-width: 768px) and (orientation: landscape) {
        .landing-container {
            min-height: auto;
            padding: 20px 10px;
        }
        
        .landing-card {
            padding: 30px 20px;
            max-width: 95%;
        }
        
        .landing-logo {
            font-size: 3rem;
            margin-bottom: 15px;
        }
        
        .landing-title {
            font-size: 2rem;
            margin-bottom: 8px;
        }
        
        .landing-subtitle {
            font-size: 1rem;
            margin-bottom: 30px;
        }
        
        .login-options {
            flex-direction: row;
            gap: 20px;
            margin-top: 30px;
        }
        
        .login-card {
            width: calc(50% - 10px);
            padding: 20px 15px;
        }
        
        .login-icon {
            font-size: 2.5rem;
            height: 70px;
            width: 70px;
            margin-bottom: 15px;
        }
        
        .login-card h3 {
            font-size: 1.3rem;
            margin-bottom: 10px;
        }
        
        .login-card p {
            font-size: 0.9rem;
            margin-bottom: 20px;
        }
        
        .btn-login {
            padding: 10px 20px;
            font-size: 0.95rem;
        }
        
        .additional-links {
            margin-top: 30px;
            padding-top: 15px;
        }
    }
    
    /* Mobile Portrait */
    @media (max-width: 768px) and (orientation: portrait) {
        .landing-container {
            min-height: 100vh;
            padding: 15px;
        }
        
        .landing-card {
            padding: 30px 20px;
            max-width: 100%;
            margin: 0 10px;
        }
        
        .landing-logo {
            font-size: 3.5rem;
            margin-bottom: 15px;
        }
        
        .landing-title {
            font-size: 1.8rem;
            margin-bottom: 8px;
        }
        
        .landing-subtitle {
            font-size: 1rem;
            margin-bottom: 30px;
            padding: 0 10px;
        }
        
        .login-options {
            flex-direction: column;
            gap: 20px;
            margin-top: 30px;
            width: 100%;
        }
        
        .login-card {
            width: 100%;
            max-width: 350px;
            margin: 0 auto;
            padding: 25px 20px;
        }
        
        .login-icon {
            font-size: 2.5rem;
            height: 70px;
            width: 70px;
            margin-bottom: 15px;
        }
        
        .login-card h3 {
            font-size: 1.4rem;
            margin-bottom: 12px;
        }
        
        .login-card p {
            font-size: 0.95rem;
            margin-bottom: 20px;
            padding: 0 5px;
        }
        
        .btn-login {
            padding: 12px 24px;
            font-size: 1rem;
        }
        
        .additional-links {
            margin-top: 40px;
            padding-top: 20px;
        }
        
        .register-link {
            font-size: 0.95rem;
            margin-bottom: 15px;
        }
        
        .security-note {
            font-size: 0.85rem;
        }
    }
    
    /* Small Mobile Devices */
    @media (max-width: 480px) {
        .landing-container {
            padding: 10px;
        }
        
        .landing-card {
            padding: 25px 15px;
            border-radius: 15px;
        }
        
        .landing-logo {
            font-size: 3rem;
            margin-bottom: 12px;
        }
        
        .landing-title {
            font-size: 1.6rem;
            margin-bottom: 6px;
        }
        
        .landing-subtitle {
            font-size: 0.95rem;
            margin-bottom: 25px;
            padding: 0;
        }
        
        .login-options {
            gap: 15px;
            margin-top: 25px;
        }
        
        .login-card {
            padding: 20px 15px;
            max-width: 100%;
        }
        
        .login-icon {
            font-size: 2.2rem;
            height: 60px;
            width: 60px;
            margin-bottom: 12px;
        }
        
        .login-card h3 {
            font-size: 1.3rem;
            margin-bottom: 10px;
        }
        
        .login-card p {
            font-size: 0.9rem;
            margin-bottom: 18px;
        }
        
        .btn-login {
            padding: 10px 20px;
            font-size: 0.95rem;
        }
        
        .additional-links {
            margin-top: 30px;
            padding-top: 15px;
        }
        
        .register-link {
            font-size: 0.9rem;
            margin-bottom: 12px;
        }
        
        .security-note {
            font-size: 0.8rem;
        }
    }
    
    /* Extra Small Devices */
    @media (max-width: 360px) {
        .landing-title {
            font-size: 1.4rem;
        }
        
        .landing-subtitle {
            font-size: 0.9rem;
        }
        
        .login-card {
            padding: 18px 12px;
        }
        
        .login-card h3 {
            font-size: 1.2rem;
        }
        
        .login-card p {
            font-size: 0.85rem;
        }
        
        .btn-login {
            padding: 9px 18px;
            font-size: 0.9rem;
        }
        
        .btn-login i {
            margin-right: 5px;
        }
    }
    
    /* Touch Device Optimizations */
    @media (hover: none) {
        .login-card:hover {
            transform: none;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }
        
        .user-login .btn-login:hover {
            transform: none;
            box-shadow: none;
            background: var(--secondary);
        }
        
        .admin-login .btn-login:hover {
            transform: none;
            box-shadow: none;
            background: var(--primary);
        }
        
        .register-link a:hover {
            color: var(--secondary);
            text-decoration: none;
        }
        
        /* Add touch feedback */
        .btn-login:active {
            transform: scale(0.98);
        }
        
        .login-card:active {
            transform: scale(0.99);
        }
    }
    
    /* High DPI Screens */
    @media (-webkit-min-device-pixel-ratio: 2), (min-resolution: 192dpi) {
        .landing-card {
            backdrop-filter: blur(20px);
        }
    }
    
    /* Safe area for notched phones */
    @supports(padding: max(0px)) {
        .landing-container {
            padding-left: max(20px, env(safe-area-inset-left));
            padding-right: max(20px, env(safe-area-inset-right));
            padding-top: max(20px, env(safe-area-inset-top));
            padding-bottom: max(20px, env(safe-area-inset-bottom));
        }
    }
    
    /* Dark mode support */
    @media (prefers-color-scheme: dark) {
        .landing-card {
            background: rgba(30, 30, 30, 0.95);
            color: #ffffff;
        }
        
        .landing-title,
        .login-card h3 {
            color: #ffffff;
        }
        
        .landing-subtitle,
        .login-card p,
        .register-link {
            color: rgba(255, 255, 255, 0.8);
        }
        
        .login-card {
            background: rgba(40, 40, 40, 0.9);
        }
        
        .security-note {
            color: rgba(255, 255, 255, 0.6);
        }
        
        .additional-links {
            border-top-color: rgba(255, 255, 255, 0.1);
        }
        
        .login-icon {
            background: rgba(255, 255, 255, 0.1);
        }
    }
</style>

<div class="landing-container">
    <div class="landing-card">
        <div class="landing-logo">
            <i class="fas fa-hand-holding-heart"></i>
        </div>
        <h1 class="landing-title">Pensioner Management System</h1>
        <p class="landing-subtitle">Secure access to your pension management portal</p>
        
        <div class="login-options">
            <!-- User Login Card -->
            <div class="login-card user-login">
                <div class="login-icon">
                    <i class="fas fa-user-circle"></i>
                </div>
                <h3>User Login</h3>
                <p>Access your personal pension account, view statements, and manage your profile.</p>
                <a href="<?= site_url('/login') ?>" class="btn-login">
                    <i class="fas fa-sign-in-alt"></i>User Login
                </a>
            </div>
            
            <!-- Admin Login Card -->
            <div class="login-card admin-login">
                <div class="login-icon">
                    <i class="fas fa-lock"></i>
                </div>
                <h3>Admin Login</h3>
                <p>Administrator access for system management, user administration, and reporting.</p>
                <a href="<?= site_url('/admin/login') ?>" class="btn-login">
                    <i class="fas fa-cog"></i>Admin Login
                </a>
            </div>
        </div>
        
        <!-- Additional Links -->
        <div class="additional-links">
            <p class="register-link">
                Don't have an account? 
                <a href="<?= site_url('/register') ?>">
                    <i class="fas fa-user-plus"></i>Register here
                </a>
            </p>
            <p class="security-note">
                <i class="fas fa-shield-alt"></i>
                Your security is our priority. All data is encrypted with 256-bit SSL.
            </p>
        </div>
    </div>
</div>

<?= $this->endSection() ?>