<?php

?>

<?= $this->extend('layouts/login_base') ?>

<?= $this->section('content') ?>

<style>
    :root {
        --primary: #2c3e50;
        --secondary: #3498db;
        --accent: #1abc9c;
        --light: #f8f9fa;
        --dark: #343a40;
        --warning: #f39c12;
        --danger: #e74c3c;
        --success: #27ae60;
    }
    
    body {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        min-height: 100vh;
        font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 20px;
    }
    
    /* Main Container */
    .auth-container {
        max-width: 500px;
        width: 100%;
    }
    
    /* Card */
    .auth-card {
        background: rgba(255, 255, 255, 0.95);
        border-radius: 15px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.3);
        overflow: hidden;
    }
    
    /* Header */
    .auth-header {
        background: linear-gradient(135deg, var(--primary), var(--secondary));
        color: white;
        padding: 30px;
        border-radius: 15px 15px 0 0;
        text-align: center;
    }
    
    .auth-logo {
        width: 80px;
        height: 80px;
        background: white;
        border-radius: 50%;
        margin: 0 auto 20px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--primary);
        font-size: 2rem;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
    }
    
    .auth-title {
        font-size: 1.8rem;
        font-weight: 600;
        margin-bottom: 8px;
    }
    
    .auth-subtitle {
        font-size: 1rem;
        opacity: 0.9;
    }
    
    /* Body */
    .auth-body {
        padding: 30px;
    }
    
    /* Alerts */
    .alert {
        border-radius: 8px;
        border: none;
        padding: 15px 20px;
        margin-bottom: 25px;
        display: flex;
        align-items: flex-start;
        gap: 12px;
    }
    
    .alert-error {
        background: rgba(231, 76, 60, 0.1);
        color: var(--danger);
        border-left: 4px solid var(--danger);
    }
    
    .alert-success {
        background: rgba(39, 174, 96, 0.1);
        color: var(--success);
        border-left: 4px solid var(--success);
    }
    
    .alert-info {
        background: rgba(52, 152, 219, 0.1);
        color: var(--secondary);
        border-left: 4px solid var(--secondary);
    }
    
    .alert-icon {
        font-size: 1.2rem;
        flex-shrink: 0;
    }
    
    .alert-content {
        flex: 1;
    }
    
    .alert-title {
        font-weight: 600;
        margin-bottom: 5px;
        font-size: 1rem;
    }
    
    .alert-message {
        font-size: 0.95rem;
        line-height: 1.5;
    }
    
    /* Form */
    .form-group {
        margin-bottom: 25px;
    }
    
    .form-label {
        display: block;
        color: var(--dark);
        font-weight: 600;
        font-size: 0.95rem;
        margin-bottom: 8px;
    }
    
    .form-control {
        width: 100%;
        border: 2px solid #e9ecef;
        border-radius: 8px;
        padding: 14px 16px;
        font-size: 1rem;
        transition: all 0.3s;
        background: white;
    }
    
    .form-control:focus {
        border-color: var(--accent);
        outline: none;
        box-shadow: 0 0 0 0.2rem rgba(26, 188, 156, 0.25);
    }
    
    .input-group {
        position: relative;
    }
    
    /* Password Toggle */
    .password-toggle {
        position: absolute;
        right: 15px;
        top: 50%;
        transform: translateY(-50%);
        background: none;
        border: none;
        color: #6c757d;
        cursor: pointer;
        padding: 4px;
        transition: color 0.3s;
    }
    
    .password-toggle:hover {
        color: var(--primary);
    }
    
    /* Remember Me */
    .remember-me {
        display: flex;
        align-items: center;
        margin-bottom: 25px;
        gap: 8px;
    }
    
    .form-check-input {
        width: 18px;
        height: 18px;
        border: 2px solid #ced4da;
        border-radius: 4px;
        cursor: pointer;
        margin: 0;
    }
    
    .form-check-input:checked {
        background-color: var(--accent);
        border-color: var(--accent);
    }
    
    .form-check-label {
        color: var(--dark);
        font-size: 0.95rem;
        cursor: pointer;
        user-select: none;
    }
    
    /* Submit Button */
    .btn-primary {
        background: linear-gradient(135deg, var(--primary), var(--secondary));
        border: none;
        padding: 16px;
        border-radius: 8px;
        font-weight: 600;
        transition: all 0.3s;
        color: white;
        font-size: 1rem;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
        width: 100%;
    }
    
    .btn-primary:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(52, 152, 219, 0.4);
    }
    
    .btn-primary:disabled {
        opacity: 0.6;
        cursor: not-allowed;
        transform: none;
        box-shadow: none;
    }
    
    /* Links */
    .auth-links {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin: 25px 0 0;
        padding-top: 20px;
        border-top: 1px solid #e9ecef;
    }
    
    .auth-link {
        color: var(--secondary);
        text-decoration: none;
        font-size: 0.95rem;
        font-weight: 500;
        transition: color 0.3s;
    }
    
    .auth-link:hover {
        color: var(--primary);
        text-decoration: underline;
    }
    
    /* Security Note */
    .security-note {
        background: rgba(26, 188, 156, 0.1);
        border-radius: 8px;
        padding: 16px 20px;
        margin-top: 25px;
        border-left: 4px solid var(--accent);
    }
    
    .security-title {
        font-weight: 600;
        color: var(--primary);
        font-size: 0.95rem;
        margin-bottom: 5px;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    
    .security-text {
        color: var(--dark);
        font-size: 0.9rem;
        line-height: 1.5;
    }
    
    /* Loading */
    .loading {
        display: inline-block;
        width: 20px;
        height: 20px;
        border: 2px solid rgba(255, 255, 255, 0.3);
        border-radius: 50%;
        border-top-color: white;
        animation: spin 1s linear infinite;
    }
    
    @keyframes spin {
        to { transform: rotate(360deg); }
    }
    
    /* Validation */
    .error-message {
        color: var(--danger);
        font-size: 0.85rem;
        margin-top: 8px;
        display: none;
    }
    
    .form-control.invalid {
        border-color: var(--danger);
        background: rgba(231, 76, 60, 0.05);
    }
    
    .form-control.invalid + .error-message {
        display: block;
    }
    
    /* Responsive */
    @media (max-width: 576px) {
        body {
            padding: 15px;
        }
        
        .auth-container {
            margin: 0 auto;
            padding: 0;
        }
        
        .auth-header {
            padding: 25px 20px;
        }
        
        .auth-body {
            padding: 25px 20px;
        }
        
        .auth-logo {
            width: 70px;
            height: 70px;
            font-size: 1.8rem;
        }
        
        .auth-title {
            font-size: 1.6rem;
        }
        
        .auth-links {
            flex-direction: column;
            gap: 15px;
            align-items: flex-start;
        }
    }
    
    @media (max-width: 360px) {
        .auth-header {
            padding: 20px 15px;
        }
        
        .auth-body {
            padding: 20px 15px;
        }
        
        .auth-title {
            font-size: 1.4rem;
        }
        
        .form-control {
            padding: 12px 14px;
            font-size: 16px;
        }
        
        .btn-primary {
            padding: 14px;
        }
    }
    
    /* Touch device optimizations */
    @media (hover: none) {
        .btn-primary:hover {
            transform: none;
            box-shadow: none;
        }
        
        .auth-link:hover {
            color: var(--secondary);
        }
    }
</style>

<div class="auth-container">
    <div class="auth-card">
        <!-- Header -->
        <div class="auth-header">
            <div class="auth-logo">
                <i class="fas fa-hand-holding-heart"></i>
            </div>
            <h3 class="auth-title">PensionerMS</h3>
            <p class="auth-subtitle">Secure Access Portal</p>
        </div>
        
        <!-- Body -->
        <div class="auth-body">
            <!-- Alert Messages -->
<!-- Alert Messages -->
<?php if (session()->getFlashdata('error')): ?>
    <div class="alert alert-error">
        <i class="fas fa-exclamation-triangle alert-icon"></i>
        <div class="alert-content">
            <div class="alert-title">Login Failed</div>
            <div class="alert-message"><?= session()->getFlashdata('error') ?></div>
        </div>
    </div>
<?php endif; ?>

<?php if (session()->getFlashdata('success')): ?>
    <div class="alert alert-success">
        <i class="fas fa-check-circle alert-icon"></i>
        <div class="alert-content">
            <div class="alert-title">Success</div>
            <div class="alert-message"><?= session()->getFlashdata('success') ?></div>
        </div>
    </div>
<?php endif; ?>

            
            <!-- Login Form -->
            <form action="<?= base_url('login') ?>" method="POST" id="loginForm">
                <!-- Email -->
                <div class="form-group">
                    <label for="email" class="form-label">
                        <i class="fas fa-envelope me-2"></i>Email Address
                    </label>
                    <input type="email" 
                           class="form-control" 
                           id="email" 
                           name="email"
                           placeholder="Enter your email"
                           value="<?= !empty($data->getPost('email')) ? esc($data->getPost('email')) : '' ?>"
                           required
                           autocomplete="username">
                    <div class="error-message" id="emailError"></div>
                </div>
                
                <!-- Password -->
                <div class="form-group">
                    <label for="password" class="form-label">
                        <i class="fas fa-lock me-2"></i>Password
                    </label>
                    <div class="input-group">
                        <input type="password" 
                               class="form-control" 
                               id="password" 
                               name="password"
                               placeholder="Enter your password"
                               required
                               autocomplete="current-password">
                        <button type="button" class="password-toggle" id="togglePassword" aria-label="Show password">
                            <i class="far fa-eye"></i>
                        </button>
                    </div>
                    <div class="error-message" id="passwordError"></div>
                </div>
                
                <!-- Remember Me -->
                <div class="remember-me">
                    <input type="checkbox" 
                           class="form-check-input" 
                           id="remember" 
                           name="remember"
                           <?= !empty($data->getPost('remember')) ? 'checked' : '' ?>>
                    <label for="remember" class="form-check-label">Remember me</label>
                </div>
                
                <!-- Submit Button -->
                <button type="submit" class="btn btn-primary" id="loginButton">
                    <i class="fas fa-sign-in-alt"></i>
                    <span id="buttonText">Sign In</span>
                    <span id="loadingIcon" class="loading" style="display: none;"></span>
                </button>
                
                <!-- Links -->
                <div class="auth-links">
                    <a href="<?= site_url('/register') ?>" class="auth-link">
                        <i class="fas fa-user-plus me-1"></i>Create Account
                    </a>
                </div>
                
                <!-- Security Note -->
                <div class="security-note">
                    <div class="security-title">
                        <i class="fas fa-shield-alt"></i>
                        <span>Secure Access</span>
                    </div>
                    <div class="security-text">
                        Your login is protected with 256-bit SSL encryption. 
                        Unauthorized access is strictly prohibited.
                    </div>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Footer -->
</div>

<!-- Forgot Password Modal -->
<div class="modal fade" id="forgotPasswordModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fas fa-key me-2"></i>Reset Password</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>Enter your email address and we'll send you a link to reset your password.</p>
                <div class="mb-3">
                    <label for="resetEmail" class="form-label">Email Address</label>
                    <input type="email" class="form-control" id="resetEmail" placeholder="Enter your email">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" onclick="sendResetLink()">Send Reset Link</button>
            </div>
        </div>
    </div>
</div>

<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

<script>
    // Password toggle
    const togglePassword = document.getElementById('togglePassword');
    const passwordInput = document.getElementById('password');
    
    if (togglePassword) {
        togglePassword.addEventListener('click', function() {
            const type = passwordInput.type === 'password' ? 'text' : 'password';
            passwordInput.type = type;
            
            const icon = this.querySelector('i');
            if (type === 'text') {
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
                this.setAttribute('aria-label', 'Hide password');
            } else {
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
                this.setAttribute('aria-label', 'Show password');
            }
        });
    }
    
    // Form validation
    const loginForm = document.getElementById('loginForm');
    const loginButton = document.getElementById('loginButton');
    
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Clear previous errors
            clearErrors();
            
            // Get values
            const email = document.getElementById('email').value.trim();
            const password = document.getElementById('password').value.trim();
            
            let hasError = false;
            
            // Validate email
            if (!email) {
                showError('email', 'Email is required');
                hasError = true;
            } else if (!isValidEmail(email)) {
                showError('email', 'Please enter a valid email address');
                hasError = true;
            }
            
            // Validate password
            if (!password) {
                showError('password', 'Password is required');
                hasError = true;
            }
            
            if (hasError) {
                return;
            }
            
            // Show loading
            showLoading();
            
            // Submit form
            setTimeout(() => {
                loginForm.submit();
            }, 1000);
        });
    }
    
    // Helper functions
    function isValidEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }
    
    function showError(field, message) {
        const input = document.getElementById(field);
        const errorElement = document.getElementById(field + 'Error');
        
        if (input && errorElement) {
            input.classList.add('invalid');
            errorElement.textContent = message;
            errorElement.style.display = 'block';
        }
    }
    
    function clearErrors() {
        const inputs = document.querySelectorAll('.form-control');
        inputs.forEach(input => {
            input.classList.remove('invalid');
        });
        
        const errors = document.querySelectorAll('.error-message');
        errors.forEach(error => {
            error.textContent = '';
            error.style.display = 'none';
        });
    }
    
    function showLoading() {
        const buttonText = document.getElementById('buttonText');
        const loadingIcon = document.getElementById('loadingIcon');
        
        if (loginButton && buttonText && loadingIcon) {
            loginButton.disabled = true;
            buttonText.textContent = 'Signing In...';
            loadingIcon.style.display = 'inline-block';
        }
    }
    
    // Forgot password modal functions
    function showForgotPassword() {
        const modal = new bootstrap.Modal(document.getElementById('forgotPasswordModal'));
        modal.show();
    }
    
    function sendResetLink() {
        const email = document.getElementById('resetEmail').value;
        
        if (!email) {
            alert('Please enter your email address');
            return;
        }
        
        if (!isValidEmail(email)) {
            alert('Please enter a valid email address');
            return;
        }
        
        // Here you would typically make an API call
        alert('Reset link sent to ' + email);
        const modal = bootstrap.Modal.getInstance(document.getElementById('forgotPasswordModal'));
        modal.hide();
    }
    
    // Auto-focus email on load
    document.addEventListener('DOMContentLoaded', function() {
        const emailField = document.getElementById('email');
        if (emailField) {
            emailField.focus();
        }
        
        // Initialize Bootstrap modal
        if (typeof bootstrap !== 'undefined') {
            const modalElement = document.getElementById('forgotPasswordModal');
            if (modalElement) {
                new bootstrap.Modal(modalElement);
            }
        }
    });
    
    // Real-time validation
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');
    
    if (emailInput) {
        emailInput.addEventListener('blur', function() {
            if (this.value.trim() && !isValidEmail(this.value.trim())) {
                showError('email', 'Please enter a valid email');
            } else {
                this.classList.remove('invalid');
                document.getElementById('emailError').style.display = 'none';
            }
        });
    }
    
    if (passwordInput) {
        passwordInput.addEventListener('blur', function() {
            if (this.value.trim() && this.value.length < 6) {
                showError('password', 'Password must be at least 6 characters');
            } else {
                this.classList.remove('invalid');
                document.getElementById('passwordError').style.display = 'none';
            }
        });
    }
    
    // Enter key submits form
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' && loginForm) {
            loginForm.dispatchEvent(new Event('submit'));
        }
    });
</script>

<?= $this->endSection() ?>