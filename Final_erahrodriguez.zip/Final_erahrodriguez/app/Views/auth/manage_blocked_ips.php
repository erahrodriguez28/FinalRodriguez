<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="container-fluid px-0 px-md-3">

    <!-- Alerts -->
    <?php if(session()->getFlashdata('success')): ?>
        <div class="alert alert-success alert-dismissible fade show mb-4" role="alert">
            <i class="fas fa-check-circle me-2"></i>
            <?= session()->getFlashdata('success') ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    
    <?php if(session()->getFlashdata('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show mb-4" role="alert">
            <i class="fas fa-exclamation-circle me-2"></i>
            <?= session()->getFlashdata('error') ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="row justify-content-center">
        <div class="col-12">
            <!-- Main Card -->
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-primary text-white py-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">
                            <i class="fas fa-list-check me-2"></i>Manage Blocked IP Addresses
                        </h5>
                        <div class="d-flex gap-2">
                            <a href="<?= base_url('/Auth/blockIP') ?>" class="btn btn-outline-light btn-sm">
                                <i class="fas fa-ban me-1"></i>Block New IP
                            </a>
                            <a href="<?= base_url('/Main') ?>" class="btn btn-outline-light btn-sm">
                                <i class="fas fa-arrow-left me-1"></i>Back to Dashboard
                            </a>
                        </div>
                    </div>
                </div>
                
                <div class="card-body p-3 p-md-4">
                    <?php if(empty($blocked_ips)): ?>
                        <div class="text-center py-5">
                            <div class="empty-state-icon mb-3">
                                <i class="fas fa-shield-alt fa-3x text-muted"></i>
                            </div>
                            <h5 class="text-muted mb-2">No Blocked IP Addresses</h5>
                            <p class="text-muted mb-4">No IP addresses are currently blocked.</p>
                            <a href="<?= base_url('/Auth/blockIP') ?>" class="btn btn-primary">
                                <i class="fas fa-plus-circle me-2"></i>Block Your First IP
                            </a>
                        </div>
                    <?php else: ?>
                        <!-- Statistics Summary -->
                        <div class="row mb-4">
                            <div class="col-md-4 mb-3">
                                <div class="card border-0 bg-light shadow-sm">
                                    <div class="card-body py-3">
                                        <div class="d-flex align-items-center">
                                            <div class="stat-icon bg-primary bg-opacity-10 rounded p-2 me-3">
                                                <i class="fas fa-ban text-primary"></i>
                                            </div>
                                            <div>
                                                <h5 class="stat-number mb-0"><?= count($blocked_ips) ?></h5>
                                                <p class="stat-label text-muted mb-0">Total Blocked</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 mb-3">
                                <div class="card border-0 bg-light shadow-sm">
                                    <div class="card-body py-3">
                                        <div class="d-flex align-items-center">
                                            <div class="stat-icon bg-danger bg-opacity-10 rounded p-2 me-3">
                                                <i class="fas fa-infinity text-danger"></i>
                                            </div>
                                            <div>
                                                <h5 class="stat-number mb-0">
                                                    <?= count(array_filter($blocked_ips, fn($ip) => $ip['is_permanent'] == 1)) ?>
                                                </h5>
                                                <p class="stat-label text-muted mb-0">Permanent</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 mb-3">
                                <div class="card border-0 bg-light shadow-sm">
                                    <div class="card-body py-3">
                                        <div class="d-flex align-items-center">
                                            <div class="stat-icon bg-warning bg-opacity-10 rounded p-2 me-3">
                                                <i class="fas fa-clock text-warning"></i>
                                            </div>
                                            <div>
                                                <h5 class="stat-number mb-0">
                                                    <?= count(array_filter($blocked_ips, fn($ip) => $ip['is_permanent'] == 0)) ?>
                                                </h5>
                                                <p class="stat-label text-muted mb-0">Temporary</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Table -->
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead class="table-light">
                                    <tr>
                                        <th class="fw-semibold">IP Address</th>
                                        <th class="fw-semibold">Reason</th>
                                        <th class="fw-semibold">Blocked By</th>
                                        <th class="fw-semibold">Type</th>
                                        <th class="fw-semibold">Status</th>
                                        <th class="fw-semibold">Date Blocked</th>
                                        <th class="fw-semibold text-end">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($blocked_ips as $ip): ?>
                                        <?php 
                                            $isExpired = $ip['is_permanent'] == 0 && strtotime($ip['block_until']) < time();
                                            $typeClass = $ip['is_permanent'] ? 'danger' : 'warning';
                                            $statusClass = $isExpired ? 'secondary' : 'success';
                                        ?>
                                        <tr class="<?= $isExpired ? 'table-secondary' : '' ?>">
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <div class="ip-icon bg-primary bg-opacity-10 rounded p-2 me-2">
                                                        <i class="fas fa-network-wired text-primary"></i>
                                                    </div>
                                                    <div>
                                                        <code class="fw-semibold"><?= esc($ip['ip_address']) ?></code>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <span class="text-muted"><?= esc($ip['reason'] ?: 'Not specified') ?></span>
                                            </td>
                                            <td>
                                                <div class="d-flex flex-column">
                                                    <span class="fw-medium"><?= esc($ip['blocked_by_name']) ?></span>
                                                    <small class="text-muted"><?= esc($ip['blocked_by_email']) ?></small>
                                                </div>
                                            </td>
                                            <td>
                                                <span class="badge bg-<?= $typeClass ?> bg-opacity-10 text-<?= $typeClass ?> border border-<?= $typeClass ?> border-opacity-25">
                                                    <i class="fas fa-<?= $ip['is_permanent'] ? 'infinity' : 'clock' ?> me-1"></i>
                                                    <?= $ip['is_permanent'] ? 'Permanent' : 'Temporary' ?>
                                                </span>
                                            </td>
                                            <td>
                                                <?php if($isExpired): ?>
                                                    <span class="badge bg-secondary bg-opacity-10 text-secondary border border-secondary border-opacity-25">
                                                        <i class="fas fa-clock me-1"></i>Expired
                                                    </span>
                                                <?php elseif($ip['is_permanent']): ?>
                                                    <span class="badge bg-success bg-opacity-10 text-success border border-success border-opacity-25">
                                                        <i class="fas fa-check-circle me-1"></i>Active
                                                    </span>
                                                <?php else: ?>
                                                    <span class="badge bg-info bg-opacity-10 text-info border border-info border-opacity-25">
                                                        <i class="fas fa-clock me-1"></i>
                                                        Until <?= date('M d, H:i', strtotime($ip['block_until'])) ?>
                                                    </span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <div class="d-flex flex-column">
                                                    <span class="fw-medium"><?= date('M d, Y', strtotime($ip['created_at'])) ?></span>
                                                    <small class="text-muted"><?= date('H:i', strtotime($ip['created_at'])) ?></small>
                                                </div>
                                            </td>
                                            <td class="text-end">
                                                <a href="<?= base_url('/Auth/unblockIP/' . $ip['id']) ?>" 
                                                   class="btn btn-sm btn-outline-success" 
                                                   onclick="return confirm('Are you sure you want to unblock IP <?= $ip['ip_address'] ?>?')">
                                                    <i class="fas fa-unlock me-1"></i>Unblock
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>

                        <!-- Quick Actions -->
                        <div class="d-flex justify-content-between align-items-center mt-4 pt-4 border-top">
                            <div class="text-muted small">
                                <i class="fas fa-info-circle me-1"></i>
                                Showing <?= count($blocked_ips) ?> blocked IP address(es)
                            </div>
                            <div class="d-flex gap-2">
                                <a href="<?= base_url('/Auth/userIPs') ?>" class="btn btn-outline-info btn-sm">
                                    <i class="fas fa-network-wired me-1"></i>View User IPs
                                </a>
                                <a href="<?= base_url('/Auth/blockIP') ?>" class="btn btn-primary btn-sm">
                                    <i class="fas fa-plus-circle me-1"></i>Block New IP
                                </a>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    /* Card Styling */
    .card {
        border-radius: 12px;
        overflow: hidden;
    }
    
    .card-header {
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }
    
    /* Statistics Cards */
    .stat-icon {
        width: 45px;
        height: 45px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .stat-number {
        font-size: 1.5rem;
        font-weight: 700;
        color: var(--text-dark);
    }
    
    .stat-label {
        font-size: 0.875rem;
        font-weight: 500;
        color: var(--text-light);
    }
    
    /* Table Styling */
    .table {
        margin-bottom: 0;
    }
    
    .table thead th {
        border-bottom: 2px solid var(--border-color);
        font-weight: 600;
        color: var(--text-dark);
        padding: 1rem;
        background-color: rgba(44, 90, 160, 0.03);
    }
    
    .table tbody td {
        padding: 1rem;
        vertical-align: middle;
        border-bottom: 1px solid var(--border-color);
    }
    
    .table tbody tr:hover {
        background-color: rgba(44, 90, 160, 0.02);
    }
    
    .table tbody tr.table-secondary:hover {
        background-color: rgba(108, 117, 125, 0.05);
    }
    
    /* Badges */
    .badge {
        padding: 0.35rem 0.65rem;
        font-weight: 500;
        border-radius: 6px;
    }
    
    /* IP Icon */
    .ip-icon {
        width: 40px;
        height: 40px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    /* Empty State */
    .empty-state-icon {
        opacity: 0.5;
    }
    
    /* Buttons */
    .btn {
        border-radius: 8px;
        font-weight: 500;
        transition: all 0.2s ease;
    }
    
    .btn-outline-light:hover {
        background-color: rgba(255, 255, 255, 0.1);
        border-color: white;
    }
    
    /* Responsive Design */
    @media (max-width: 768px) {
        .card-header {
            flex-direction: column;
            align-items: flex-start;
            gap: 0.75rem;
        }
        
        .card-header h5 {
            width: 100%;
            margin-bottom: 0.5rem;
        }
        
        .card-header .d-flex {
            width: 100%;
            justify-content: space-between;
        }
        
        .table-responsive {
            border: 1px solid var(--border-color);
            border-radius: 8px;
            overflow-x: auto;
        }
        
        .table {
            min-width: 800px;
        }
        
        .stat-number {
            font-size: 1.25rem;
        }
        
        .stat-icon {
            width: 40px;
            height: 40px;
        }
    }
    
    @media (max-width: 576px) {
        .card-body {
            padding: 1rem !important;
        }
        
        .row.mb-4 .col-md-4 {
            width: 100%;
            margin-bottom: 0.75rem;
        }
        
        .table tbody td, 
        .table thead th {
            padding: 0.75rem 0.5rem;
            font-size: 0.875rem;
        }
        
        .badge {
            font-size: 0.75rem;
            padding: 0.25rem 0.5rem;
        }
        
        .btn {
            padding: 0.375rem 0.75rem;
            font-size: 0.875rem;
        }
        
        .btn-sm {
            padding: 0.25rem 0.5rem;
            font-size: 0.8rem;
        }
        
        .d-flex.gap-2 {
            flex-wrap: wrap;
            gap: 0.5rem !important;
        }
        
        .text-end {
            text-align: center !important;
        }
        
        .d-flex.justify-content-between {
            flex-direction: column;
            gap: 1rem;
            text-align: center;
        }
        
        .d-flex.justify-content-between > div {
            width: 100%;
        }
    }
    
    @media (max-width: 375px) {
        .card-body {
            padding: 0.75rem !important;
        }
        
        .stat-icon {
            width: 35px;
            height: 35px;
        }
        
        .ip-icon {
            width: 35px;
            height: 35px;
        }
        
        .btn {
            width: 100%;
            margin-bottom: 0.5rem;
        }
        
        .d-flex.gap-2 {
            flex-direction: column;
        }
    }
</style>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Add confirmation for unblock actions
        const unblockButtons = document.querySelectorAll('a[href*="/Auth/unblockIP/"]');
        unblockButtons.forEach(button => {
            button.addEventListener('click', function(e) {
                if (!confirm('Are you sure you want to unblock this IP address?')) {
                    e.preventDefault();
                    return false;
                }
            });
        });
        
        // Add row hover effect
        const tableRows = document.querySelectorAll('.table tbody tr');
        tableRows.forEach(row => {
            row.addEventListener('mouseenter', function() {
                this.style.transition = 'all 0.2s ease';
            });
        });
        
        // Auto-refresh expired status badges
        function updateExpiredStatus() {
            const now = new Date().getTime();
            const statusBadges = document.querySelectorAll('.badge');
            
            statusBadges.forEach(badge => {
                if (badge.textContent.includes('Until')) {
                    // You could add logic here to update expired status
                    // This is a placeholder for future real-time updates
                }
            });
        }
        
        // Update every minute
        setInterval(updateExpiredStatus, 60000);
    });
</script>

<?= $this->endSection() ?>