<?php
// Register page for Pensioner Association Management System
$systemName = "Pensioner Association Management System";
$systemVersion = "v2.1";
?>

<?= $this->extend('layouts/login_base') ?>

<?= $this->section('content') ?>

<style>
    :root {
        --primary: #2c3e50;
        --secondary: #3498db;
        --accent: #1abc9c;
        --light: #f8f9fa;
        --dark: #343a40;
        --warning: #f39c12;
        --danger: #e74c3c;
        --success: #27ae60;
    }
    
    body {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        min-height: 100vh;
        font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 20px;
    }
    
    /* Main Container */
    .auth-container {
        max-width: 500px;
        width: 100%;
    }
    
    /* Card */
    .auth-card {
        background: rgba(255, 255, 255, 0.95);
        border-radius: 15px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.3);
        overflow: hidden;
    }
    
    /* Header */
    .auth-header {
        background: linear-gradient(135deg, var(--primary), var(--secondary));
        color: white;
        padding: 30px;
        border-radius: 15px 15px 0 0;
        text-align: center;
    }
    
    .auth-logo {
        width: 80px;
        height: 80px;
        background: white;
        border-radius: 50%;
        margin: 0 auto 20px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--primary);
        font-size: 2rem;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
    }
    
    .auth-title {
        font-size: 1.8rem;
        font-weight: 600;
        margin-bottom: 8px;
    }
    
    .auth-subtitle {
        font-size: 1rem;
        opacity: 0.9;
    }
    
    /* Body */
    .auth-body {
        padding: 30px;
    }
    
    /* Alerts */
    .alert {
        border-radius: 8px;
        border: none;
        padding: 15px 20px;
        margin-bottom: 25px;
        display: flex;
        align-items: flex-start;
        gap: 12px;
    }
    
    .alert-error {
        background: rgba(231, 76, 60, 0.1);
        color: var(--danger);
        border-left: 4px solid var(--danger);
    }
    
    .alert-success {
        background: rgba(39, 174, 96, 0.1);
        color: var(--success);
        border-left: 4px solid var(--success);
    }
    
    .alert-info {
        background: rgba(52, 152, 219, 0.1);
        color: var(--secondary);
        border-left: 4px solid var(--secondary);
    }
    
    .alert-icon {
        font-size: 1.2rem;
        flex-shrink: 0;
    }
    
    .alert-content {
        flex: 1;
    }
    
    .alert-title {
        font-weight: 600;
        margin-bottom: 5px;
        font-size: 1rem;
    }
    
    .alert-message {
        font-size: 0.95rem;
        line-height: 1.5;
    }
    
    /* Form */
    .form-group {
        margin-bottom: 25px;
    }
    
    .form-label {
        display: block;
        color: var(--dark);
        font-weight: 600;
        font-size: 0.95rem;
        margin-bottom: 8px;
    }
    
    .form-control {
        width: 100%;
        border: 2px solid #e9ecef;
        border-radius: 8px;
        padding: 14px 16px;
        font-size: 1rem;
        transition: all 0.3s;
        background: white;
    }
    
    .form-control:focus {
        border-color: var(--accent);
        outline: none;
        box-shadow: 0 0 0 0.2rem rgba(26, 188, 156, 0.25);
    }
    
    .input-group {
        position: relative;
    }
    
    /* Password Toggle */
    .password-toggle {
        position: absolute;
        right: 15px;
        top: 50%;
        transform: translateY(-50%);
        background: none;
        border: none;
        color: #6c757d;
        cursor: pointer;
        padding: 4px;
        transition: color 0.3s;
    }
    
    .password-toggle:hover {
        color: var(--primary);
    }
    
    /* Password Strength */
    .password-strength {
        margin-top: 5px;
        font-size: 0.85rem;
        display: flex;
        flex-direction: column;
        gap: 5px;
    }
    
    .strength-bar {
        height: 4px;
        background: #e9ecef;
        border-radius: 2px;
        overflow: hidden;
        margin-top: 3px;
    }
    
    .strength-fill {
        height: 100%;
        border-radius: 2px;
        transition: all 0.3s ease;
    }
    
    .strength-weak {
        color: var(--danger);
    }
    
    .strength-medium {
        color: var(--warning);
    }
    
    .strength-strong {
        color: var(--accent);
    }
    
    /* Password Match */
    .password-match {
        margin-top: 5px;
        font-size: 0.85rem;
    }
    
    .match-success {
        color: var(--accent);
    }
    
    .match-error {
        color: var(--danger);
    }
    
    /* Terms & Conditions */
    .terms-check {
        display: flex;
        align-items: flex-start;
        margin: 25px 0;
        gap: 8px;
    }
    
    .form-check-input {
        width: 18px;
        height: 18px;
        border: 2px solid #ced4da;
        border-radius: 4px;
        cursor: pointer;
        margin: 3px 0 0 0;
        flex-shrink: 0;
    }
    
    .form-check-input:checked {
        background-color: var(--accent);
        border-color: var(--accent);
    }
    
    .form-check-label {
        color: var(--dark);
        font-size: 0.95rem;
        cursor: pointer;
        user-select: none;
        line-height: 1.4;
    }
    
    .terms-link {
        color: var(--secondary);
        text-decoration: none;
        font-weight: 600;
    }
    
    .terms-link:hover {
        color: var(--primary);
        text-decoration: underline;
    }
    
    /* Submit Button */
    .btn-primary {
        background: linear-gradient(135deg, var(--primary), var(--secondary));
        border: none;
        padding: 16px;
        border-radius: 8px;
        font-weight: 600;
        transition: all 0.3s;
        color: white;
        font-size: 1rem;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
        width: 100%;
    }
    
    .btn-primary:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(52, 152, 219, 0.4);
    }
    
    .btn-primary:disabled {
        opacity: 0.6;
        cursor: not-allowed;
        transform: none;
        box-shadow: none;
    }
    
    /* Links */
    .auth-links {
        display: flex;
        justify-content: center;
        align-items: center;
        margin: 25px 0 0;
        padding-top: 20px;
        border-top: 1px solid #e9ecef;
    }
    
    .auth-link {
        color: var(--secondary);
        text-decoration: none;
        font-size: 0.95rem;
        font-weight: 500;
        transition: color 0.3s;
    }
    
    .auth-link:hover {
        color: var(--primary);
        text-decoration: underline;
    }
    
    /* Security Note */
    .security-note {
        background: rgba(26, 188, 156, 0.1);
        border-radius: 8px;
        padding: 16px 20px;
        margin-top: 25px;
        border-left: 4px solid var(--accent);
    }
    
    .security-title {
        font-weight: 600;
        color: var(--primary);
        font-size: 0.95rem;
        margin-bottom: 5px;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    
    .security-text {
        color: var(--dark);
        font-size: 0.9rem;
        line-height: 1.5;
    }
    
    /* Loading */
    .loading {
        display: inline-block;
        width: 20px;
        height: 20px;
        border: 2px solid rgba(255, 255, 255, 0.3);
        border-radius: 50%;
        border-top-color: white;
        animation: spin 1s linear infinite;
    }
    
    @keyframes spin {
        to { transform: rotate(360deg); }
    }
    
    /* Validation */
    .error-message {
        color: var(--danger);
        font-size: 0.85rem;
        margin-top: 8px;
        display: none;
    }
    
    .form-control.invalid {
        border-color: var(--danger);
        background: rgba(231, 76, 60, 0.05);
    }
    
    .form-control.invalid + .error-message {
        display: block;
    }
    
    /* Responsive */
    @media (max-width: 576px) {
        body {
            padding: 15px;
        }
        
        .auth-container {
            margin: 0 auto;
            padding: 0;
        }
        
        .auth-header {
            padding: 25px 20px;
        }
        
        .auth-body {
            padding: 25px 20px;
        }
        
        .auth-logo {
            width: 70px;
            height: 70px;
            font-size: 1.8rem;
        }
        
        .auth-title {
            font-size: 1.6rem;
        }
        
        .auth-subtitle {
            font-size: 0.95rem;
        }
        
        .form-control {
            padding: 12px 14px;
            font-size: 16px;
        }
        
        .btn-primary {
            padding: 14px;
        }
        
        .terms-check {
            margin: 20px 0;
        }
        
        .form-check-label {
            font-size: 0.9rem;
        }
    }
    
    @media (max-width: 360px) {
        .auth-header {
            padding: 20px 15px;
        }
        
        .auth-body {
            padding: 20px 15px;
        }
        
        .auth-title {
            font-size: 1.4rem;
        }
        
        .form-control {
            padding: 12px 14px;
            font-size: 16px;
        }
        
        .btn-primary {
            padding: 14px;
        }
        
        .form-check-label {
            font-size: 0.85rem;
        }
    }
    
    /* Touch device optimizations */
    @media (hover: none) {
        .btn-primary:hover {
            transform: none;
            box-shadow: none;
        }
        
        .auth-link:hover {
            color: var(--secondary);
        }
        
        .terms-link:hover {
            color: var(--secondary);
            text-decoration: none;
        }
    }
</style>

<div class="auth-container">
    <div class="auth-card">
        <!-- Header -->
        <div class="auth-header">
            <div class="auth-logo">
                <i class="fas fa-hand-holding-heart"></i>
            </div>
            <h3 class="auth-title">PensionerMS</h3>
            <p class="auth-subtitle">Create Your Account</p>
        </div>
        
        <!-- Body -->
        <div class="auth-body">
            <!-- Alert Messages -->
            <?php if($session->getFlashdata('error')): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-triangle alert-icon"></i>
                    <div class="alert-content">
                        <div class="alert-title">Registration Failed</div>
                        <div class="alert-message"><?= $session->getFlashdata('error') ?></div>
                    </div>
                </div>
            <?php endif; ?>
            
            <?php if($session->getFlashdata('success')): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle alert-icon"></i>
                    <div class="alert-content">
                        <div class="alert-title">Success</div>
                        <div class="alert-message"><?= $session->getFlashdata('success') ?></div>
                    </div>
                </div>
            <?php endif; ?>
            
            <!-- Registration Form -->
            <form action="<?= base_url('register') ?>" method="POST" id="registerForm">
                <!-- Name -->
                <div class="form-group">
                    <label for="name" class="form-label">
                        <i class="fas fa-user me-2"></i>Full Name
                    </label>
                    <input type="text"
                           class="form-control"
                           id="name"
                           name="name"
                           placeholder="Enter your full name"
                           value="<?= !empty($data->getPost('name')) ? esc($data->getPost('name')) : '' ?>"
                           required
                           autocomplete="name">
                    <div class="error-message" id="nameError"></div>
                </div>
                
                <!-- Email -->
                <div class="form-group">
                    <label for="email" class="form-label">
                        <i class="fas fa-envelope me-2"></i>Email Address
                    </label>
                    <input type="email"
                           class="form-control"
                           id="email"
                           name="email"
                           placeholder="Enter your email"
                           value="<?= !empty($data->getPost('email')) ? esc($data->getPost('email')) : '' ?>"
                           required
                           autocomplete="username">
                    <div class="error-message" id="emailError"></div>
                </div>
                
                <!-- Password -->
                <div class="form-group">
                    <label for="password" class="form-label">
                        <i class="fas fa-lock me-2"></i>Password
                    </label>
                    <div class="input-group">
                        <input type="password"
                               class="form-control"
                               id="password"
                               name="password"
                               placeholder="Create a password"
                               required
                               autocomplete="new-password">
                        <button type="button" class="password-toggle" id="togglePassword" aria-label="Show password">
                            <i class="far fa-eye"></i>
                        </button>
                    </div>
                    <div class="error-message" id="passwordError"></div>
                    <div class="password-strength">
                        <div id="strengthText"></div>
                        <div class="strength-bar">
                            <div class="strength-fill" id="strengthBar"></div>
                        </div>
                    </div>
                </div>
                
                <!-- Confirm Password -->
                <div class="form-group">
                    <label for="cpassword" class="form-label">
                        <i class="fas fa-lock me-2"></i>Confirm Password
                    </label>
                    <div class="input-group">
                        <input type="password"
                               class="form-control"
                               id="cpassword"
                               name="cpassword"
                               placeholder="Confirm your password"
                               required
                               autocomplete="new-password">
                        <button type="button" class="password-toggle" id="toggleCPassword" aria-label="Show password">
                            <i class="far fa-eye"></i>
                        </button>
                    </div>
                    <div class="error-message" id="cpasswordError"></div>
                    <div class="password-match" id="passwordMatch"></div>
                </div>
                
                <!-- Terms & Conditions -->
                <div class="terms-check">
                    <input type="checkbox" class="form-check-input" id="terms" name="terms" required>
                    <label for="terms" class="form-check-label">
                        I agree to the <a href="#" class="terms-link" data-bs-toggle="modal" data-bs-target="#termsModal">Terms & Conditions</a> 
                        and <a href="#" class="terms-link" data-bs-toggle="modal" data-bs-target="#privacyModal">Privacy Policy</a>
                    </label>
                </div>
                
                <!-- Submit Button -->
                <button type="submit" class="btn btn-primary" id="registerButton">
                    <i class="fas fa-user-plus"></i>
                    <span id="buttonText">Create Account</span>
                    <span id="loadingIcon" class="loading" style="display: none;"></span>
                </button>
                
                <!-- Links -->
                <div class="auth-links">
                    <a href="<?= site_url('/') ?>" class="auth-link">
                        <i class="fas fa-sign-in-alt me-1"></i>Already have an account? Login
                    </a>
                </div>
                
                <!-- Security Note -->
                <div class="security-note">
                    <div class="security-title">
                        <i class="fas fa-shield-alt"></i>
                        <span>Secure Registration</span>
                    </div>
                    <div class="security-text">
                        Your information is protected with 256-bit SSL encryption. 
                        All data is securely stored and never shared with third parties.
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Terms & Conditions Modal -->
<div class="modal fade" id="termsModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fas fa-file-contract me-2"></i>Terms & Conditions</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p><strong>Welcome to PensionerMS</strong></p>
                <p>By creating an account, you agree to:</p>
                <ul class="mb-3">
                    <li>Use the system responsibly for pensioner association management</li>
                    <li>Keep your login credentials secure and confidential</li>
                    <li>Respect the privacy of other members</li>
                    <li>Not share sensitive pensioner information</li>
                    <li>Comply with data protection regulations</li>
                    <li>Report any security concerns immediately</li>
                </ul>
                <p>We reserve the right to suspend accounts that violate these terms.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Privacy Policy Modal -->
<div class="modal fade" id="privacyModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fas fa-user-shield me-2"></i>Privacy Policy</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p><strong>Your Privacy Matters</strong></p>
                <p>We are committed to protecting your personal information:</p>
                <ul class="mb-3">
                    <li>Your personal information is encrypted using industry-standard security</li>
                    <li>We never share your data with third parties without consent</li>
                    <li>All pensioner data is protected with strict access controls</li>
                    <li>You have the right to access, modify, or delete your information</li>
                    <li>We conduct regular security audits and updates</li>
                    <li>Cookies are used only for essential system functionality</li>
                </ul>
                <p>For more information, contact our support team.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

<script>
    // Password toggle functions
    const togglePassword = document.getElementById('togglePassword');
    const passwordInput = document.getElementById('password');
    
    if (togglePassword) {
        togglePassword.addEventListener('click', function() {
            const type = passwordInput.type === 'password' ? 'text' : 'password';
            passwordInput.type = type;
            
            const icon = this.querySelector('i');
            if (type === 'text') {
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
                this.setAttribute('aria-label', 'Hide password');
            } else {
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
                this.setAttribute('aria-label', 'Show password');
            }
        });
    }
    
    const toggleCPassword = document.getElementById('toggleCPassword');
    const cpasswordInput = document.getElementById('cpassword');
    
    if (toggleCPassword) {
        toggleCPassword.addEventListener('click', function() {
            const type = cpasswordInput.type === 'password' ? 'text' : 'password';
            cpasswordInput.type = type;
            
            const icon = this.querySelector('i');
            if (type === 'text') {
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
                this.setAttribute('aria-label', 'Hide password');
            } else {
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
                this.setAttribute('aria-label', 'Show password');
            }
        });
    }
    
    // Password strength checker
    document.getElementById('password').addEventListener('input', function() {
        const password = this.value;
        const strengthBar = document.getElementById('strengthBar');
        const strengthText = document.getElementById('strengthText');
        
        let strength = 0;
        let color = '#e74c3c';
        let text = '';
        
        // Check password criteria
        if (password.length >= 8) strength += 20;
        if (password.length >= 12) strength += 10;
        if (/[A-Z]/.test(password)) strength += 20;
        if (/[a-z]/.test(password)) strength += 20;
        if (/[0-9]/.test(password)) strength += 20;
        if (/[^A-Za-z0-9]/.test(password)) strength += 10;
        
        // Limit to 100%
        strength = Math.min(strength, 100);
        
        // Update bar and text
        strengthBar.style.width = strength + '%';
        
        if (strength < 40) {
            color = '#e74c3c';
            text = '<span class="strength-weak">Weak password</span>';
        } else if (strength < 70) {
            color = '#f39c12';
            text = '<span class="strength-medium">Medium password</span>';
        } else {
            color = '#1abc9c';
            text = '<span class="strength-strong">Strong password</span>';
        }
        
        strengthBar.style.background = color;
        strengthText.innerHTML = text;
        
        // Hide if empty
        if (password.length === 0) {
            strengthText.innerHTML = '';
            strengthBar.style.width = '0%';
        }
    });
    
    // Password confirmation checker
    document.getElementById('cpassword').addEventListener('input', function() {
        const password = document.getElementById('password').value;
        const confirmPassword = this.value;
        const matchDiv = document.getElementById('passwordMatch');
        
        if (confirmPassword.length === 0) {
            matchDiv.innerHTML = '';
        } else if (password === confirmPassword) {
            matchDiv.innerHTML = '<span class="match-success">✓ Passwords match</span>';
        } else {
            matchDiv.innerHTML = '<span class="match-error">✗ Passwords do not match</span>';
        }
    });
    
    // Form validation
    const registerForm = document.getElementById('registerForm');
    const registerButton = document.getElementById('registerButton');
    
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Clear previous errors
            clearErrors();
            
            // Get values
            const name = document.getElementById('name').value.trim();
            const email = document.getElementById('email').value.trim();
            const password = document.getElementById('password').value.trim();
            const cpassword = document.getElementById('cpassword').value.trim();
            const terms = document.getElementById('terms').checked;
            
            let hasError = false;
            
            // Validate name
            if (!name) {
                showError('name', 'Full name is required');
                hasError = true;
            } else if (name.length < 2) {
                showError('name', 'Name must be at least 2 characters');
                hasError = true;
            }
            
            // Validate email
            if (!email) {
                showError('email', 'Email is required');
                hasError = true;
            } else if (!isValidEmail(email)) {
                showError('email', 'Please enter a valid email address');
                hasError = true;
            }
            
            // Validate password
            if (!password) {
                showError('password', 'Password is required');
                hasError = true;
            } else if (password.length < 8) {
                showError('password', 'Password must be at least 8 characters long');
                hasError = true;
            }
            
            // Validate confirm password
            if (!cpassword) {
                showError('cpassword', 'Please confirm your password');
                hasError = true;
            } else if (password !== cpassword) {
                showError('cpassword', 'Passwords do not match');
                hasError = true;
            }
            
            // Validate terms
            if (!terms) {
                alert('Please agree to the Terms & Conditions and Privacy Policy');
                hasError = true;
            }
            
            if (hasError) {
                return;
            }
            
            // Show loading
            showLoading();
            
            // Submit form
            setTimeout(() => {
                registerForm.submit();
            }, 1000);
        });
    }
    
    // Helper functions
    function isValidEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }
    
    function showError(field, message) {
        const input = document.getElementById(field);
        const errorElement = document.getElementById(field + 'Error');
        
        if (input && errorElement) {
            input.classList.add('invalid');
            errorElement.textContent = message;
            errorElement.style.display = 'block';
        }
    }
    
    function clearErrors() {
        const inputs = document.querySelectorAll('.form-control');
        inputs.forEach(input => {
            input.classList.remove('invalid');
        });
        
        const errors = document.querySelectorAll('.error-message');
        errors.forEach(error => {
            error.textContent = '';
            error.style.display = 'none';
        });
    }
    
    function showLoading() {
        const buttonText = document.getElementById('buttonText');
        const loadingIcon = document.getElementById('loadingIcon');
        
        if (registerButton && buttonText && loadingIcon) {
            registerButton.disabled = true;
            buttonText.textContent = 'Creating Account...';
            loadingIcon.style.display = 'inline-block';
        }
    }
    
    // Forgot password modal functions
    function showForgotPassword() {
        const modal = new bootstrap.Modal(document.getElementById('forgotPasswordModal'));
        modal.show();
    }
    
    // Auto-focus name on load
    document.addEventListener('DOMContentLoaded', function() {
        const nameField = document.getElementById('name');
        if (nameField) {
            nameField.focus();
        }
        
        // Initialize Bootstrap modals
        if (typeof bootstrap !== 'undefined') {
            const termsModal = document.getElementById('termsModal');
            const privacyModal = document.getElementById('privacyModal');
            
            if (termsModal) new bootstrap.Modal(termsModal);
            if (privacyModal) new bootstrap.Modal(privacyModal);
        }
    });
    
    // Real-time validation
    const nameInput = document.getElementById('name');
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');
    const cpasswordInput = document.getElementById('cpassword');
    
    if (nameInput) {
        nameInput.addEventListener('blur', function() {
            if (this.value.trim() && this.value.trim().length < 2) {
                showError('name', 'Name must be at least 2 characters');
            } else {
                this.classList.remove('invalid');
                document.getElementById('nameError').style.display = 'none';
            }
        });
    }
    
    if (emailInput) {
        emailInput.addEventListener('blur', function() {
            if (this.value.trim() && !isValidEmail(this.value.trim())) {
                showError('email', 'Please enter a valid email address');
            } else {
                this.classList.remove('invalid');
                document.getElementById('emailError').style.display = 'none';
            }
        });
    }
    
    if (passwordInput) {
        passwordInput.addEventListener('blur', function() {
            if (this.value.trim() && this.value.length < 8) {
                showError('password', 'Password must be at least 8 characters');
            } else {
                this.classList.remove('invalid');
                document.getElementById('passwordError').style.display = 'none';
            }
        });
    }
    
    if (cpasswordInput) {
        cpasswordInput.addEventListener('blur', function() {
            const password = document.getElementById('password').value;
            if (this.value.trim() && this.value !== password) {
                showError('cpassword', 'Passwords do not match');
            } else {
                this.classList.remove('invalid');
                document.getElementById('cpasswordError').style.display = 'none';
            }
        });
    }
    
    // Enter key submits form
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' && registerForm) {
            registerForm.dispatchEvent(new Event('submit'));
        }
    });
</script>

<?= $this->endSection() ?>