<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title ?> - Pension Management System</title>
    <!-- Add your CSS links here -->
</head>
<body>
    <div class="container">
        <h2>User IP Addresses</h2>
        
        <form method="post" action="<?= base_url('/Auth/userIPs') ?>" class="mb-4">
            <div class="form-group">
                <label>Select User</label>
                <select name="user_id" class="form-control" onchange="this.form.submit()">
                    <option value="">-- Select User --</option>
                    <?php foreach($users as $user): ?>
                        <option value="<?= $user['id'] ?>" 
                                <?= isset($user_id) && $user_id == $user['id'] ? 'selected' : '' ?>>
                            <?= esc($user['name']) ?> (<?= esc($user['email']) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </form>
        
        <?php if(isset($user) && isset($user_ips)): ?>
            <h3>IP Addresses used by <?= esc($user['name']) ?></h3>
            
            <?php if(empty($user_ips)): ?>
                <p>No IP addresses found for this user.</p>
            <?php else: ?>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>IP Address</th>
                            <th>Last Used</th>
                            <th>Login Count</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($user_ips as $ip): ?>
                            <tr>
                                <td><?= esc($ip['ip_address']) ?></td>
                                <td><?= $ip['last_used'] ? date('M d, Y H:i', strtotime($ip['last_used'])) : 'Never' ?></td>
                                <td><?= $ip['login_count'] ?></td>
                                <td>
                                    <a href="<?= base_url('/Auth/blockIP') ?>?ip=<?= urlencode($ip['ip_address']) ?>" 
                                       class="btn btn-sm btn-danger">
                                        Block This IP
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</body>
</html>