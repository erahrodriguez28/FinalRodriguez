<h2>Book: <?= $place['name'] ?></h2>

<form action="<?= site_url('/booking/store') ?>" method="POST">

    <input type="hidden" name="place_id" value="<?= $place['place_id'] ?>">

    <label>Booking Date:</label>
    <input type="date" name="booking_date" required><br><br>

    <label>Note:</label>
    <textarea name="note"></textarea><br><br>

    <button type="submit">Confirm Booking</button>
</form>

<br>
<a href="<?= site_url('/places') ?>">Cancel</a>
