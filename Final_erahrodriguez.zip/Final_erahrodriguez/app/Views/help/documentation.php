<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="container-fluid px-4">


    <div class="row">
        <div class="col-12">
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <div class="text-center py-5">
                        <i class="fas fa-book-open fa-4x text-primary mb-3"></i>
                        <h3>Documentation Coming Soon</h3>
                        <p class="text-muted">We're currently preparing comprehensive documentation for the system.</p>
                        <a href="<?= base_url($isAdmin ? '/admin/help' : '/help') ?>" class="btn btn-primary mt-3">
                            <i class="fas fa-arrow-left me-2"></i>Back to Help Center
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>