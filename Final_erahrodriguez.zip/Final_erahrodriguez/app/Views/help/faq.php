<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="container-fluid px-4">
    <div class="page-header bg-white rounded-3 shadow-sm mb-4">
        <div class="row align-items-center py-3">
            <div class="col-md-8">
                <div class="d-flex align-items-center">
                    <div class="help-icon bg-primary-gradient rounded-circle p-3 me-3">
                        <i class="fas fa-list-alt fa-2x text-white"></i>
                    </div>
                    <div>
                        <h1 class="h3 mb-1 text-gray-800 fw-bold"><?= $page_title ?></h1>
                        <p class="text-muted mb-0">Frequently asked questions about the Pensioner Association Management System</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <?php if(isset($faqs) && !empty($faqs)): ?>
                        <div class="accordion" id="faqAccordion">
                            <?php foreach($faqs as $index => $faq): ?>
                                <div class="accordion-item border-0 mb-3">
                                    <h2 class="accordion-header" id="heading<?= $index ?>">
                                        <button class="accordion-button collapsed py-3" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?= $index ?>">
                                            <i class="fas fa-question-circle text-primary me-3"></i>
                                            <?= $faq['question'] ?>
                                        </button>
                                    </h2>
                                    <div id="collapse<?= $index ?>" class="accordion-collapse collapse">
                                        <div class="accordion-body pt-2">
                                            <div class="d-flex">
                                                <div class="flex-shrink-0">
                                                    <i class="fas fa-lightbulb text-warning mt-1 me-3"></i>
                                                </div>
                                                <div class="flex-grow-1">
                                                    <?= $faq['answer'] ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="fas fa-info-circle fa-3x text-muted mb-3"></i>
                            <h4>No FAQs Available</h4>
                            <p class="text-muted">FAQs will be added soon.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>