<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="container-fluid px-4">
    <!-- Page Header -->

    <?php if(session()->getFlashdata('success')): ?>
        <div class="alert alert-success alert-dismissible fade show shadow-sm" role="alert">
            <i class="fas fa-check-circle me-2"></i>
            <?= session()->getFlashdata('success') ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <!-- Help Sections -->
    <div class="row mb-4">
        <?php foreach($sections as $index => $section): ?>
            <div class="col-xl-6 col-lg-6 col-md-12 mb-4">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-header bg-white border-bottom-0 py-3">
                        <div class="d-flex align-items-center">
                            <div class="icon-wrapper bg-light-primary rounded-circle p-2 me-3">
                                <i class="fas fa-circle-question text-primary"></i>
                            </div>
                            <h5 class="mb-0 fw-semibold"><?= $section['title'] ?></h5>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="accordion help-accordion" id="accordion<?= $index ?>">
                            <?php $itemIndex = 0; ?>
                            <?php foreach($section['items'] as $question => $answer): ?>
                                <div class="accordion-item border-0">
                                    <h2 class="accordion-header" id="heading<?= $index . $itemIndex ?>">
                                        <button class="accordion-button collapsed py-3" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?= $index . $itemIndex ?>">
                                            <span class="d-flex align-items-center">
                                                <i class="fas fa-circle-question text-primary me-3"></i>
                                                <span class="fw-medium"><?= $question ?></span>
                                            </span>
                                        </button>
                                    </h2>
                                    <div id="collapse<?= $index . $itemIndex ?>" class="accordion-collapse collapse" data-bs-parent="#accordion<?= $index ?>">
                                        <div class="accordion-body pt-2">
                                            <div class="d-flex">
                                                <div class="flex-shrink-0">
                                                    <i class="fas fa-lightbulb text-warning mt-1 me-3"></i>
                                                </div>
                                                <div class="flex-grow-1">
                                                    <?= $answer ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php $itemIndex++; ?>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <!-- Quick Contact Cards -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white py-3">
                    <h5 class="mb-0 fw-semibold">Get in Touch</h5>
                </div>
                <div class="card-body">
                    <div class="row g-4">
                        <div class="col-md-4">
                            <div class="card contact-card border-0 h-100 transition-all">
                                <div class="card-body text-center p-4">
                                    <div class="contact-icon bg-primary-gradient rounded-circle mx-auto mb-3">
                                        <i class="fas fa-envelope fa-2x text-white"></i>
                                    </div>
                                    <h6 class="fw-semibold mb-2">Email Support</h6>
                                    <p class="text-muted mb-3">For general inquiries and support</p>
                                    <a href="mailto:support@pensioner-association.org" class="btn btn-outline-primary btn-sm">
                                        support@pensioner-association.org
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card contact-card border-0 h-100 transition-all">
                                <div class="card-body text-center p-4">
                                    <div class="contact-icon bg-success-gradient rounded-circle mx-auto mb-3">
                                        <i class="fas fa-phone fa-2x text-white"></i>
                                    </div>
                                    <h6 class="fw-semibold mb-2">Phone Support</h6>
                                    <p class="text-muted mb-3">Call us during business hours</p>
                                    <a href="tel:+15551234567" class="btn btn-outline-success btn-sm">
                                        +63 9816 163 775
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card contact-card border-0 h-100 transition-all">
                                <div class="card-body text-center p-4">
                                    <div class="contact-icon bg-warning-gradient rounded-circle mx-auto mb-3">
                                        <i class="fas fa-clock fa-2x text-white"></i>
                                    </div>
                                    <h6 class="fw-semibold mb-2">Office Hours</h6>
                                    <p class="text-muted mb-3">Available for support</p>
                                    <div class="badge bg-warning text-dark px-3 py-2">
                                        Mon - Fri: 9:00 AM - 5:00 PM
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Additional Resources -->
    <div class="row">
        <div class="col-12">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white py-3">
                    <h5 class="mb-0 fw-semibold">Additional Resources</h5>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-3 col-sm-6">
                                <div class="card border h-100 hover-lift">
                                    <div class="card-body text-center p-4">
                                        <div class="resource-icon mb-3">
                                            <i class="fas fa-book fa-3x text-primary"></i>
                                        </div>
                                        <h6 class="fw-semibold mb-2">Documentation</h6>
                                        <p class="text-muted small">Complete system guides and manuals</p>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-3 col-sm-6">
                                <div class="card border h-100 hover-lift">
                                    <div class="card-body text-center p-4">
                                        <div class="resource-icon mb-3">
                                            <i class="fas fa-video fa-3x text-danger"></i>
                                        </div>
                                        <h6 class="fw-semibold mb-2">Video Tutorials</h6>
                                        <p class="text-muted small">Step-by-step video guides</p>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-3 col-sm-6">
                                <div class="card border h-100 hover-lift">
                                    <div class="card-body text-center p-4">
                                        <div class="resource-icon mb-3">
                                            <i class="fas fa-list-alt fa-3x text-success"></i>
                                        </div>
                                        <h6 class="fw-semibold mb-2">FAQ</h6>
                                        <p class="text-muted small">Frequently asked questions</p>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-3 col-sm-6">
                                <div class="card border h-100 hover-lift">
                                    <div class="card-body text-center p-4">
                                        <div class="resource-icon mb-3">
                                            <i class="fas fa-headset fa-3x text-info"></i>
                                        </div>
                                        <h6 class="fw-semibold mb-2">Contact Form</h6>
                                        <p class="text-muted small">Send us a message directly</p>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('styles') ?>
<style>
    /* Professional Color Scheme */
    :root {
        --primary-gradient: linear-gradient(135deg, #4e54c8 0%, #8f94fb 100%);
        --success-gradient: linear-gradient(135deg, #00b09b 0%, #96c93d 100%);
        --warning-gradient: linear-gradient(135deg, #f7971e 0%, #ffd200 100%);
        --light-primary: #f0f5ff;
    }

    /* Page Header */
    .page-header {
        border-left: 4px solid #4e54c8;
    }

    .help-icon {
        background: var(--primary-gradient);
    }

    /* Accordion Styles */
    .help-accordion .accordion-button {
        background-color: var(--light-primary);
        border-radius: 8px !important;
        margin-bottom: 8px;
        border: 1px solid #e0e0e0;
    }

    .help-accordion .accordion-button:not(.collapsed) {
        background-color: #e8f4ff;
        color: #2c3e50;
        box-shadow: 0 2px 8px rgba(0, 123, 255, 0.1);
    }

    .help-accordion .accordion-button:focus {
        box-shadow: 0 0 0 0.25rem rgba(78, 84, 200, 0.25);
        border-color: #4e54c8;
    }

    /* Contact Icons */
    .contact-icon {
        width: 70px;
        height: 70px;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .bg-primary-gradient {
        background: var(--primary-gradient) !important;
    }

    .bg-success-gradient {
        background: var(--success-gradient) !important;
    }

    .bg-warning-gradient {
        background: var(--warning-gradient) !important;
    }

    /* Cards */
    .contact-card {
        transition: all 0.3s ease;
        background: #f8fafc;
    }

    .contact-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1) !important;
    }

    /* Resource Cards */
    .resource-card .card {
        transition: all 0.3s ease;
        background: white;
    }

    .resource-card:hover .card {
        transform: translateY(-5px);
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        border-color: #4e54c8;
    }

    .hover-lift:hover {
        transform: translateY(-5px);
        transition: transform 0.2s ease;
    }

    /* Icon Wrapper */
    .icon-wrapper {
        width: 40px;
        height: 40px;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    /* Smooth transitions */
    .transition-all {
        transition: all 0.3s ease;
    }

    /* Alert styling */
    .alert {
        border: none;
        border-left: 4px solid #28a745;
    }

    /* Breadcrumb styling */
    .breadcrumb {
        background: transparent;
        padding: 0;
        margin: 0;
    }

    .breadcrumb-item a {
        color: #6c757d;
        text-decoration: none;
    }

    .breadcrumb-item a:hover {
        color: #4e54c8;
    }

    /* Button styling */
    .btn-outline-primary {
        border-width: 1px;
    }

    .btn-outline-primary:hover {
        background-color: #4e54c8;
        border-color: #4e54c8;
    }

    /* Text colors */
    .text-gray-800 {
        color: #2c3e50;
    }
</style>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Initialize tooltips
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });

        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({ behavior: 'smooth' });
                }
            });
        });

        // Auto-open first accordion item on page load
        const firstAccordionButton = document.querySelector('.help-accordion .accordion-button');
        if (firstAccordionButton) {
            firstAccordionButton.click();
        }

        // Add animation to resource cards on hover
        document.querySelectorAll('.resource-card').forEach(card => {
            card.addEventListener('mouseenter', function() {
                this.querySelector('.resource-icon i').style.transform = 'scale(1.1)';
            });
            
            card.addEventListener('mouseleave', function() {
                this.querySelector('.resource-icon i').style.transform = 'scale(1)';
            });
        });
    });
</script>
<?= $this->endSection() ?>