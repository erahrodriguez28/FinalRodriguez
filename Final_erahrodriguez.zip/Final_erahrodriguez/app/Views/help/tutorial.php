<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="container-fluid px-4">
    <div class="page-header bg-white rounded-3 shadow-sm mb-4">
        <div class="row align-items-center py-3">
            <div class="col-md-8">
                <div class="d-flex align-items-center">
                    <div class="help-icon bg-primary-gradient rounded-circle p-3 me-3">
                        <i class="fas fa-video fa-2x text-white"></i>
                    </div>
                    <div>
                        <h1 class="h3 mb-1 text-gray-800 fw-bold"><?= $page_title ?></h1>
                        <p class="text-muted mb-0">Video tutorials and guides for the Pensioner Association Management System</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <div class="text-center py-5">
                        <i class="fas fa-video-slash fa-4x text-primary mb-3"></i>
                        <h3>Tutorials Coming Soon</h3>
                        <p class="text-muted">We're currently preparing video tutorials for the system.</p>
                        <a href="<?= base_url($isAdmin ? '/admin/help' : '/help') ?>" class="btn btn-primary mt-3">
                            <i class="fas fa-arrow-left me-2"></i>Back to Help Center
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>