<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($page_title) ? $page_title.' | ' : "" ?><?= env('system_name') ?></title>

    <!-- Bootstrap 5 CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <!-- Google Fonts - More Professional -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Source+Sans+Pro:wght@400;500;600&display=swap" rel="stylesheet">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

    <style>
        :root {
            --primary: #2c5aa0; /* Professional blue */
            --primary-dark: #1e3a6f;
            --primary-light: #4a7fd4;
            --secondary: #00695c; /* Teal for accents */
            --accent: #d32f2f; /* Subtle red for alerts/actions */
            --light-bg: #f8fafc;
            --card-bg: #ffffff;
            --border-color: #e2e8f0;
            --text-dark: #1e293b;
            --text-medium: #475569;
            --text-light: #64748b;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --info: #3b82f6;
        }
        
        body {
            font-family: 'Inter', 'Source Sans Pro', sans-serif;
            background-color: var(--light-bg);
            color: var(--text-dark);
            font-size: 15px;
            line-height: 1.6;
            min-height: 100vh;
            display: flex;
            font-weight: 400;
        }

        /* Sidebar - Professional Redesign */
        .sidebar {
            width: 260px;
            background: var(--card-bg);
            color: var(--text-dark);
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            z-index: 1000;
            transition: transform 0.3s ease;
            display: flex;
            flex-direction: column;
            overflow-y: auto;
            border-right: 1px solid var(--border-color);
            box-shadow: 2px 0 8px rgba(0, 0, 0, 0.05);
        }

        .sidebar-header {
            padding: 24px 20px;
            border-bottom: 1px solid var(--border-color);
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
        }

        .system-logo {
            display: flex;
            align-items: center;
            justify-content: flex-start;
            gap: 12px;
            text-decoration: none;
            color: white;
        }

        .system-logo i {
            font-size: 26px;
            color: white;
            background: rgba(255, 255, 255, 0.15);
            width: 44px;
            height: 44px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .system-logo .logo-text {
            font-size: 20px;
            font-weight: 700;
            color: white;
            letter-spacing: 0.3px;
        }

        .sidebar-subtitle {
            color: rgba(255, 255, 255, 0.85);
            font-size: 13px;
            font-weight: 500;
            margin-top: 5px;
            margin-left: 56px;
        }

        .sidebar-nav {
            padding: 20px 0;
            flex-grow: 1;
        }

        .nav-item {
            padding: 0 16px;
            margin-bottom: 4px;
        }

        .nav-link {
            color: var(--text-medium);
            padding: 12px 16px;
            border-radius: 8px;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: all 0.2s ease;
            font-weight: 500;
            border-left: 3px solid transparent;
        }

        .nav-link i {
            width: 20px;
            text-align: center;
            color: var(--text-light);
            font-size: 16px;
        }

        .nav-link:hover {
            background: rgba(44, 90, 160, 0.05);
            color: var(--primary);
            border-left-color: var(--primary-light);
        }

        .nav-link:hover i {
            color: var(--primary);
        }

        .nav-link.active {
            background: rgba(44, 90, 160, 0.1);
            color: var(--primary);
            font-weight: 600;
            border-left-color: var(--primary);
        }

        .nav-link.active i {
            color: var(--primary);
        }

        /* User Profile */
        .sidebar-footer {
            padding: 20px 16px;
            border-top: 1px solid var(--border-color);
            background: var(--card-bg);
        }

        .user-profile {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px;
            border-radius: 10px;
            cursor: pointer;
            transition: all 0.3s ease;
            border: 1px solid var(--border-color);
        }

        .user-profile:hover {
            background: rgba(44, 90, 160, 0.05);
            border-color: var(--primary-light);
        }

        .user-avatar {
            width: 42px;
            height: 42px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            font-size: 16px;
        }

        .user-info {
            flex: 1;
            min-width: 0;
        }

        .user-name {
            font-weight: 600;
            font-size: 14px;
            color: var(--text-dark);
            margin-bottom: 3px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .user-role {
            font-size: 12px;
            color: var(--text-light);
            font-weight: 500;
        }

        .dropdown-menu {
            border: 1px solid var(--border-color);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            padding: 8px 0;
            min-width: 200px;
        }

        .dropdown-item {
            padding: 10px 16px;
            color: var(--text-dark);
            transition: all 0.2s ease;
            font-weight: 500;
            font-size: 14px;
        }

        .dropdown-item i {
            width: 20px;
            margin-right: 10px;
            color: var(--text-light);
        }

        .dropdown-item:hover {
            background: rgba(44, 90, 160, 0.08);
            color: var(--primary);
        }

        .dropdown-item:hover i {
            color: var(--primary);
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 260px;
            padding: 30px;
            min-height: 100vh;
            transition: all 0.3s ease;
            background: var(--light-bg);
        }

        .content-header {
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid var(--border-color);
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            flex-wrap: wrap;
            gap: 20px;
        }

        .page-title {
            font-size: 28px;
            font-weight: 700;
            color: var(--text-dark);
            margin: 0 0 8px 0;
            letter-spacing: -0.3px;
        }

        .breadcrumb {
            background: transparent;
            padding: 0;
            margin: 0;
            font-size: 14px;
            color: var(--text-light);
        }

        .breadcrumb-item a {
            color: var(--primary);
            text-decoration: none;
            font-weight: 500;
        }

        .breadcrumb-item a:hover {
            color: var(--primary-dark);
            text-decoration: none;
        }

        .breadcrumb-item.active {
            color: var(--text-medium);
            font-weight: 500;
        }

        .breadcrumb-item+.breadcrumb-item::before {
            color: var(--text-light);
        }

        /* Alerts */
        .alert {
            border: 1px solid transparent;
            border-radius: 8px;
            padding: 16px 20px;
            margin-bottom: 24px;
            font-weight: 500;
            border-left-width: 4px;
        }

        .alert-danger {
            background: #fef2f2;
            color: var(--danger);
            border-color: #fed7d7;
            border-left-color: var(--danger);
        }

        .alert-success {
            background: #f0fdf4;
            color: var(--success);
            border-color: #d1fae5;
            border-left-color: var(--success);
        }

        /* Content Cards */
        .content-card {
            background: var(--card-bg);
            border-radius: 12px;
            padding: 28px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.04);
            margin-bottom: 30px;
            border: 1px solid var(--border-color);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        .content-card:hover {
            box-shadow: 0 6px 16px rgba(0, 0, 0, 0.06);
        }

        .card-header {
            padding: 0 0 22px 0;
            margin-bottom: 24px;
            border-bottom: 1px solid var(--border-color);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .card-title {
            font-size: 18px;
            font-weight: 600;
            color: var(--text-dark);
            margin: 0;
        }

        /* Buttons */
        .btn-primary {
            background: var(--primary);
            border: none;
            border-radius: 8px;
            padding: 10px 24px;
            font-weight: 600;
            color: white;
            transition: all 0.2s ease;
            font-size: 14px;
            letter-spacing: 0.2px;
        }

        .btn-primary:hover {
            background: var(--primary-dark);
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(44, 90, 160, 0.2);
            color: white;
        }

        .btn-outline-primary {
            border: 1px solid var(--primary);
            color: var(--primary);
            border-radius: 8px;
            padding: 9px 22px;
            font-weight: 600;
            transition: all 0.2s ease;
        }

        .btn-outline-primary:hover {
            background: var(--primary);
            color: white;
        }

        /* Mobile Menu Toggle */
        .mobile-menu-toggle {
            display: none;
            position: fixed;
            top: 20px;
            left: 20px;
            z-index: 1100;
            background: var(--primary);
            color: white;
            border: none;
            width: 48px;
            height: 48px;
            border-radius: 10px;
            font-size: 18px;
            font-weight: 600;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        /* Notification Styles */
        .notification-badge {
            position: absolute;
            top: 0;
            right: 0;
            transform: translate(50%, -50%);
            background: var(--danger);
            color: white;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            font-size: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
        }

        .notification-dropdown {
            min-width: 350px;
            max-height: 400px;
            overflow-y: auto;
        }

        .notification-item {
            border-left: 3px solid transparent;
            transition: all 0.2s ease;
        }

        .notification-item:hover {
            background: rgba(44, 90, 160, 0.05);
            border-left-color: var(--primary);
        }

        .notification-item.unread {
            background: rgba(44, 90, 160, 0.08);
            border-left-color: var(--primary);
            font-weight: 500;
        }

        .notification-item.unread:hover {
            background: rgba(44, 90, 160, 0.12);
        }

        .notification-icon {
            width: 36px;
            height: 36px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            flex-shrink: 0;
        }

        .notification-icon.info {
            background: var(--info);
        }

        .notification-icon.success {
            background: var(--success);
        }

        .notification-icon.warning {
            background: var(--warning);
        }

        .notification-icon.error {
            background: var(--danger);
        }

        .notification-icon.system {
            background: var(--primary);
        }

        .notification-time {
            font-size: 12px;
            color: var(--text-light);
        }

        .notification-empty {
            padding: 20px;
            text-align: center;
            color: var(--text-light);
        }

        /* Responsive Design */
        @media (max-width: 992px) {
            .sidebar {
                transform: translateX(-100%);
                width: 280px;
                box-shadow: 5px 0 20px rgba(0, 0, 0, 0.1);
            }
            
            .sidebar.active {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
                padding: 25px 20px;
            }
            
            .mobile-menu-toggle {
                display: flex;
                align-items: center;
                justify-content: center;
            }
            
            .page-title {
                font-size: 24px;
            }
            
            .content-card {
                padding: 22px;
            }

            .notification-dropdown {
                min-width: 300px;
                position: fixed !important;
                top: 60px !important;
                right: 10px !important;
                left: auto !important;
            }
        }

        @media (min-width: 993px) and (max-width: 1200px) {
            .sidebar {
                width: 240px;
            }
            
            .main-content {
                margin-left: 240px;
                padding: 28px;
            }
        }

        @media (min-width: 1201px) {
            .mobile-menu-toggle {
                display: none;
            }
        }

        /* Table Styling */
        .table {
            border-radius: 10px;
            overflow: hidden;
            border: 1px solid var(--border-color);
            font-size: 14px;
        }

        .table thead {
            background: rgba(44, 90, 160, 0.08);
        }

        .table th {
            font-weight: 600;
            color: var(--text-dark);
            border-bottom: 2px solid var(--border-color);
            padding: 16px;
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .table td {
            padding: 16px;
            color: var(--text-medium);
            border-top: 1px solid var(--border-color);
            font-weight: 500;
            vertical-align: middle;
        }

        .table tbody tr:hover {
            background-color: rgba(44, 90, 160, 0.03);
        }

        /* Badges */
        .badge {
            border-radius: 6px;
            padding: 5px 10px;
            font-weight: 600;
            font-size: 12px;
            letter-spacing: 0.3px;
        }

        .badge-admin {
            background: var(--primary);
            color: white;
        }

        .badge-user {
            background: rgba(0, 105, 92, 0.1);
            color: var(--secondary);
        }

        .badge-pensioner {
            background: rgba(59, 130, 246, 0.1);
            color: var(--info);
        }

        /* Form Controls */
        .form-control {
            border: 1px solid var(--border-color);
            border-radius: 8px;
            padding: 11px 16px;
            font-weight: 500;
            color: var(--text-dark);
            font-size: 14px;
            transition: all 0.2s ease;
        }

        .form-control:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(44, 90, 160, 0.1);
        }

        .form-label {
            font-weight: 600;
            color: var(--text-dark);
            margin-bottom: 8px;
            font-size: 14px;
        }

        /* Footer */
        .system-footer {
            text-align: center;
            margin-top: 50px;
            padding-top: 24px;
            border-top: 1px solid var(--border-color);
            color: var(--text-light);
            font-size: 14px;
            font-weight: 500;
        }

        /* Typography Improvements */
        h1, h2, h3, h4, h5, h6 {
            color: var(--text-dark);
            font-weight: 600;
            letter-spacing: -0.3px;
        }

        p {
            color: var(--text-medium);
            font-weight: 400;
            line-height: 1.7;
        }

        small {
            color: var(--text-light);
            font-weight: 500;
        }

        /* Statistics Cards */
        .stat-card {
            background: var(--card-bg);
            border-radius: 12px;
            padding: 24px;
            border: 1px solid var(--border-color);
            transition: all 0.3s ease;
            height: 100%;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.06);
            border-color: var(--primary-light);
        }

        .stat-icon {
            width: 56px;
            height: 56px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            margin-bottom: 20px;
            background: rgba(44, 90, 160, 0.1);
            color: var(--primary);
        }

        .stat-number {
            font-size: 32px;
            font-weight: 700;
            color: var(--text-dark);
            margin-bottom: 8px;
            line-height: 1;
        }

        .stat-label {
            font-size: 14px;
            font-weight: 600;
            color: var(--text-medium);
            text-transform: uppercase;
            letter-spacing: 0.8px;
        }

        .stat-trend {
            font-size: 13px;
            font-weight: 600;
            margin-top: 8px;
        }

        .trend-up {
            color: var(--success);
        }

        .trend-down {
            color: var(--danger);
        }

        /* Quick Actions Bar */
        .quick-actions {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
            margin-bottom: 30px;
        }

        .quick-action-btn {
            padding: 12px 20px;
            background: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 10px;
            display: flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
            color: var(--text-dark);
            font-weight: 500;
            transition: all 0.2s ease;
            flex: 1;
            min-width: 180px;
        }

        .quick-action-btn:hover {
            background: rgba(44, 90, 160, 0.05);
            border-color: var(--primary-light);
            transform: translateY(-2px);
            color: var(--primary);
        }

        .quick-action-btn i {
            font-size: 18px;
            color: var(--primary);
        }

        /* Page Header Actions */
        .header-actions {
            display: flex;
            gap: 12px;
            align-items: center;
        }

        .date-display {
            padding: 10px 16px;
            background: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 8px;
            font-weight: 600;
            color: var(--text-dark);
            font-size: 14px;
        }

        /* Search Box */
        .search-box {
            position: relative;
            max-width: 300px;
        }

        .search-box input {
            padding-left: 44px;
            border-radius: 8px;
        }

        .search-box i {
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-light);
        }

        /* Status Indicators */
        .status-indicator {
            display: inline-block;
            width: 10px;
            height: 10px;
            border-radius: 50%;
            margin-right: 8px;
        }

        .status-active {
            background: var(--success);
        }

        .status-inactive {
            background: var(--text-light);
        }

        .status-pending {
            background: var(--warning);
        }

        /* Data Filter Bar */
        .filter-bar {
            background: var(--card-bg);
            border-radius: 10px;
            padding: 16px 20px;
            margin-bottom: 24px;
            border: 1px solid var(--border-color);
            display: flex;
            gap: 16px;
            flex-wrap: wrap;
            align-items: center;
        }

        /* Modal Custom Styles */
        #registerPensionerModal .modal-content {
            border-radius: 15px;
            border: none;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.15);
        }

        #registerPensionerModal .modal-header {
            padding: 1.25rem 1.5rem;
            background: linear-gradient(135deg, #ff7eb9 0%, #d4a5ff 100%);
            border-radius: 12px 12px 0 0;
        }

        #registerPensionerModal .modal-body {
            padding: 1.5rem;
        }

        #registerPensionerModal .modal-footer {
            padding: 1rem 1.5rem;
            border-top: 1px solid #e9ecef;
        }

        #registerPensionerModal .form-label {
            font-size: 14px;
            margin-bottom: 8px;
        }

        #registerPensionerModal .input-group-text {
            background-color: #f8f9fa;
            border: 1px solid #dee2e6;
            min-width: 45px;
            justify-content: center;
        }

        #registerPensionerModal .form-control {
            border: 1px solid #dee2e6;
            padding: 10px 12px;
            font-size: 14px;
        }

        #registerPensionerModal .form-control:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(44, 90, 160, 0.15);
        }

        /* Select with icon styling */
        .select-with-icon {
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='%232c5aa0' viewBox='0 0 16 16'%3E%3Cpath d='M7.247 11.14 2.451 5.658C1.885 5.013 2.345 4 3.204 4h9.592a1 1 0 0 1 .753 1.659l-4.796 5.48a1 1 0 0 1-1.506 0z'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 12px center;
            background-size: 14px;
            padding-right: 36px;
            cursor: pointer;
            appearance: none;
            -webkit-appearance: none;
            -moz-appearance: none;
        }

        .select-with-icon:focus {
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='%231e3a6f' viewBox='0 0 16 16'%3E%3Cpath d='M7.247 11.14 2.451 5.658C1.885 5.013 2.345 4 3.204 4h9.592a1 1 0 0 1 .753 1.659l-4.796 5.48a1 1 0 0 1-1.506 0z'/%3E%3C/svg%3E");
        }

        /* Toast animations */
        .toast {
            border: none;
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
        }

        .toast-header {
            border-radius: 10px 10px 0 0;
        }

        /* Mobile optimizations for modal */
        @media (max-width: 768px) {
            #registerPensionerModal .modal-dialog {
                margin: 10px;
            }
            
            #registerPensionerModal .modal-content {
                border-radius: 12px;
            }
            
            #registerPensionerModal .modal-body {
                padding: 1.25rem;
            }
            
            #registerPensionerModal .col-md-6 {
                margin-bottom: 15px;
            }
        }

        /* Modal backdrop */
        .modal-backdrop {
            background-color: rgba(0, 0, 0, 0.5);
        }

        .modal-backdrop.show {
            opacity: 0.5;
        }
    </style>
</head>
<body>

    <!-- Mobile Menu Toggle -->
    <button class="mobile-menu-toggle" id="mobileMenuToggle" aria-label="Toggle menu">
        <i class="fas fa-bars"></i>
    </button>

    <!-- Sidebar Navigation -->
    <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <a class="system-logo" href="<?= site_url() ?>">
                <i class="fas fa-hands-helping"></i>
                <div>
                    <div class="logo-text">PensionerMS</div>
                </div>
            </a>
        </div>

        <div class="sidebar-nav">
            <!-- Navigation Links -->
            <div class="nav-item">
                <a class="nav-link <?= isset($page_title) && $page_title == 'Home' ? 'active' : '' ?>" href="<?= site_url('/Main') ?>">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </div>

            <!-- Admin Only Links -->
            <?php if (session()->login_type == 1): ?>
            <div class="nav-item">
                <a class="nav-link <?= isset($page_title) && $page_title == 'Users' ? 'active' : '' ?>" href="<?= site_url('Main/users') ?>">
                    <i class="fas fa-user-shield"></i>
                    <span>User Management</span>
                </a>
            </div>

                       <!-- IP Block -->
                       <div class="nav-item">
    <a class="nav-link <?= isset($page_title) && $page_title == 'Block IP Address' ? 'active' : '' ?>" href="<?= site_url('Auth/blockIP') ?>">
        <i class="fas fa-ban"></i>
        <span>Block IP Address</span>
    </a>
</div>

            <?php endif; ?>

            <!-- Pensioner Management - Modal Trigger -->
            <div class="nav-item">
                <a class="nav-link" href="#" data-bs-toggle="modal" data-bs-target="#registerPensionerModal">
                    <i class="fas fa-user-plus"></i>
                    <span>Register Pensioner</span>
                </a>
            </div>

            <?php if(session()->login_type == 2): ?>
            <div class="nav-item">
                <a class="nav-link <?= isset($page_title) && $page_title == 'List Updated of Pensioners' ? 'active' : '' ?>" href="<?= site_url('user/pensioners/view') ?>">
                    <i class="fas fa-clipboard-list"></i>
                    <span>Updated Records</span>
                </a>
            </div>
            
            <?php endif; ?>

            <?php if (session()->login_type == 1): ?>
            <div class="nav-item">
                <a class="nav-link <?= isset($page_title) && $page_title == 'List Pensioners' ? 'active' : '' ?>" href="<?= site_url('admin/pensioners') ?>">
                    <i class="fas fa-address-book"></i>
                    <span>All Pensioners</span>
                </a>
            </div>
            
            <div class="nav-item">
                <a class="nav-link <?= isset($page_title) && $page_title == 'Reports' ? 'active' : '' ?>" 
                   href="<?= site_url('admin/pensioners/report') ?>">
                    <i class="fas fa-chart-bar"></i>
                    <span>Reports & Analytics</span>
                </a>
            </div>
            
            <?php endif; ?>
            
            <!-- Support Link -->
            <div class="nav-item">
                <a class="nav-link" href="help/index">
                    <i class="fas fa-question-circle"></i>
                    <span>Help & Support</span>
                </a>
            </div>

        </div>

        <!-- User Profile Section -->
        <div class="sidebar-footer">
            <div class="user-profile dropdown" data-bs-toggle="dropdown" aria-expanded="false">
                <div class="user-avatar">
                    <?= strtoupper(substr(session()->get('login_name'), 0, 1)) ?>
                </div>
                <div class="user-info">
                    <div class="user-name"><?= session()->get('login_name') ?></div>
                    <div class="user-role">
                        <span class="badge <?= session()->login_type == 1 ? 'badge-admin' : 'badge-user' ?>">
                            <?= session()->login_type == 1 ? 'Administrator' : 'Association Member' ?>
                        </span>
                    </div>
                </div>
                <i class="fas fa-chevron-down"></i>
            </div>
            <ul class="dropdown-menu">
                <li>
                    <a class="dropdown-item" href="<?= base_url('update_user') ?>">
                        <i class="fas fa-user-edit me-2"></i>My Profile
                    </a>
                </li>
                <li>
                    <!-- Updated Notification Dropdown -->
                    <div class="dropdown-item notification-dropdown-item p-0">
                        <a href="#" class="dropdown-item d-flex align-items-center" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-bell me-2"></i>Notifications
                            <?php if(isset($unreadCount) && $unreadCount > 0): ?>
                                <span class="badge bg-danger rounded-pill ms-auto">
                                    <?= $unreadCount > 9 ? '9+' : $unreadCount ?>
                                </span>
                            <?php endif; ?>
                        </a>
                        
                        <!-- Notification Dropdown -->
                        <div class="dropdown-menu notification-dropdown p-0" style="width: 350px;">
                            <div class="p-3 border-bottom">
                                <div class="d-flex justify-content-between align-items-center">
                                    <h6 class="mb-0 fw-semibold">Notifications</h6>
                                    <?php if(isset($unreadCount) && $unreadCount > 0): ?>
                                        <button type="button" class="btn btn-sm btn-outline-primary py-0" onclick="markAllAsRead()">
                                            <small>Mark all read</small>
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div id="notificationList" style="max-height: 300px; overflow-y: auto;">
                                <!-- Notifications will be loaded via AJAX -->
                                <div class="notification-empty p-4 text-center">
                                    <div class="spinner-border spinner-border-sm text-primary" role="status">
                                        <span class="visually-hidden">Loading...</span>
                                    </div>
                                    <p class="mt-2 mb-0 text-muted">Loading notifications...</p>
                                </div>
                            </div>
                            <div class="border-top p-2">
                                <a class="dropdown-item text-center" href="<?= base_url('notifications') ?>">
                                    <i class="fas fa-list me-1"></i> View all notifications
                                </a>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <a class="dropdown-item" href="#">
                        <i class="fas fa-cog me-2"></i>Account Settings
                    </a>
                </li>
                <li><hr class="dropdown-divider"></li>
                <li>
                    <a class="dropdown-item text-danger" href="<?= base_url('logout') ?>">
                        <i class="fas fa-sign-out-alt me-2"></i>Logout
                    </a>
                </li>
            </ul>
        </div>
    </div>

    <!-- Main Content Area -->
    <div class="main-content" id="mainContent">
        <!-- Page Header -->
        <div class="content-header">
            <div>
                <h1 class="page-title"><?= isset($page_title) ? $page_title : 'Dashboard' ?></h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?= site_url() ?>">Home</a></li>
                        <?php if(isset($page_title) && $page_title != 'Home'): ?>
                        <li class="breadcrumb-item active"><?= $page_title ?></li>
                        <?php endif; ?>
                    </ol>
                </nav>
            </div>
            
            <!-- Quick Actions -->
            <div class="header-actions">
                <!-- Date Display -->
                <div class="date-display">
                    <i class="fas fa-calendar-alt me-2"></i>
                    <?= date('l, F j, Y') ?>
                </div>
                
                <!-- Notification Bell in Header (Alternative) -->
                <div class="dropdown">
                    <button class="btn btn-outline-primary position-relative" type="button" 
                            id="headerNotificationDropdown" data-bs-toggle="dropdown" 
                            aria-expanded="false">
                        <i class="fas fa-bell"></i>
                        <?php if(isset($unreadCount) && $unreadCount > 0): ?>
                            <span class="notification-badge">
                                <?= $unreadCount > 9 ? '9+' : $unreadCount ?>
                            </span>
                        <?php endif; ?>
                    </button>
                    <div class="dropdown-menu notification-dropdown dropdown-menu-end p-0" 
                         aria-labelledby="headerNotificationDropdown" style="width: 350px;">
                        <div class="p-3 border-bottom">
                            <div class="d-flex justify-content-between align-items-center">
                                <h6 class="mb-0 fw-semibold">Notifications</h6>
                                <?php if(isset($unreadCount) && $unreadCount > 0): ?>
                                    <button type="button" class="btn btn-sm btn-outline-primary py-0" onclick="markAllAsRead()">
                                        <small>Mark all read</small>
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div id="headerNotificationList" style="max-height: 300px; overflow-y: auto;">
                            <!-- Notifications will be loaded via AJAX -->
                            <div class="notification-empty p-4 text-center">
                                <div class="spinner-border spinner-border-sm text-primary" role="status">
                                    <span class="visually-hidden">Loading...</span>
                                </div>
                                <p class="mt-2 mb-0 text-muted">Loading notifications...</p>
                            </div>
                        </div>
                        <div class="border-top p-2">
                            <a class="dropdown-item text-center" href="<?= base_url('notifications') ?>">
                                <i class="fas fa-list me-1"></i> View all notifications
                            </a>
                        </div>
                    </div>
                </div>
                
                <!-- Search Box (Optional) -->
                <?php if(isset($page_title) && ($page_title == 'All Pensioners' || $page_title == 'Users')): ?>
                <div class="search-box">
                    <i class="fas fa-search"></i>
                    <input type="text" class="form-control" placeholder="Search...">
                </div>
                <?php endif; ?>
                
                <!-- Add New Button -->
                <?php if(isset($page_title) && $page_title == 'All Pensioners' && session()->login_type == 1): ?>
                <a href="<?= site_url('admin/pensioners/create') ?>" class="btn btn-primary">
                    <i class="fas fa-plus me-2"></i>Add New
                </a>
                <?php endif; ?>
            </div>
        </div>

        <!-- Alert Messages -->
        <?php if(session()->getFlashdata('main_error')): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle me-2"></i>
                <?= session()->getFlashdata('main_error') ?>
            </div>
        <?php endif; ?>
        
        <?php if(session()->getFlashdata('main_success')): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle me-2"></i>
                <?= session()->getFlashdata('main_success') ?>
            </div>
        <?php endif; ?>

        <!-- Main Content -->
        <?= $this->renderSection('content') ?>

        <!-- Footer -->
        <div class="system-footer">
            <p style="font-weight: 500; color: var(--text-medium); margin-bottom: 5px;">
                Pensioner Association Management System v2.1
            </p>
            <p style="font-size: 13px; color: var(--text-light);">
                &copy; <?= date('Y') ?> Pensioner Association. All rights reserved. | 
                <span style="color: var(--primary);">Secure • Reliable • Efficient</span>
            </p>
        </div>
    </div>

  <!-- Register Pensioner Modal -->
<div class="modal fade" id="registerPensionerModal" tabindex="-1" aria-labelledby="registerPensionerModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-white" id="registerPensionerModalLabel">
                    <i class="fas fa-user-plus me-2"></i>Register New Pensioner
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-4">
                <form id="pensionerForm" method="POST">
                    <?= csrf_field() ?>
                    
                    <!-- Personal Information Section -->
                    <div class="row mb-4">
                        <div class="col-12">
                            <h6 class="border-bottom pb-2 mb-3">
                                <i class="fas fa-id-card me-2"></i>Personal Information
                            </h6>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Full Name <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-user text-primary"></i>
                                </span>
                                <input type="text" name="full_name" class="form-control" placeholder="Enter full name" required>
                            </div>
                            <div class="invalid-feedback">Please enter full name</div>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">ID Number</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-id-card text-primary"></i>
                                </span>
                                <input type="text" name="id_number" class="form-control" placeholder="Enter ID number">
                            </div>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-semibold">Date of Birth</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-calendar-alt text-primary"></i>
                                </span>
                                <input type="date" name="date_of_birth" class="form-control">
                            </div>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-semibold">Gender <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-venus-mars text-primary"></i>
                                </span>
                                <select name="gender" class="form-control select-with-icon" required>
                                    <option value="">Select gender</option>
                                    <option value="male">Male</option>
                                    <option value="female">Female</option>
                                    <option value="other">Other</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-semibold">Marital Status</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-heart text-primary"></i>
                                </span>
                                <select name="marital_status" class="form-control select-with-icon">
                                    <option value="">Select status</option>
                                    <option value="single">Single</option>
                                    <option value="married">Married</option>
                                    <option value="divorced">Divorced</option>
                                    <option value="widowed">Widowed</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Contact Information Section -->
                    <div class="row mb-4">
                        <div class="col-12">
                            <h6 class="border-bottom pb-2 mb-3">
                                <i class="fas fa-address-book me-2"></i>Contact Information
                            </h6>
                        </div>
                        
                        <div class="col-12 mb-3">
                            <label class="form-label fw-semibold">Address</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-home text-primary"></i>
                                </span>
                                <textarea name="address" class="form-control" placeholder="Enter complete address" rows="2"></textarea>
                            </div>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Contact Number</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-phone text-primary"></i>
                                </span>
                                <input type="tel" name="contact_number" class="form-control" placeholder="Enter contact number">
                            </div>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Email Address</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-envelope text-primary"></i>
                                </span>
                                <input type="email" name="email" class="form-control" placeholder="Enter email address">
                            </div>
                        </div>
                    </div>
                    
                    <!-- Bank Information Section -->
                    <div class="row mb-4">
                        <div class="col-12">
                            <h6 class="border-bottom pb-2 mb-3">
                                <i class="fas fa-university me-2"></i>Bank Information
                            </h6>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Bank Account Number</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-credit-card text-primary"></i>
                                </span>
                                <input type="text" name="bank_account" class="form-control" placeholder="Enter bank account number">
                            </div>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Bank Name</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-landmark text-primary"></i>
                                </span>
                                <input type="text" name="bank_name" class="form-control" placeholder="Enter bank name">
                            </div>
                        </div>
                    </div>
                    
                    <!-- Next of Kin Section -->
                    <div class="row mb-4">
                        <div class="col-12">
                            <h6 class="border-bottom pb-2 mb-3">
                                <i class="fas fa-user-friends me-2"></i>Next of Kin Information
                            </h6>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Next of Kin Name</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-user-friends text-primary"></i>
                                </span>
                                <input type="text" name="next_of_kin" class="form-control" placeholder="Enter next of kin name">
                            </div>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Next of Kin Contact</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-phone text-primary"></i>
                                </span>
                                <input type="tel" name="next_of_kin_contact" class="form-control" placeholder="Enter contact number">
                            </div>
                        </div>
                    </div>
                    
                    <!-- Pension Information Section -->
                    <div class="row mb-4">
                        <div class="col-12">
                            <h6 class="border-bottom pb-2 mb-3">
                                <i class="fas fa-piggy-bank me-2"></i>Pension Information
                            </h6>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Pension Type <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-heartbeat text-primary"></i>
                                </span>
                                <select name="pension_type" class="form-control select-with-icon" required>
                                    <option value="">Select pension type</option>
                                    <option value="retirement">Retirement Pension</option>
                                    <option value="disability">Disability Pension</option>
                                    <option value="survivor">Survivor Pension</option>
                                    <option value="other">Other Pension</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Pension Amount <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-money-bill-wave text-primary"></i>
                                </span>
                                <input type="number" name="pension_amount" class="form-control" placeholder="0.00" step="0.01" min="0" required>
                            </div>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Pension Start Date</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-calendar-check text-primary"></i>
                                </span>
                                <input type="date" name="pension_start_date" class="form-control">
                            </div>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Status <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-chart-line text-primary"></i>
                                </span>
                                <select name="status" class="form-control select-with-icon" required>
                                    <option value="">Select status</option>
                                    <option value="active">Active</option>
                                    <option value="suspended">Suspended</option>
                                    <option value="deceased">Deceased</option>
                                    <option value="inactive">Inactive</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Additional Information Section -->
                    <div class="row mb-4">
                        <div class="col-12">
                            <h6 class="border-bottom pb-2 mb-3">
                                <i class="fas fa-clipboard-list me-2"></i>Additional Information
                            </h6>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Medical Conditions</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-medkit text-primary"></i>
                                </span>
                                <textarea name="medical_conditions" class="form-control" placeholder="Enter medical conditions" rows="2"></textarea>
                            </div>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Notes</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-sticky-note text-primary"></i>
                                </span>
                                <textarea name="notes" class="form-control" placeholder="Enter additional notes" rows="2"></textarea>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Information Alert -->
                    <div class="alert alert-info mt-4 mb-0">
                        <div class="d-flex align-items-center">
                            <i class="fas fa-info-circle me-3 fa-lg"></i>
                            <div>
                                <h6 class="alert-heading mb-2">Important Information</h6>
                                <ul class="mb-0 ps-3">
                                    <li>Fields marked with <span class="text-danger">*</span> are required.</li>
                                    <li>Ensure all information is accurate before submission.</li>
                                    <li>Pensioner will be added immediately upon successful submission.</li>
                                    <li>You can edit the pensioner details later if needed.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer border-top-0 pt-0">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    <i class="fas fa-times me-2"></i>Cancel
                </button>
                <button type="button" class="btn btn-primary" id="savePensionerBtn">
                    <i class="fas fa-save me-2"></i>Save Pensioner
                </button>
            </div>
        </div>
    </div>
</div>

    <!-- Success Toast -->
    <div class="toast-container position-fixed bottom-0 end-0 p-3" style="z-index: 1060">
        <div id="successToast" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="toast-header bg-success text-white">
                <i class="fas fa-check-circle me-2"></i>
                <strong class="me-auto">Success</strong>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            <div class="toast-body">
                <div class="d-flex align-items-center">
                    <i class="fas fa-check-circle text-success me-3 fa-lg"></i>
                    <div>
                        <h6 class="mb-1">Pensioner Registered Successfully!</h6>
                        <p class="mb-0 small">The new pensioner has been added to the system.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Error Toast -->
    <div class="toast-container position-fixed bottom-0 end-0 p-3" style="z-index: 1060">
        <div id="errorToast" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="toast-header bg-danger text-white">
                <i class="fas fa-exclamation-circle me-2"></i>
                <strong class="me-auto">Error</strong>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            <div class="toast-body">
                <div class="d-flex align-items-center">
                    <i class="fas fa-exclamation-circle text-danger me-3 fa-lg"></i>
                    <div>
                        <h6 class="mb-1">Registration Failed</h6>
                        <p class="mb-0 small" id="errorMessage">Please try again later.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Notification Toast -->
    <div class="toast-container position-fixed top-0 end-0 p-3" style="z-index: 1060">
        <div id="notificationToast" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="toast-header bg-primary text-white">
                <i class="fas fa-bell me-2"></i>
                <strong class="me-auto">New Notification</strong>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            <div class="toast-body">
                <div class="d-flex align-items-center">
                    <i class="fas fa-bell text-primary me-3 fa-lg"></i>
                    <div>
                        <h6 class="mb-1" id="notificationToastTitle">New Notification</h6>
                        <p class="mb-0 small" id="notificationToastMessage">You have a new notification</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Mobile menu functionality
        const mobileMenuToggle = document.getElementById('mobileMenuToggle');
        const sidebar = document.getElementById('sidebar');
        
        mobileMenuToggle.addEventListener('click', function() {
            sidebar.classList.toggle('active');
        });

        // Close sidebar when clicking outside on mobile
        document.addEventListener('click', function(event) {
            if (window.innerWidth <= 992) {
                if (!sidebar.contains(event.target) && 
                    !mobileMenuToggle.contains(event.target) && 
                    sidebar.classList.contains('active')) {
                    sidebar.classList.remove('active');
                }
            }
        });

        // Auto-hide alerts after 5 seconds
        document.addEventListener('DOMContentLoaded', function() {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                setTimeout(() => {
                    alert.style.transition = 'opacity 0.3s ease';
                    alert.style.opacity = '0';
                    setTimeout(() => {
                        if (alert.parentNode) {
                            alert.parentNode.removeChild(alert);
                        }
                    }, 300);
                }, 5000);
            });
        });

        // Add active class to current page
        document.addEventListener('DOMContentLoaded', function() {
            const currentPath = window.location.pathname;
            const navLinks = document.querySelectorAll('.nav-link');
            
            navLinks.forEach(link => {
                if (link.getAttribute('href') === currentPath) {
                    link.classList.add('active');
                }
            });
        });

        // Handle window resize
        window.addEventListener('resize', function() {
            if (window.innerWidth > 992 && sidebar.classList.contains('active')) {
                sidebar.classList.remove('active');
            }
        });

        // Form validation enhancements
        document.addEventListener('DOMContentLoaded', function() {
            // Add focus effects to form controls
            const formControls = document.querySelectorAll('.form-control');
            formControls.forEach(control => {
                control.addEventListener('focus', function() {
                    this.parentElement.classList.add('focused');
                });
                
                control.addEventListener('blur', function() {
                    this.parentElement.classList.remove('focused');
                });
            });
        });
    </script>

    <script>
    $(document).ready(function() {
        // Form validation
        function validateForm() {
            var isValid = true;
            var form = $('#pensionerForm')[0];
            
            // Reset validation styles
            $('.form-control').removeClass('is-invalid');
            $('.invalid-feedback').hide();
            
            // Check required fields
            $('[required]').each(function() {
                if (!$(this).val().trim()) {
                    $(this).addClass('is-invalid');
                    $(this).next('.invalid-feedback').show();
                    isValid = false;
                }
            });
            
            // Email validation
            var email = $('input[name="email"]').val();
            if (email && !isValidEmail(email)) {
                $('input[name="email"]').addClass('is-invalid');
                isValid = false;
            }
            
            return isValid;
        }
        
        function isValidEmail(email) {
            var re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return re.test(email);
        }
        
        // Save pensioner button click handler
        $('#savePensionerBtn').click(function(e) {
            e.preventDefault();
            
            if (!validateForm()) {
                showError('Please fill in all required fields correctly.');
                return;
            }
            
            // Show loading state
            var $btn = $(this);
            var originalText = $btn.html();
            $btn.html('<i class="fas fa-spinner fa-spin me-2"></i>Saving...');
            $btn.prop('disabled', true);
            
            // Get form data
            var formData = new FormData($('#pensionerForm')[0]);
            
            // Submit via AJAX
            $.ajax({
                url: '<?= site_url("/admin/pensioners/store") ?>',
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                },
                success: function(response) {
                    // Reset button
                    $btn.html(originalText);
                    $btn.prop('disabled', false);
                    
                    if (response.success) {
                        // Show success toast
                        var successToast = new bootstrap.Toast(document.getElementById('successToast'));
                        successToast.show();
                        
                        // Reset form
                        $('#pensionerForm')[0].reset();
                        
                        // Close modal after delay
                        setTimeout(function() {
                            $('#registerPensionerModal').modal('hide');
                            
                            // Refresh page to show updated data (optional)
                            setTimeout(function() {
                                window.location.reload();
                            }, 500);
                        }, 2000);
                    } else {
                        showError(response.message || 'An error occurred. Please try again.');
                    }
                },
                error: function(xhr, status, error) {
                    // Reset button
                    $btn.html(originalText);
                    $btn.prop('disabled', false);
                    
                    var errorMsg = 'An error occurred while saving. Please try again.';
                    if (xhr.responseJSON && xhr.responseJSON.message) {
                        errorMsg = xhr.responseJSON.message;
                    } else if (xhr.status === 403) {
                        errorMsg = 'Access denied. You do not have permission to perform this action.';
                    } else if (xhr.status === 500) {
                        errorMsg = 'Server error. Please contact administrator.';
                    }
                    
                    showError(errorMsg);
                }
            });
        });
        
        // Show error toast
        function showError(message) {
            $('#errorMessage').text(message);
            var errorToast = new bootstrap.Toast(document.getElementById('errorToast'));
            errorToast.show();
        }
        
        // Clear form when modal closes
        $('#registerPensionerModal').on('hidden.bs.modal', function () {
            $('#pensionerForm')[0].reset();
            $('.form-control').removeClass('is-invalid');
            $('.invalid-feedback').hide();
            $('#savePensionerBtn').prop('disabled', false).html('<i class="fas fa-save me-2"></i>Save Pensioner');
        });
        
        // Auto-focus first input when modal opens
        $('#registerPensionerModal').on('shown.bs.modal', function () {
            $('#pensionerForm input[name="full_name"]').focus();
        });
        
        // Real-time validation
        $('#pensionerForm input, #pensionerForm select').on('blur', function() {
            validateForm();
        });
    });
    </script>

    <!-- Notification System JavaScript -->
    <script>
    // Initialize notification system
    $(document).ready(function() {
        // Load notifications on page load
        loadNotifications();
        
        // Set up periodic refresh (every 30 seconds)
        setInterval(loadNotifications, 30000);
        
        // Load notifications when dropdown is shown
        $('#headerNotificationDropdown').on('shown.bs.dropdown', function () {
            loadNotifications();
        });
        
        // Also for sidebar notifications
        $('.notification-dropdown-item .dropdown-item').on('click', function(e) {
            e.preventDefault();
            loadNotifications();
        });
    });
    
    function loadNotifications() {
        $.ajax({
            url: '<?= base_url("notifications/getNotifications") ?>',
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    updateNotificationLists(response.notifications);
                    updateNotificationBadge(response.unreadCount);
                } else {
                    showNotificationError('Failed to load notifications.');
                }
            },
            error: function(xhr, status, error) {
                showNotificationError('Error loading notifications.');
            }
        });
    }
    
    function updateNotificationLists(notifications) {
        updateNotificationList('notificationList', notifications);
        updateNotificationList('headerNotificationList', notifications);
    }
    
    function updateNotificationList(listId, notifications) {
        var $list = $('#' + listId);
        
        if (notifications.length === 0) {
            $list.html(`
                <div class="notification-empty p-4">
                    <i class="fas fa-bell-slash fa-2x text-muted mb-3"></i>
                    <p class="text-muted mb-0">No notifications yet</p>
                </div>
            `);
            return;
        }
        
        var html = '';
        notifications.forEach(function(notification) {
            var iconClass = getNotificationIconClass(notification.type);
            var icon = getNotificationIcon(notification.type);
            var isUnread = notification.is_read == 0;
            var timeAgoText = timeAgo(notification.created_at);
            
            html += `
                <a href="${notification.action_url ? notification.action_url : 'javascript:void(0)'}" 
                   class="dropdown-item notification-item ${isUnread ? 'unread' : ''}" 
                   onclick="markNotificationAsRead(${notification.notification_id}, this)">
                    <div class="d-flex align-items-start">
                        <div class="notification-icon ${iconClass} me-3">
                            <i class="fas fa-${icon}"></i>
                        </div>
                        <div class="flex-grow-1">
                            <div class="d-flex justify-content-between align-items-start mb-1">
                                <h6 class="mb-0" style="font-size: 14px;">${notification.title}</h6>
                                <small class="notification-time text-muted">${timeAgoText}</small>
                            </div>
                            <p class="mb-0 text-muted" style="font-size: 13px; line-height: 1.4;">
                                ${notification.message}
                            </p>
                        </div>
                    </div>
                </a>
            `;
        });
        
        $list.html(html);
    }
    
    function updateNotificationBadge(count) {
        // Update badge in header
        var $headerBadge = $('.notification-badge');
        if (count > 0) {
            if ($headerBadge.length === 0) {
                $('#headerNotificationDropdown').append(`
                    <span class="notification-badge">
                        ${count > 9 ? '9+' : count}
                    </span>
                `);
            } else {
                $headerBadge.text(count > 9 ? '9+' : count);
            }
        } else {
            $headerBadge.remove();
        }
        
        // Update badge in sidebar
        var $sidebarBadge = $('.notification-dropdown-item .badge');
        if (count > 0) {
            if ($sidebarBadge.length === 0) {
                $('.notification-dropdown-item .dropdown-item').append(`
                    <span class="badge bg-danger rounded-pill ms-auto">
                        ${count > 9 ? '9+' : count}
                    </span>
                `);
            } else {
                $sidebarBadge.text(count > 9 ? '9+' : count);
            }
        } else {
            $sidebarBadge.remove();
        }
    }
    
    function markNotificationAsRead(notificationId, element) {
        $.ajax({
            url: '<?= base_url("notifications/markAsRead") ?>/' + notificationId,
            method: 'POST',
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    // Remove unread styling
                    $(element).removeClass('unread');
                    
                    // Update badge count
                    var currentCount = parseInt($('.notification-badge').text()) || 0;
                    if (currentCount > 1) {
                        $('.notification-badge').text(currentCount > 10 ? '9+' : currentCount - 1);
                    } else {
                        $('.notification-badge').remove();
                    }
                    
                    // Also update sidebar badge
                    var sidebarBadge = $('.notification-dropdown-item .badge');
                    if (sidebarBadge.length > 0) {
                        var sidebarCount = parseInt(sidebarBadge.text()) || 0;
                        if (sidebarCount > 1) {
                            sidebarBadge.text(sidebarCount > 10 ? '9+' : sidebarCount - 1);
                        } else {
                            sidebarBadge.remove();
                        }
                    }
                    
                    // If there's an action URL, follow it after marking as read
                    var href = $(element).attr('href');
                    if (href && href !== 'javascript:void(0)') {
                        window.location.href = href;
                    }
                }
            }
        });
    }
    
    function markAllAsRead() {
        if (confirm('Mark all notifications as read?')) {
            $.ajax({
                url: '<?= base_url("notifications/markAllAsRead") ?>',
                method: 'POST',
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        // Reload notifications
                        loadNotifications();
                        
                        // Show success message
                        showNotificationToast('Success', 'All notifications marked as read');
                    }
                }
            });
        }
    }
    
    function getNotificationIcon(type) {
        const icons = {
            'info': 'info-circle',
            'success': 'check-circle',
            'warning': 'exclamation-triangle',
            'error': 'times-circle',
            'system': 'cog'
        };
        return icons[type] || 'bell';
    }
    
    function getNotificationIconClass(type) {
        const classes = {
            'info': 'info',
            'success': 'success',
            'warning': 'warning',
            'error': 'error',
            'system': 'system'
        };
        return classes[type] || 'info';
    }
    
    function timeAgo(datetime) {
        const date = new Date(datetime);
        const now = new Date();
        const diffMs = now - date;
        const diffSec = Math.floor(diffMs / 1000);
        const diffMin = Math.floor(diffSec / 60);
        const diffHour = Math.floor(diffMin / 60);
        const diffDay = Math.floor(diffHour / 24);
        
        if (diffSec < 60) return 'Just now';
        if (diffMin < 60) return diffMin + ' min ago';
        if (diffHour < 24) return diffHour + ' hour' + (diffHour > 1 ? 's' : '') + ' ago';
        if (diffDay < 7) return diffDay + ' day' + (diffDay > 1 ? 's' : '') + ' ago';
        if (diffDay < 30) return Math.floor(diffDay / 7) + ' week' + (Math.floor(diffDay / 7) > 1 ? 's' : '') + ' ago';
        return date.toLocaleDateString();
    }
    
    function showNotificationError(message) {
        console.error('Notification error:', message);
        // You could show a small toast or update UI to indicate error
    }
    
    function showNotificationToast(title, message) {
        $('#notificationToastTitle').text(title);
        $('#notificationToastMessage').text(message);
        var toast = new bootstrap.Toast(document.getElementById('notificationToast'));
        toast.show();
    }
    
    // WebSocket/SSE for real-time notifications (optional)
    // Uncomment if you want real-time push notifications
    /*
    function setupRealTimeNotifications() {
        // Use WebSocket or Server-Sent Events for real-time updates
        if (typeof(EventSource) !== "undefined") {
            var source = new EventSource("<?= base_url('notifications/stream') ?>");
            source.onmessage = function(event) {
                var notification = JSON.parse(event.data);
                if (notification) {
                    // Show notification toast
                    showNotificationToast(notification.title, notification.message);
                    
                    // Reload notifications
                    loadNotifications();
                }
            };
        }
    }
    
    // Call this function if you implement real-time notifications
    // setupRealTimeNotifications();
    */
    </script>

    <?= $this->renderSection('custom_js') ?>
</body>
</html>