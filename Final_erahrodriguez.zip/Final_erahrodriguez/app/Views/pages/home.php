<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>

<?php
$settingModel = new \App\Models\SettingModel();
$currentMode = $settingModel->getMode();
$isMaintenance = $currentMode === 'maintenance';
?>

<style>
    .dashboard-container {
        padding: 2rem 0;
        background: #f8fafc;
        min-height: calc(100vh - 160px);
    }
    
    .welcome-card {
        background: white;
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.04);
        border: 1px solid #e2e8f0;
        overflow: hidden;
        margin-bottom: 2rem;
    }
    
    .welcome-header {
        background: linear-gradient(135deg, #2c5aa0 0%, #1e3a6f 100%);
        padding: 2rem;
        color: white;
    }
    
    .welcome-body {
        padding: 2rem;
    }
    
    .system-name {
        font-weight: 700;
        color: #2c5aa0;
    }
    
    .feature-list {
        list-style: none;
        padding-left: 0;
    }
    
    .feature-list li {
        padding: 0.5rem 0;
        color: #475569;
        display: flex;
        align-items: center;
    }
    
    .feature-list i {
        color: #2c5aa0;
        margin-right: 0.75rem;
        width: 20px;
        text-align: center;
    }
    
    .mode-toggle-btn {
        border-radius: 8px;
        padding: 0.875rem 2rem;
        font-weight: 600;
        transition: all 0.2s ease;
        border: none;
        width: 100%;
    }
    
    .mode-toggle-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }
    
    .btn-maintenance {
        background: #dc2626;
        color: white;
    }
    
    .btn-maintenance:hover {
        background: #b91c1c;
        color: white;
    }
    
    .btn-operational {
        background: #10b981;
        color: white;
    }
    
    .btn-operational:hover {
        background: #059669;
        color: white;
    }
    
    .mode-indicator {
        display: inline-flex;
        align-items: center;
        padding: 0.5rem 1rem;
        border-radius: 20px;
        font-size: 0.875rem;
        font-weight: 600;
        margin-bottom: 1rem;
        background: rgba(255, 255, 255, 0.15);
        color: white;
    }
    
    .stats-card {
        background: white;
        border-radius: 12px;
        padding: 1.5rem;
        border: 1px solid #e2e8f0;
        transition: all 0.3s ease;
        height: 100%;
    }
    
    .stats-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.06);
        border-color: #4a7fd4;
    }
    
    .stats-icon {
        width: 56px;
        height: 56px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 24px;
        margin-bottom: 1rem;
        background: rgba(44, 90, 160, 0.1);
        color: #2c5aa0;
    }
    
    .stats-number {
        font-size: 32px;
        font-weight: 700;
        color: #1e293b;
        margin-bottom: 0.25rem;
        line-height: 1;
    }
    
    .stats-label {
        font-size: 14px;
        font-weight: 600;
        color: #475569;
        text-transform: uppercase;
        letter-spacing: 0.8px;
    }
    
    .quick-actions {
        display: flex;
        gap: 12px;
        flex-wrap: wrap;
        margin: 1.5rem 0;
    }
    
    .quick-action-btn {
        padding: 12px 20px;
        background: white;
        border: 1px solid #e2e8f0;
        border-radius: 8px;
        display: flex;
        align-items: center;
        gap: 10px;
        text-decoration: none;
        color: #1e293b;
        font-weight: 500;
        transition: all 0.2s ease;
        flex: 1;
        min-width: 180px;
        cursor: pointer;
    }
    
    .quick-action-btn:hover {
        background: rgba(44, 90, 160, 0.05);
        border-color: #4a7fd4;
        transform: translateY(-2px);
        color: #2c5aa0;
    }
    
    .quick-action-btn i {
        font-size: 18px;
        color: #2c5aa0;
    }
    
    /* Modal Styles */
    .modal-header {
        background: linear-gradient(135deg, #2c5aa0 0%, #1e3a6f 100%);
        color: white;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }
    
    .modal-title {
        font-weight: 600;
        font-size: 1.25rem;
    }
    
    .modal-body {
        padding: 1.5rem;
    }
    
    .modal-footer {
        border-top: 1px solid #e2e8f0;
        padding: 1rem 1.5rem;
    }
    
    .form-label {
        font-weight: 600;
        color: #1e293b;
        margin-bottom: 0.5rem;
        font-size: 0.95rem;
    }
    
    .form-control {
        border: 1px solid #e2e8f0;
        border-radius: 8px;
        padding: 0.75rem 1rem;
        font-size: 0.95rem;
        transition: all 0.2s ease;
        background-color: white;
    }
    
    .form-control:focus {
        border-color: #2c5aa0;
        box-shadow: 0 0 0 3px rgba(44, 90, 160, 0.1);
        outline: none;
    }
    
    .input-group-icon {
        position: relative;
    }
    
    .input-group-icon .form-control {
        padding-left: 2.75rem;
    }
    
    .input-group-icon .icon {
        position: absolute;
        left: 1rem;
        top: 50%;
        transform: translateY(-50%);
        color: #2c5aa0;
        z-index: 10;
        font-size: 1rem;
    }
    
    .required-field::after {
        content: " *";
        color: #ef4444;
    }
    
    /* Form grid for modal */
    .form-row {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 1rem;
        margin-bottom: 1rem;
    }
    
    @media (max-width: 768px) {
        .form-row {
            grid-template-columns: 1fr;
        }
    }
</style>

<div class="dashboard-container">
    <div class="container">
        <!-- Welcome Card -->
        <div class="welcome-card">
            <div class="welcome-header">
                <div class="d-flex align-items-center justify-content-between mb-4">
                    <div>
                        <div class="mode-indicator">
                            <i class="bi <?= $isMaintenance ? 'bi-exclamation-triangle-fill' : 'bi-check-circle-fill' ?> me-2"></i>
                            System is <?= $isMaintenance ? 'in Maintenance Mode' : 'Operational' ?>
                        </div>
                        <h1 class="h2 mb-2">
                            Welcome, <span style="color: #93c5fd;"><?= esc($session->get('login_name')) ?></span>
                        </h1>
                        <p class="lead mb-0" style="color: rgba(255, 255, 255, 0.9);">
                            Pensioner Association Management System
                        </p>
                    </div>
                    <div class="d-none d-md-block">
                        <div class="date-display" style="background: rgba(255, 255, 255, 0.1); padding: 0.75rem 1.5rem; border-radius: 8px; color: white;">
                            <i class="bi bi-calendar3 me-2"></i>
                            <?= date('l, F j, Y') ?>
                        </div>
                    </div>
                </div>
                
                <!-- Quick Actions -->
                <div class="quick-actions">
                    <button type="button" class="quick-action-btn" data-bs-toggle="modal" data-bs-target="#registerPensionerModal" style="background: rgba(255, 255, 255, 0.15); border-color: rgba(255, 255, 255, 0.3); color: white;">
                        <i class="bi bi-person-plus"></i>
                        Register Pensioner
                    </button>
                    <?php if ($session->login_type == 1): ?>
                    <a href="<?= site_url('Main/users') ?>" class="quick-action-btn" style="background: rgba(255, 255, 255, 0.15); border-color: rgba(255, 255, 255, 0.3); color: white;">
                        <i class="bi bi-people"></i>
                        Manage Users
                    </a>
                    <?php endif; ?>
                    <a href="<?= site_url('admin/pensioners') ?>" class="quick-action-btn" style="background: rgba(255, 255, 255, 0.15); border-color: rgba(255, 255, 255, 0.3); color: white;">
                        <i class="bi bi-list-ul"></i>
                        View All Pensioners
                    </a>
                </div>
            </div>
            
            <div class="welcome-body">
                <div class="row">
                    <div class="col-lg-8">
                        <h3 class="h5 mb-4" style="color: #2c5aa0;">
                            <i class="bi bi-speedometer2 me-2"></i>System Overview
                        </h3>
                        
                        <p class="mb-4" style="color: #475569;">
                            Welcome to the Pensioner Association Management System, a comprehensive platform designed 
                            to streamline pensioner data management with precision and security. Our system ensures 
                            efficient handling of records while maintaining the highest standards of data integrity.
                        </p>
                        
                        <h4 class="h6 mb-3" style="color: #2c5aa0;">
                            <i class="bi bi-columns-gap me-2"></i>Key Modules
                        </h4>
                        
                        <ul class="feature-list mb-4">
                            <li>
                                <i class="bi bi-person-badge"></i>
                                Pensioner Profile Management
                            </li>
                            <li>
                                <i class="bi bi-arrow-clockwise"></i>
                                Record Updates & Modifications
                            </li>
                            <li>
                                <i class="bi bi-people"></i>
                                User Account Administration
                            </li>
                            <li>
                                <i class="bi bi-graph-up"></i>
                                Reports & Analytics
                            </li>
                            <li>
                                <i class="bi bi-shield-check"></i>
                                Security & Access Controls
                            </li>
                        </ul>
                    </div>
                    
                    <div class="col-lg-4">
                        <div class="card border-0" style="background: #f1f5f9; border: 1px solid #e2e8f0;">
                            <div class="card-body p-4">
                                <h4 class="h6 mb-3" style="color: #2c5aa0;">
                                    <i class="bi bi-tools me-2"></i>System Status
                                </h4>
                                
                                <p class="small" style="color: #64748b; margin-bottom: 1.5rem;">
                                    Maintenance mode restricts access to regular users while allowing administrators 
                                    to perform system updates and maintenance.
                                </p>
                                
                                <a href="<?= site_url('/toggle_mode') ?>" 
                                   class="btn mode-toggle-btn mb-3 <?= $isMaintenance ? 'btn-maintenance' : 'btn-operational' ?>">
                                    <i class="bi <?= $isMaintenance ? 'bi-toggle-off' : 'bi-toggle-on' ?> me-2"></i>
                                    <?= $isMaintenance ? 'Disable Maintenance Mode' : 'Enable Maintenance Mode' ?>
                                </a>
                                
                                <?php if($isMaintenance): ?>
                                    <div class="alert alert-light border mt-3 small" role="alert" style="background: white; border-color: #fecaca; color: #dc2626;">
                                        <i class="bi bi-info-circle me-2"></i>
                                        Regular users will see a maintenance page until disabled
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Statistics Section -->
                <?php if ($session->login_type == 1): ?>
                <div class="row mt-5">
                    <div class="col-12">
                        <h3 class="h5 mb-4" style="color: #2c5aa0;">
                            <i class="bi bi-bar-chart me-2"></i>System Statistics
                        </h3>
                    </div>
                    
                    <div class="col-md-3 col-sm-6 mb-4">
                        <div class="stats-card">
                            <div class="stats-icon">
                                <i class="bi bi-people"></i>
                            </div>
                            <div class="stats-number" id="totalPensioners">0</div>
                            <div class="stats-label">Total Pensioners</div>
                        </div>
                    </div>
                    
                    <div class="col-md-3 col-sm-6 mb-4">
                        <div class="stats-card">
                            <div class="stats-icon">
                                <i class="bi bi-person-check"></i>
                            </div>
                            <div class="stats-number" id="activeUsers">0</div>
                            <div class="stats-label">Active Users</div>
                        </div>
                    </div>
                    
                    <div class="col-md-3 col-sm-6 mb-4">
                        <div class="stats-card">
                            <div class="stats-icon">
                                <i class="bi bi-calendar-check"></i>
                            </div>
                            <div class="stats-number" id="todayRegistrations">0</div>
                            <div class="stats-label">Today's Registrations</div>
                        </div>
                    </div>
                    
                    <div class="col-md-3 col-sm-6 mb-4">
                        <div class="stats-card">
                            <div class="stats-icon">
                                <i class="bi bi-clock-history"></i>
                            </div>
                            <div class="stats-number" id="pendingUpdates">0</div>
                            <div class="stats-label">Pending Updates</div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

  <!-- Register Pensioner Modal -->
  <div class="modal fade" id="registerPensionerModal" tabindex="-1" aria-labelledby="registerPensionerModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-white" id="registerPensionerModalLabel">
                    <i class="fas fa-user-plus me-2"></i>Register New Pensioner
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-4">
                <form id="pensionerForm" method="POST">
                    <?= csrf_field() ?>
                    
                    <!-- Personal Information Section -->
                    <div class="row mb-4">
                        <div class="col-12">
                            <h6 class="border-bottom pb-2 mb-3">
                                <i class="fas fa-id-card me-2"></i>Personal Information
                            </h6>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Full Name <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-user text-primary"></i>
                                </span>
                                <input type="text" name="full_name" class="form-control" placeholder="Enter full name" required>
                            </div>
                            <div class="invalid-feedback">Please enter full name</div>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">ID Number</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-id-card text-primary"></i>
                                </span>
                                <input type="text" name="id_number" class="form-control" placeholder="Enter ID number">
                            </div>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-semibold">Date of Birth</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-calendar-alt text-primary"></i>
                                </span>
                                <input type="date" name="date_of_birth" class="form-control">
                            </div>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-semibold">Gender <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-venus-mars text-primary"></i>
                                </span>
                                <select name="gender" class="form-control select-with-icon" required>
                                    <option value="">Select gender</option>
                                    <option value="male">Male</option>
                                    <option value="female">Female</option>
                                    <option value="other">Other</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-semibold">Marital Status</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-heart text-primary"></i>
                                </span>
                                <select name="marital_status" class="form-control select-with-icon">
                                    <option value="">Select status</option>
                                    <option value="single">Single</option>
                                    <option value="married">Married</option>
                                    <option value="divorced">Divorced</option>
                                    <option value="widowed">Widowed</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Contact Information Section -->
                    <div class="row mb-4">
                        <div class="col-12">
                            <h6 class="border-bottom pb-2 mb-3">
                                <i class="fas fa-address-book me-2"></i>Contact Information
                            </h6>
                        </div>
                        
                        <div class="col-12 mb-3">
                            <label class="form-label fw-semibold">Address</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-home text-primary"></i>
                                </span>
                                <textarea name="address" class="form-control" placeholder="Enter complete address" rows="2"></textarea>
                            </div>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Contact Number</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-phone text-primary"></i>
                                </span>
                                <input type="tel" name="contact_number" class="form-control" placeholder="Enter contact number">
                            </div>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Email Address</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-envelope text-primary"></i>
                                </span>
                                <input type="email" name="email" class="form-control" placeholder="Enter email address">
                            </div>
                        </div>
                    </div>
                    
                    <!-- Bank Information Section -->
                    <div class="row mb-4">
                        <div class="col-12">
                            <h6 class="border-bottom pb-2 mb-3">
                                <i class="fas fa-university me-2"></i>Bank Information
                            </h6>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Bank Account Number</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-credit-card text-primary"></i>
                                </span>
                                <input type="text" name="bank_account" class="form-control" placeholder="Enter bank account number">
                            </div>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Bank Name</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-landmark text-primary"></i>
                                </span>
                                <input type="text" name="bank_name" class="form-control" placeholder="Enter bank name">
                            </div>
                        </div>
                    </div>
                    
                    <!-- Next of Kin Section -->
                    <div class="row mb-4">
                        <div class="col-12">
                            <h6 class="border-bottom pb-2 mb-3">
                                <i class="fas fa-user-friends me-2"></i>Next of Kin Information
                            </h6>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Next of Kin Name</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-user-friends text-primary"></i>
                                </span>
                                <input type="text" name="next_of_kin" class="form-control" placeholder="Enter next of kin name">
                            </div>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Next of Kin Contact</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-phone text-primary"></i>
                                </span>
                                <input type="tel" name="next_of_kin_contact" class="form-control" placeholder="Enter contact number">
                            </div>
                        </div>
                    </div>
                    
                    <!-- Pension Information Section -->
                    <div class="row mb-4">
                        <div class="col-12">
                            <h6 class="border-bottom pb-2 mb-3">
                                <i class="fas fa-piggy-bank me-2"></i>Pension Information
                            </h6>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Pension Type <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-heartbeat text-primary"></i>
                                </span>
                                <select name="pension_type" class="form-control select-with-icon" required>
                                    <option value="">Select pension type</option>
                                    <option value="retirement">Retirement Pension</option>
                                    <option value="disability">Disability Pension</option>
                                    <option value="survivor">Survivor Pension</option>
                                    <option value="other">Other Pension</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Pension Amount <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-money-bill-wave text-primary"></i>
                                </span>
                                <input type="number" name="pension_amount" class="form-control" placeholder="0.00" step="0.01" min="0" required>
                            </div>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Pension Start Date</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-calendar-check text-primary"></i>
                                </span>
                                <input type="date" name="pension_start_date" class="form-control">
                            </div>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Status <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-chart-line text-primary"></i>
                                </span>
                                <select name="status" class="form-control select-with-icon" required>
                                    <option value="">Select status</option>
                                    <option value="active">Active</option>
                                    <option value="suspended">Suspended</option>
                                    <option value="deceased">Deceased</option>
                                    <option value="inactive">Inactive</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Additional Information Section -->
                    <div class="row mb-4">
                        <div class="col-12">
                            <h6 class="border-bottom pb-2 mb-3">
                                <i class="fas fa-clipboard-list me-2"></i>Additional Information
                            </h6>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Medical Conditions</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-medkit text-primary"></i>
                                </span>
                                <textarea name="medical_conditions" class="form-control" placeholder="Enter medical conditions" rows="2"></textarea>
                            </div>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Notes</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light">
                                    <i class="fas fa-sticky-note text-primary"></i>
                                </span>
                                <textarea name="notes" class="form-control" placeholder="Enter additional notes" rows="2"></textarea>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Information Alert -->
                    <div class="alert alert-info mt-4 mb-0">
                        <div class="d-flex align-items-center">
                            <i class="fas fa-info-circle me-3 fa-lg"></i>
                            <div>
                                <h6 class="alert-heading mb-2">Important Information</h6>
                                <ul class="mb-0 ps-3">
                                    <li>Fields marked with <span class="text-danger">*</span> are required.</li>
                                    <li>Ensure all information is accurate before submission.</li>
                                    <li>Pensioner will be added immediately upon successful submission.</li>
                                    <li>You can edit the pensioner details later if needed.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer border-top-0 pt-0">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    <i class="fas fa-times me-2"></i>Cancel
                </button>
                <button type="button" class="btn btn-primary" id="savePensionerBtn">
                    <i class="fas fa-save me-2"></i>Save Pensioner
                </button>
            </div>
        </div>
    </div>
</div>

<script>
    // For demo purposes - replace with actual API calls
    document.addEventListener('DOMContentLoaded', function() {
        // Simulate loading statistics
        setTimeout(() => {
            document.getElementById('totalPensioners').textContent = '1,247';
            document.getElementById('activeUsers').textContent = '42';
            document.getElementById('todayRegistrations').textContent = '8';
            document.getElementById('pendingUpdates').textContent = '23';
        }, 500);

        // Form validation for modal
        const pensionerForm = document.getElementById('pensionerForm');
        
        pensionerForm.addEventListener('submit', function(e) {
            const requiredFields = this.querySelectorAll('[required]');
            let isValid = true;
            
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    field.classList.add('is-invalid');
                    isValid = false;
                    
                    // Create error message if it doesn't exist
                    if (!field.nextElementSibling || !field.nextElementSibling.classList.contains('invalid-feedback')) {
                        const errorDiv = document.createElement('div');
                        errorDiv.className = 'invalid-feedback';
                        errorDiv.textContent = 'This field is required';
                        field.parentNode.appendChild(errorDiv);
                    }
                } else {
                    field.classList.remove('is-invalid');
                    // Remove error message if exists
                    const errorDiv = field.parentNode.querySelector('.invalid-feedback');
                    if (errorDiv) {
                        errorDiv.remove();
                    }
                }
            });
            
            if (!isValid) {
                e.preventDefault();
                e.stopPropagation();
                // Scroll to first error in modal
                const firstError = this.querySelector('.is-invalid');
                if (firstError) {
                    firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    firstError.focus();
                }
                return false;
            }
        });

        // Real-time validation
        document.querySelectorAll('#pensionerForm [required]').forEach(field => {
            field.addEventListener('input', function() {
                if (this.value.trim()) {
                    this.classList.remove('is-invalid');
                    const errorDiv = this.parentNode.querySelector('.invalid-feedback');
                    if (errorDiv) {
                        errorDiv.remove();
                    }
                }
            });
        });

        // Set max date for date of birth (must be at least 18 years old)
        const dobInput = document.querySelector('#pensionerForm input[name="date_of_birth"]');
        if (dobInput) {
            const today = new Date();
            const maxDate = new Date(today.getFullYear() - 18, today.getMonth(), today.getDate());
            dobInput.max = maxDate.toISOString().split('T')[0];
        }

        // Clear form when modal is hidden
        const registerModal = document.getElementById('registerPensionerModal');
        if (registerModal) {
            registerModal.addEventListener('hidden.bs.modal', function () {
                pensionerForm.reset();
                // Clear validation errors
                pensionerForm.querySelectorAll('.is-invalid').forEach(el => {
                    el.classList.remove('is-invalid');
                });
                pensionerForm.querySelectorAll('.invalid-feedback').forEach(el => {
                    el.remove();
                });
            });
        }

        // Auto-show modal if there's an error parameter in URL
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.has('showRegisterModal')) {
            const modal = new bootstrap.Modal(document.getElementById('registerPensionerModal'));
            modal.show();
        }
    });
</script>

<?= $this->endSection() ?>