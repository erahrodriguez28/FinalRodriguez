<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>System Under Maintenance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            height: 100vh;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            background: linear-gradient(135deg, #f8f0e3, #ffe5d4);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .maintenance-container {
            text-align: center;
            background: #fff3e6;
            padding: 3rem 2rem;
            border-radius: 25px;
            box-shadow: 0 20px 50px rgba(0,0,0,0.15);
            position: relative;
            max-width: 500px;
            animation: fadeIn 1.2s ease forwards;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .warning-icon {
            font-size: 4rem;
            color: #e74c3c;
            animation: shake 1s infinite;
            display: inline-block;
        }

        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-8px); }
            50% { transform: translateX(8px); }
            75% { transform: translateX(-8px); }
        }

        h1 {
            font-size: 2rem;
            font-weight: 700;
            margin-top: 1rem;
            color: #c0392b;
        }

        p {
            font-size: 1.1rem;
            color: #7f8c8d;
            margin-top: 0.5rem;
        }

        .btn-refresh {
            background-color: #d35400;
            border: none;
            color: #fff;
            padding: 0.6rem 1.2rem;
            border-radius: 50px;
            font-weight: 600;
            margin-top: 1.5rem;
            transition: all 0.3s ease;
        }

        .btn-refresh:hover {
            background-color: #e67e22;
            transform: scale(1.05);
        }

        /* Warning stripes on top */
        .maintenance-container::before {
            content: "⚠️⚠️⚠️";
            position: absolute;
            top: -25px;
            left: 50%;
            transform: translateX(-50%);
            font-size: 1.5rem;
            color: #e74c3c;
        }
    </style>
</head>
<body>
    <div class="maintenance-container">
        <div class="warning-icon">🚧</div>
        <h1>System Under Maintenance</h1>
        <p>Our system is currently undergoing maintenance. Please check back later.</p>
        <a href="<?= site_url('/') ?>" class="btn btn-refresh">Refresh</a>
    </div>
</body>
</html>
