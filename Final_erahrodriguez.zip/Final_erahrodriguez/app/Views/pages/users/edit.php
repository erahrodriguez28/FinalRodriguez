<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<style>
    /* Professional Color Override - Pensioner Management System */
    
    /* Primary Professional Colors */
    :root {
        --primary-blue: #2c5aa0;
        --primary-dark: #1e3a6f;
        --primary-light: #4a7fd4;
        --secondary-teal: #00695c;
        --success-green: #10b981;
        --warning-amber: #f59e0b;
        --danger-red: #ef4444;
        --info-blue: #3b82f6;
        --gray-dark: #1e293b;
        --gray-medium: #475569;
        --gray-light: #64748b;
        --border-color: #e2e8f0;
        --background-light: #f8fafc;
        --card-bg: #ffffff;
    }
    
    /* Card Styling */
    .card {
        border: 1px solid var(--border-color) !important;
        background: var(--card-bg) !important;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.04) !important;
        border-radius: 12px !important;
    }
    
    /* Header Colors */
    [style*="color: #e91e63"] {
        color: var(--primary-blue) !important;
    }
    
    .card-header h1 {
        color: var(--gray-dark) !important;
        font-weight: 700 !important;
    }
    
    .card-header p.text-muted {
        color: var(--gray-light) !important;
    }
    
    /* Back Button */
    [style*="background: #ffe6f0"]:not(.badge):not(.input-group-text) {
        background: rgba(44, 90, 160, 0.08) !important;
        color: var(--primary-blue) !important;
        border: 1px solid rgba(44, 90, 160, 0.2) !important;
    }
    
    [style*="border: 1px solid #ffb6c1"] {
        border-color: rgba(44, 90, 160, 0.2) !important;
    }
    
    /* Form Sections */
    [style*="background: #fafafa"] {
        background: #f8fafc !important;
        border: 1px solid var(--border-color) !important;
    }
    
    [style*="border: 1px solid #ffe6f0"] {
        border-color: var(--border-color) !important;
    }
    
    /* Section Headers */
    .fw-semibold[style*="color: #e91e63"] {
        color: var(--gray-dark) !important;
        font-weight: 600 !important;
    }
    
    /* Form Labels */
    .form-label[style*="color: #666"] {
        color: var(--gray-medium) !important;
        font-weight: 500 !important;
    }
    
    /* Icons in Labels */
    [style*="color: #ff85a2"] {
        color: var(--primary-blue) !important;
    }
    
    /* Form Inputs */
    [style*="border-color: #f8bbd9"] {
        border-color: var(--border-color) !important;
    }
    
    /* Input Group Text */
    .input-group-text[style*="background: #ffe6f0"] {
        background: #f1f5f9 !important;
        border-color: var(--border-color) !important;
        color: var(--primary-blue) !important;
    }
    
    /* Placeholder Text */
    ::placeholder {
        color: var(--gray-light) !important;
        opacity: 0.7 !important;
    }
    
    /* Form Help Text */
    .form-text[style*="color: #999"] {
        color: var(--gray-light) !important;
        font-size: 0.85rem !important;
    }
    
    /* Badges in Form Help */
    [style*="background: #f3e5f5"].badge {
        background: rgba(44, 90, 160, 0.1) !important;
        color: var(--primary-blue) !important;
        border: 1px solid rgba(44, 90, 160, 0.2) !important;
    }
    
    [style*="background: #e3f2fd"].badge {
        background: rgba(0, 105, 92, 0.1) !important;
        color: var(--secondary-teal) !important;
        border: 1px solid rgba(0, 105, 92, 0.2) !important;
    }
    
    /* Toggle Password Button */
    .toggle-password[style*="background: #ffe6f0"] {
        background: #f1f5f9 !important;
        border-color: var(--border-color) !important;
        color: var(--primary-blue) !important;
    }
    
    /* Form Select */
    .form-select[style*="border-color: #f8bbd9"] {
        border-color: var(--border-color) !important;
        color: var(--gray-dark) !important;
    }
    
    /* Submit Button */
    [style*="background: linear-gradient(135deg, #ff85a2, #e91e63)"] {
        background: linear-gradient(135deg, var(--primary-blue) 0%, var(--primary-dark) 100%) !important;
        color: white !important;
        border: none !important;
    }
    
    /* Cancel Button */
    [style*="background: transparent; color: #666; border: 1px solid #ddd"] {
        background: transparent !important;
        color: var(--gray-medium) !important;
        border: 1px solid var(--border-color) !important;
    }
    
    /* Alerts */
    [style*="background: #ffebee"] {
        background: rgba(239, 68, 68, 0.08) !important;
        border-color: rgba(239, 68, 68, 0.2) !important;
        color: var(--danger-red) !important;
    }
    
    [style*="background: #e8f5e9"] {
        background: rgba(16, 185, 129, 0.08) !important;
        border-color: rgba(16, 185, 129, 0.2) !important;
        color: var(--success-green) !important;
    }
    
    /* Alert Icons */
    [style*="color: #c62828"] {
        color: var(--danger-red) !important;
    }
    
    [style*="color: #2e7d32"] {
        color: var(--success-green) !important;
    }
    
    /* Focus States */
    .form-control:focus, .form-select:focus {
        border-color: var(--primary-blue) !important;
        box-shadow: 0 0 0 0.2rem rgba(44, 90, 160, 0.25) !important;
    }
    
    /* Input Group Focus */
    .input-group:focus-within .input-group-text {
        background: var(--primary-blue) !important;
        color: white !important;
        border-color: var(--primary-blue) !important;
    }
    
    /* Toggle Password Hover */
    .toggle-password:hover {
        background: var(--primary-blue) !important;
        color: white !important;
    }
    
    /* Button Hover Effects */
    [style*="background: linear-gradient(135deg, #ff85a2, #e91e63)"]:hover {
        background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary-blue) 100%) !important;
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(44, 90, 160, 0.2);
    }
    
    /* Back Button Hover */
    [style*="background: #ffe6f0"]:not(.badge):not(.input-group-text):hover {
        background: rgba(44, 90, 160, 0.15) !important;
        border-color: var(--primary-blue) !important;
        transform: translateY(-1px);
    }
    
    /* Cancel Button Hover */
    [style*="background: transparent; color: #666; border: 1px solid #ddd"]:hover {
        background: #f1f5f9 !important;
        border-color: var(--primary-blue) !important;
        color: var(--primary-blue) !important;
    }
    
    /* Select Options */
    option {
        color: var(--gray-dark) !important;
        padding: 8px !important;
    }
    
    /* Remove girly borders from options */
    option[value="1"]::before {
        content: "👑 ";
        color: var(--primary-blue);
    }
    
    option[value="2"]::before {
        content: "👤 ";
        color: var(--secondary-teal);
    }
    
    /* Status Options */
    option[value="0"]::before {
        content: "⚪ ";
        color: var(--gray-light);
    }
    
    option[value="1"]::before {
        content: "🟢 ";
        color: var(--success-green);
    }
    
    option[value="2"]::before {
        content: "🔴 ";
        color: var(--danger-red);
    }
    
    /* Remove form section background on focus */
    [style*="background: #fafafa"]:focus-within {
        background: white !important;
        border-color: var(--primary-blue) !important;
        box-shadow: 0 0 0 1px rgba(44, 90, 160, 0.1);
    }
    
    /* Password strength indicator adjustments */
    .password-strength-bar {
        background: var(--primary-blue) !important;
    }
    
    /* Loading animation color */
    @keyframes professional-pulse {
        0% { opacity: 1; background: var(--primary-blue); }
        50% { opacity: 0.7; background: var(--primary-light); }
        100% { opacity: 1; background: var(--primary-blue); }
    }
    
    .loading {
        animation: professional-pulse 1.5s infinite;
    }
    
    /* Mobile menu toggle professional */
    .mobile-menu-toggle[style*="background: linear-gradient(135deg, #ff85a2, #e91e63)"] {
        background: linear-gradient(135deg, var(--primary-blue) 0%, var(--primary-dark) 100%) !important;
        color: white !important;
    }
    
    /* Validation states */
    .was-validated .form-control:valid {
        border-color: rgba(16, 185, 129, 0.5) !important;
        background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 8 8'%3e%3cpath fill='%2310b981' d='M2.3 6.73L.6 4.53c-.4-1.04.46-1.4 1.1-.8l1.1 1.4 3.4-3.8c.6-.63 1.6-.27 1.2.7l-4 4.6c-.43.5-.8.4-1.1.1z'/%3e%3c/svg%3e");
    }
    
    .was-validated .form-control:invalid {
        border-color: rgba(239, 68, 68, 0.5) !important;
        background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 12 12' width='12' height='12' fill='none' stroke='%23ef4444'%3e%3ccircle cx='6' cy='6' r='4.5'/%3e%3cpath stroke-linejoin='round' d='M5.8 3.6h.4L6 6.5z'/%3e%3ccircle cx='6' cy='8.2' r='.6' fill='%23ef4444' stroke='none'/%3e%3c/svg%3e");
    }
    
    /* Password character counter */
    .form-text[style*="color: #c62828"] {
        color: var(--danger-red) !important;
    }
    
    .form-text[style*="color: #2e7d32"] {
        color: var(--success-green) !important;
    }
    
    /* Remove any pink box shadows */
    *[style*="box-shadow"] {
        box-shadow: 0 0 0 0.2rem rgba(44, 90, 160, 0.25) !important;
    }
    
    /* Card hover effect professional */
    .card:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 24px rgba(0, 0, 0, 0.08) !important;
    }
    
    /* Responsive adjustments */
    @media (max-width: 768px) {
        .card {
            margin: 0 !important;
            border-radius: 12px !important;
        }
        
        .form-control, .form-select {
            font-size: 16px !important;
        }
        
        /* Keep mobile menu professional */
        .mobile-menu-toggle {
            background: var(--primary-blue) !important;
            color: white !important;
        }
    }
    
    /* Enhanced typography */
    h1, h2, h3, h4, h5, h6 {
        font-weight: 600 !important;
        color: var(--gray-dark) !important;
    }
    
    /* Subtle form improvements */
    .form-control, .form-select {
        border-radius: 8px !important;
        padding: 0.75rem 1rem !important;
        font-size: 0.95rem !important;
        transition: all 0.2s ease !important;
    }
    
    .btn {
        border-radius: 8px !important;
        font-weight: 500 !important;
        transition: all 0.2s ease !important;
    }
    
    /* Section spacing */
    .mb-4 {
        border-radius: 10px !important;
        margin-bottom: 1.5rem !important;
    }
</style>

<!-- YOUR EXISTING HTML CODE STARTS HERE - NO CHANGES -->
<div class="card rounded-3 shadow-sm border-0">
    <div class="card-header bg-white border-0 pt-4">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3">
            <div>
                <h1 class="h4 mb-1 fw-bold" style="color: #e91e63;">✏️ Edit User</h1>
                <p class="text-muted small mb-0">Update user details and permissions</p>
            </div>
            <div>
                <a href="<?= base_url('Main/users') ?>" class="btn px-4 py-2" 
                   style="background: #ffe6f0; color: #e91e63; border: 1px solid #ffb6c1; border-radius: 8px;">
                    <i class="fas fa-arrow-left me-1"></i> Back to List
                </a>
            </div>
        </div>
    </div>
    
    <div class="card-body p-0 p-md-4">
        <div class="container-fluid">
            <form action="<?= base_url('Main/user_edit/'.(isset($user['id'])? $user['id'] : '')) ?>" method="POST" class="needs-validation" novalidate>
                
                <!-- Alert Messages -->
                <?php if($session->getFlashdata('error')): ?>
                    <div class="alert alert-danger rounded-3 mb-4" style="background: #ffebee; border-color: #ffcdd2; color: #c62828;">
                        <div class="d-flex align-items-center">
                            <i class="fas fa-exclamation-circle me-3 fs-5"></i>
                            <div><?= $session->getFlashdata('error') ?></div>
                        </div>
                    </div>
                <?php endif; ?>
                
                <?php if($session->getFlashdata('success')): ?>
                    <div class="alert alert-success rounded-3 mb-4" style="background: #e8f5e9; border-color: #c8e6c9; color: #2e7d32;">
                        <div class="d-flex align-items-center">
                            <i class="fas fa-check-circle me-3 fs-5"></i>
                            <div><?= $session->getFlashdata('success') ?></div>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- User Information Section -->
                <div class="mb-4 p-3 p-md-4 rounded-3" style="background: #fafafa; border: 1px solid #ffe6f0;">
                    <h5 class="mb-3 fw-semibold" style="color: #e91e63;">👤 Personal Information</h5>
                    
                    <!-- Name Field -->
                    <div class="mb-3">
                        <label for="name" class="form-label fw-medium" style="color: #666;">
                            <i class="fas fa-user me-1" style="color: #ff85a2;"></i> Full Name
                        </label>
                        <div class="input-group">
                            <input type="text" class="form-control py-3" id="name" name="name" 
                                   placeholder="Enter full name" 
                                   value="<?= !empty($user['name']) ? htmlspecialchars($user['name']) : '' ?>" 
                                   required
                                   style="border-color: #f8bbd9; border-radius: 8px 0 0 8px;">
                            <span class="input-group-text" style="background: #ffe6f0; border-color: #f8bbd9; color: #e91e63; border-radius: 0 8px 8px 0;">
                                <i class="fas fa-user"></i>
                            </span>
                        </div>
                        <div class="form-text" style="color: #999;">Enter the user's full name</div>
                    </div>

                    <!-- Email Field -->
                    <div class="mb-3">
                        <label for="email" class="form-label fw-medium" style="color: #666;">
                            <i class="fas fa-envelope me-1" style="color: #ff85a2;"></i> Email Address
                        </label>
                        <div class="input-group">
                            <input type="email" class="form-control py-3" id="email" name="email" 
                                   placeholder="user@example.com" 
                                   value="<?= !empty($user['email']) ? htmlspecialchars($user['email']) : '' ?>" 
                                   required
                                   style="border-color: #f8bbd9; border-radius: 8px 0 0 8px;">
                            <span class="input-group-text" style="background: #ffe6f0; border-color: #f8bbd9; color: #e91e63; border-radius: 0 8px 8px 0;">
                                <i class="fas fa-at"></i>
                            </span>
                        </div>
                        <div class="form-text" style="color: #999;">User's email for login and notifications</div>
                    </div>
                </div>

                <!-- Password Section -->
                <div class="mb-4 p-3 p-md-4 rounded-3" style="background: #fafafa; border: 1px solid #ffe6f0;">
                    <h5 class="mb-3 fw-semibold" style="color: #e91e63;">🔒 Change Password <small class="text-muted fw-normal">(Optional)</small></h5>
                    
                    <!-- Password Field -->
                    <div class="mb-3">
                        <label for="password" class="form-label fw-medium" style="color: #666;">
                            <i class="fas fa-lock me-1" style="color: #ff85a2;"></i> New Password
                        </label>
                        <div class="input-group">
                            <input type="password" class="form-control py-3" id="password" name="password" 
                                   placeholder="Leave blank to keep current password"
                                   style="border-color: #f8bbd9; border-radius: 8px 0 0 8px;">
                            <button type="button" class="input-group-text toggle-password" 
                                    style="background: #ffe6f0; border-color: #f8bbd9; color: #e91e63; border-radius: 0 8px 8px 0; cursor: pointer;">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                        <div class="form-text" style="color: #999;">Minimum 8 characters with letters and numbers</div>
                    </div>

                    <!-- Confirm Password Field -->
                    <div class="mb-3">
                        <label for="cpassword" class="form-label fw-medium" style="color: #666;">
                            <i class="fas fa-lock me-1" style="color: #ff85a2;"></i> Confirm New Password
                        </label>
                        <div class="input-group">
                            <input type="password" class="form-control py-3" id="cpassword" name="cpassword" 
                                   placeholder="Re-enter new password"
                                   style="border-color: #f8bbd9; border-radius: 8px 0 0 8px;">
                            <button type="button" class="input-group-text toggle-password" 
                                    style="background: #ffe6f0; border-color: #f8bbd9; color: #e91e63; border-radius: 0 8px 8px 0; cursor: pointer;">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Permissions Section -->
                <div class="mb-4 p-3 p-md-4 rounded-3" style="background: #fafafa; border: 1px solid #ffe6f0;">
                    <h5 class="mb-3 fw-semibold" style="color: #e91e63;">⚙️ User Permissions</h5>
                    
                    <div class="row">
                        <!-- User Type -->
                        <div class="col-md-6 mb-3 mb-md-0">
                            <label for="type" class="form-label fw-medium" style="color: #666;">
                                <i class="fas fa-user-tag me-1" style="color: #ff85a2;"></i> User Type
                            </label>
                            <select name="type" id="type" class="form-select py-3" required
                                    style="border-color: #f8bbd9; border-radius: 8px;">
                                <option value="1" <?= isset($user['type']) && $user['type'] == 1 ? 'selected' : '' ?>>
                                    👑 Administrator
                                </option>
                                <option value="2" <?= isset($user['type']) && $user['type'] == 2 ? 'selected' : '' ?>>
                                    👤 Regular User
                                </option>
                            </select>
                            <div class="form-text" style="color: #999;">
                                <span class="badge px-2 py-1 me-1" style="background: #f3e5f5; color: #7b1fa2;">👑 Admin</span> Full system access
                                <br>
                                <span class="badge px-2 py-1" style="background: #e3f2fd; color: #1565c0;">👤 User</span> Limited access
                            </div>
                        </div>

                        <!-- Account Status -->
                        <div class="col-md-6">
                            <label for="status" class="form-label fw-medium" style="color: #666;">
                                <i class="fas fa-user-check me-1" style="color: #ff85a2;"></i> Account Status
                            </label>
                            <select name="status" id="status" class="form-select py-3" required
                                    style="border-color: #f8bbd9; border-radius: 8px;">
                                <option value="0" <?= isset($user['status']) && $user['status'] == 0 ? 'selected' : '' ?>>
                                    ⚪ Inactive
                                </option>
                                <option value="1" <?= isset($user['status']) && $user['status'] == 1 ? 'selected' : '' ?>>
                                    🟢 Active
                                </option>
                                <option value="2" <?= isset($user['status']) && $user['status'] == 2 ? 'selected' : '' ?>>
                                    🔴 Banned
                                </option>
                            </select>
                            <div class="form-text" style="color: #999;">
                                Control user's ability to login
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Submit Button -->
                <div class="d-grid gap-2 mt-4">
                    <button type="submit" class="btn py-3 fw-semibold" 
                            style="background: linear-gradient(135deg, #ff85a2, #e91e63); color: white; border: none; border-radius: 8px;">
                        <i class="fas fa-save me-2"></i> Update User Details
                    </button>
                    <a href="<?= base_url('Main/users') ?>" class="btn py-3 fw-medium" 
                       style="background: transparent; color: #666; border: 1px solid #ddd; border-radius: 8px;">
                        <i class="fas fa-times me-2"></i> Cancel
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Your existing CSS and JavaScript remain below -->
<style>
    /* Girlie Color Variables - KEEP THIS INTACT */
    :root {
        --pink: #ff85a2;
        --pink-light: #ffe6f0;
        --pink-dark: #e91e63;
        --purple-light: #f3e5f5;
        --purple-dark: #7b1fa2;
        --border-color: #f8bbd9;
        --bg-light: #fafafa;
    }
    /* ... rest of your existing CSS remains unchanged ... */
</style>

<script>
    // Your existing JavaScript remains unchanged
    document.addEventListener('DOMContentLoaded', function() {
        // ... all your existing JavaScript code ...
    });
</script>

<?= $this->endSection() ?>