<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<style>
    /* Professional Color Override - Pensioner Management System */
    
    /* Primary Professional Colors */
    :root {
        --primary-blue: #2c5aa0;
        --primary-dark: #1e3a6f;
        --primary-light: #4a7fd4;
        --secondary-teal: #00695c;
        --success-green: #10b981;
        --warning-amber: #f59e0b;
        --danger-red: #ef4444;
        --info-blue: #3b82f6;
        --gray-dark: #1e293b;
        --gray-medium: #475569;
        --gray-light: #64748b;
        --border-color: #e2e8f0;
        --background-light: #f8fafc;
    }
    
    /* Card & Container Styling */
    .card {
        border: 1px solid var(--border-color) !important;
        background: white !important;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.04) !important;
    }
    
    /* Header Colors */
    [style*="color: #e91e63"] {
        color: var(--primary-blue) !important;
    }
    
    .card-header h1 {
        color: var(--gray-dark) !important;
        font-weight: 700 !important;
    }
    
    /* Table Header */
    [style*="background: #fff0f5"] {
        background: #f1f5f9 !important;
    }
    
    [style*="color: #880e4f"] {
        color: var(--gray-dark) !important;
        font-weight: 600 !important;
    }
    
    /* Table Content Colors */
    [style*="color: #666"] {
        color: var(--gray-medium) !important;
    }
    
    [style*="color: #333"] {
        color: var(--gray-dark) !important;
        font-weight: 600 !important;
    }
    
    /* User Avatar */
    [style*="background: linear-gradient(45deg, #ff85a2, #e91e63)"] {
        background: linear-gradient(135deg, var(--primary-blue) 0%, var(--primary-dark) 100%) !important;
    }
    
    /* Badge Colors */
    /* Administrator Badge */
    [style*="background: #f3e5f5"] {
        background: rgba(44, 90, 160, 0.1) !important;
        color: var(--primary-blue) !important;
        border: 1px solid rgba(44, 90, 160, 0.2) !important;
    }
    
    [style*="color: #7b1fa2"] {
        color: var(--primary-blue) !important;
    }
    
    /* Regular User Badge */
    [style*="background: #e3f2fd"] {
        background: rgba(0, 105, 92, 0.1) !important;
        color: var(--secondary-teal) !important;
        border: 1px solid rgba(0, 105, 92, 0.2) !important;
    }
    
    [style*="color: #1565c0"] {
        color: var(--secondary-teal) !important;
    }
    
    /* Status Badges */
    /* Active Status */
    [style*="background: #e8f5e9"] {
        background: rgba(16, 185, 129, 0.1) !important;
        color: var(--success-green) !important;
        border: 1px solid rgba(16, 185, 129, 0.2) !important;
    }
    
    [style*="color: #2e7d32"] {
        color: var(--success-green) !important;
    }
    
    /* Not Active Status */
    [style*="background: #fff3e0"] {
        background: rgba(100, 116, 139, 0.1) !important;
        color: var(--gray-light) !important;
        border: 1px solid rgba(100, 116, 139, 0.2) !important;
    }
    
    [style*="color: #ef6c00"] {
        color: var(--gray-light) !important;
    }
    
    /* Banned Status */
    [style*="background: #ffebee"] {
        background: rgba(239, 68, 68, 0.1) !important;
        color: var(--danger-red) !important;
        border: 1px solid rgba(239, 68, 68, 0.2) !important;
    }
    
    [style*="color: #c62828"] {
        color: var(--danger-red) !important;
    }
    
    /* Invalid Status */
    [style*="background: #f5f5f5"] {
        background: rgba(100, 116, 139, 0.1) !important;
        color: var(--gray-light) !important;
        border: 1px solid rgba(100, 116, 139, 0.2) !important;
    }
    
    [style*="color: #616161"] {
        color: var(--gray-light) !important;
    }
    
    /* Action Buttons */
    /* Edit Button */
    [style*="background: #f3e5f5"]:not(.badge) {
        background: rgba(44, 90, 160, 0.08) !important;
        color: var(--primary-blue) !important;
        border: 1px solid rgba(44, 90, 160, 0.2) !important;
    }
    
    [style*="color: #7b1fa2"]:not(.badge) {
        color: var(--primary-blue) !important;
    }
    
    /* Delete Button */
    [style*="background: #ffebee"]:not(.badge) {
        background: rgba(239, 68, 68, 0.08) !important;
        color: var(--danger-red) !important;
        border: 1px solid rgba(239, 68, 68, 0.2) !important;
    }
    
    [style*="color: #c62828"]:not(.badge) {
        color: var(--danger-red) !important;
    }
    
    /* Email Button */
    [style*="background: #e3f2fd"]:not(.badge) {
        background: rgba(59, 130, 246, 0.08) !important;
        color: var(--info-blue) !important;
        border: 1px solid rgba(59, 130, 246, 0.2) !important;
    }
    
    [style*="color: #1565c0"]:not(.badge) {
        color: var(--info-blue) !important;
    }
    
    /* Form Inputs */
    [style*="border-color: #f8bbd9"] {
        border-color: var(--border-color) !important;
    }
    
    [style*="color: #e91e63"]:not(.small):not([style*="color: #e91e63;"]) {
        color: var(--primary-blue) !important;
    }
    
    .input-group-text {
        background: white !important;
        border-color: var(--border-color) !important;
        color: var(--primary-blue) !important;
    }
    
    /* Focus States */
    .form-control:focus, .form-select:focus {
        border-color: var(--primary-blue) !important;
        box-shadow: 0 0 0 0.2rem rgba(44, 90, 160, 0.25) !important;
    }
    
    /* Table Borders */
    [style*="border-color: #ffe6f0"] {
        border-color: var(--border-color) !important;
    }
    
    /* Mobile View */
    .d-md-none > div {
        border: 1px solid var(--border-color) !important;
        background: white !important;
    }
    
    /* Mobile Avatar */
    .d-md-none .me-2[style*="background: linear-gradient"] {
        background: linear-gradient(135deg, var(--primary-blue) 0%, var(--primary-dark) 100%) !important;
    }
    
    /* Empty State */
    [style*="color: #f8bbd9"] {
        color: #cbd5e1 !important;
    }
    
    [style*="color: #e91e63"].fw-medium {
        color: var(--gray-dark) !important;
        font-weight: 600 !important;
    }
    
    /* Pagination */
    .pagination .page-link {
        border-color: var(--border-color) !important;
        color: var(--gray-medium) !important;
    }
    
    .pagination .active .page-link {
        background: var(--primary-blue) !important;
        border-color: var(--primary-blue) !important;
        color: white !important;
    }
    
    .pagination .page-link:hover {
        background: #f1f5f9 !important;
        border-color: var(--primary-blue) !important;
        color: var(--primary-blue) !important;
    }
    
    /* Hover Effects */
    .table-hover tbody tr:hover {
        background-color: rgba(44, 90, 160, 0.02) !important;
    }
    
    /* Strong text */
    strong {
        color: var(--gray-medium) !important;
        font-weight: 600;
    }
    
    /* Text muted */
    .text-muted {
        color: var(--gray-light) !important;
    }
    
    /* Badge improvements */
    .badge {
        font-weight: 500 !important;
        border-radius: 6px !important;
        padding: 0.375rem 0.75rem !important;
        font-size: 0.8rem !important;
        display: inline-flex !important;
        align-items: center !important;
        gap: 0.25rem !important;
    }
    
    /* Button hover effects */
    .btn:hover {
        transform: translateY(-1px);
        transition: all 0.2s ease;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
    
    /* Mobile adjustments */
    @media (max-width: 768px) {
        .card {
            border-radius: 12px !important;
            margin: 0 !important;
        }
        
        .d-md-none .badge {
            padding: 0.25rem 0.5rem !important;
            font-size: 0.75rem !important;
        }
        
        .btn {
            padding: 0.5rem 1rem !important;
            font-size: 0.875rem !important;
        }
    }
    
    /* Emoji replacements for cleaner look */
    .form-select option[value="1"]::before {
        content: "👑 ";
        color: var(--primary-blue);
    }
    
    .form-select option[value="2"]::before {
        content: "👤 ";
        color: var(--secondary-teal);
    }
    
    /* Make table more readable */
    .table td, .table th {
        padding: 1rem !important;
        vertical-align: middle !important;
    }
    
    /* Card body padding */
    .card-body {
        padding: 1.5rem !important;
    }
</style>

<!-- YOUR EXISTING HTML CODE STARTS HERE - NO CHANGES -->
<div class="card rounded-3 shadow-sm border-0">
    <div class="card-header bg-white border-0 pb-3">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h1 class="h4 mb-1 fw-bold" style="color: #e91e63;">👥 Users Management</h1>
                <p class="text-muted small mb-0">Total: <?= count($users) ?> users</p>
            </div>
            <div class="d-none d-md-block">
               
            </div>
        </div>
    </div>
    
    <div class="card-body pt-0">
        <div class="container-fluid">
            <!-- Mobile Add Button -->
            <div class="d-md-none mb-3">
            
            </div>

            <!-- Search and Filters -->
            <div class="row mb-3">
                <div class="col-md-6">
                    <div class="input-group">
                        <span class="input-group-text bg-white" style="border-color: #f8bbd9; color: #e91e63;">
                            <i class="fas fa-search"></i>
                        </span>
                        <input type="text" class="form-control" placeholder="Search users..." id="searchInput" 
                               style="border-color: #f8bbd9;">
                    </div>
                </div>
                <div class="col-md-3 mt-2 mt-md-0">
                    <select class="form-select" id="typeFilter" style="border-color: #f8bbd9;">
                        <option value="">All Types</option>
                        <option value="1">👑 Administrator</option>
                        <option value="2">👤 User</option>
                    </select>
                </div>
                <div class="col-md-3 mt-2 mt-md-0">
                    <select class="form-select" id="statusFilter" style="border-color: #f8bbd9;">
                        <option value="">All Status</option>
                        <option value="1">🟢 Active</option>
                        <option value="0">⚪ Not Active</option>
                        <option value="2">🔴 Banned</option>
                    </select>
                </div>
            </div>

            <!-- Desktop Table View -->
            <div class="table-responsive d-none d-md-block">
                <table class="table table-hover align-middle" id="usersTable">
                    <thead>
                        <tr style="background: #fff0f5;">
                            <th class="ps-3 py-3" style="color: #880e4f;">#</th>
                            <th class="py-3" style="color: #880e4f;">User Details</th>
                            <th class="py-3" style="color: #880e4f;">Type</th>
                            <th class="py-3" style="color: #880e4f;">Status</th>
                            <th class="py-3" style="color: #880e4f;">Network Info</th>
                            <th class="py-3" style="color: #880e4f;">Dates</th>
                            <th class="pe-3 py-3" style="color: #880e4f;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($users as $row): ?>
                            <tr class="border-bottom" style="border-color: #ffe6f0 !important;">
                                <!-- ID -->
                                <th class="ps-3 py-3" style="color: #666;"><?= $row['id'] ?></th>
                                
                                <!-- Name & Email -->
                                <td class="py-3">
                                    <div class="d-flex align-items-center">
                                        <div class="me-3" style="width: 40px; height: 40px; background: linear-gradient(45deg, #ff85a2, #e91e63); border-radius: 10px; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold; font-size: 16px;">
                                            <?= strtoupper(substr($row['name'], 0, 1)) ?>
                                        </div>
                                        <div>
                                            <div class="fw-medium" style="color: #333;"><?= $row['name'] ?></div>
                                            <div class="small" style="color: #e91e63;"><?= $row['email'] ?></div>
                                        </div>
                                    </div>
                                </td>
                                
                                <!-- Type -->
                                <td class="py-3">
                                    <span class="badge px-3 py-1" style="background: <?= $row['type'] == 1 ? '#f3e5f5' : '#e3f2fd'; ?>; color: <?= $row['type'] == 1 ? '#7b1fa2' : '#1565c0'; ?>;">
                                        <?= ($row['type'] == 1) ? 'Administrator' : 'User' ?>
                                    </span>
                                </td>
                                
                                <!-- Status -->
                                <td class="py-3">
                                    <?php 
                                    switch($row['status']){
                                        case 0:
                                            echo '<span class="badge px-3 py-1" style="background: #fff3e0; color: #ef6c00;">Not Active</span>';
                                            break;
                                        case 1:
                                            echo '<span class="badge px-3 py-1" style="background: #e8f5e9; color: #2e7d32;">Active</span>';
                                            break;
                                        case 2:
                                            echo '<span class="badge px-3 py-1" style="background: #ffebee; color: #c62828;">Banned</span>';
                                            break;
                                        default:
                                            echo '<span class="badge px-3 py-1" style="background: #f5f5f5; color: #616161;">Invalid</span>';
                                            break;
                                    }
                                    ?>
                                </td>
                                
                                <!-- Network Info -->
                                <td class="py-3">
                                    <div class="small">
                                        <div style="color: #666;">
                                            <strong>IP:</strong> <?= $row['ip_address'] ?? '—' ?>
                                        </div>
                                        <div style="color: #666;" class="mt-1">
                                            <strong>MAC:</strong> <?= $row['mac_address'] ?? '—' ?>
                                        </div>
                                    </div>
                                </td>
                                
                                <!-- Dates -->
                                <td class="py-3">
                                    <div class="small">
                                        <div style="color: #666;">
                                            <strong>Created:</strong> <?= date('M d, Y', strtotime($row['created_at'])) ?? '—' ?>
                                        </div>
                                        <div style="color: #666;" class="mt-1">
                                            <strong>Last Login:</strong> <?= $row['last_login'] ? date('M d, h:i A', strtotime($row['last_login'])) : '—' ?>
                                        </div>
                                        <div style="color: #666;" class="mt-1">
                                            <strong>Last Logout:</strong> <?= $row['last_logout'] ? date('M d, h:i A', strtotime($row['last_logout'])) : '—' ?>
                                        </div>
                                    </div>
                                </td>
                                
                                <!-- Actions -->
                                <td class="pe-3 py-3">
                                    <div class="d-flex gap-2">
                                        <a href="<?= base_url('Main/user_edit/'.$row['id']) ?>" 
                                           class="btn btn-sm px-3" 
                                           style="background: #f3e5f5; color: #7b1fa2; border: none; border-radius: 6px;"
                                           title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a href="<?= base_url('Main/user_delete/'.$row['id']) ?>" 
                                           class="btn btn-sm px-3"
                                           style="background: #ffebee; color: #c62828; border: none; border-radius: 6px;"
                                           onclick="return confirm('Delete <?= htmlspecialchars($row['email']) ?>?')"
                                           title="Delete">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>

                        <?php if(count($users) <= 0): ?>
                            <tr>
                                <td colspan="7" class="text-center py-5">
                                    <div class="py-4">
                                        <div class="mb-3" style="font-size: 48px; color: #f8bbd9;">👥</div>
                                        <h6 class="fw-medium" style="color: #e91e63;">No users found</h6>
                                    </div>
                                </td>
                            </tr>
                        <?php endif ?>
                    </tbody>
                </table>
            </div>

            <!-- Mobile Card View -->
            <div class="d-md-none">
                <?php if(count($users) > 0): ?>
                    <?php foreach($users as $row): ?>
                        <div class="mb-3 p-3 rounded-3" style="background: white; border: 1px solid #ffe6f0;">
                            <!-- Header -->
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <div class="d-flex align-items-center">
                                    <div class="me-2" style="width: 36px; height: 36px; background: linear-gradient(45deg, #ff85a2, #e91e63); border-radius: 8px; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold; font-size: 14px;">
                                        <?= strtoupper(substr($row['name'], 0, 1)) ?>
                                    </div>
                                    <div>
                                        <div class="fw-medium small" style="color: #333;"><?= $row['name'] ?></div>
                                        <div class="x-small" style="color: #e91e63;"><?= $row['email'] ?></div>
                                    </div>
                                </div>
                                <div>
                                    <span class="badge px-2 py-1" style="background: <?= $row['type'] == 1 ? '#f3e5f5' : '#e3f2fd'; ?>; color: <?= $row['type'] == 1 ? '#7b1fa2' : '#1565c0'; ?>;">
                                        <?= ($row['type'] == 1) ? '👑 Admin' : '👤 User' ?>
                                    </span>
                                </div>
                            </div>
                            
                            <!-- Status & ID -->
                            <div class="d-flex justify-content-between mb-2">
                                <div>
                                    <?php 
                                    switch($row['status']){
                                        case 0:
                                            echo '<span class="badge px-2 py-1" style="background: #fff3e0; color: #ef6c00;">⚪ Not Active</span>';
                                            break;
                                        case 1:
                                            echo '<span class="badge px-2 py-1" style="background: #e8f5e9; color: #2e7d32;">🟢 Active</span>';
                                            break;
                                        case 2:
                                            echo '<span class="badge px-2 py-1" style="background: #ffebee; color: #c62828;">🔴 Banned</span>';
                                            break;
                                    }
                                    ?>
                                </div>
                                <div class="small" style="color: #666;">ID: <?= $row['id'] ?></div>
                            </div>
                            
                            <!-- Network Info -->
                            <div class="row g-1 mb-2">
                                <div class="col-6">
                                    <div class="x-small text-muted">IP Address</div>
                                    <div class="small" style="color: #666;"><?= $row['ip_address'] ?? '—' ?></div>
                                </div>
                                <div class="col-6">
                                    <div class="x-small text-muted">MAC Address</div>
                                    <div class="small" style="color: #666;"><?= $row['mac_address'] ?? '—' ?></div>
                                </div>
                            </div>
                            
                            <!-- Dates -->
                            <div class="row g-1 mb-3">
                                <div class="col-4">
                                    <div class="x-small text-muted">Created</div>
                                    <div class="small" style="color: #666;"><?= date('M d', strtotime($row['created_at'])) ?? '—' ?></div>
                                </div>
                                <div class="col-4">
                                    <div class="x-small text-muted">Last Login</div>
                                    <div class="small" style="color: #666;"><?= $row['last_login'] ? date('M d', strtotime($row['last_login'])) : '—' ?></div>
                                </div>
                                <div class="col-4">
                                    <div class="x-small text-muted">Last Logout</div>
                                    <div class="small" style="color: #666;"><?= $row['last_logout'] ? date('M d', strtotime($row['last_logout'])) : '—' ?></div>
                                </div>
                            </div>
                            
                            <!-- Actions -->
                            <div class="d-flex justify-content-between pt-2 border-top" style="border-color: #ffe6f0 !important;">
                                <a href="mailto:<?= $row['email'] ?>" 
                                   class="btn btn-sm px-3" 
                                   style="background: #e3f2fd; color: #1565c0; border: none; border-radius: 6px;">
                                    <i class="fas fa-envelope"></i>
                                </a>
                                <div class="d-flex gap-2">
                                    <a href="<?= base_url('Main/user_edit/'.$row['id']) ?>" 
                                       class="btn btn-sm px-3" 
                                       style="background: #f3e5f5; color: #7b1fa2; border: none; border-radius: 6px;">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="<?= base_url('Main/user_delete/'.$row['id']) ?>" 
                                       class="btn btn-sm px-3"
                                       style="background: #ffebee; color: #c62828; border: none; border-radius: 6px;"
                                       onclick="return confirm('Delete <?= htmlspecialchars($row['email']) ?>?')">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="text-center py-4">
                        <div class="mb-2" style="font-size: 36px; color: #f8bbd9;">👥</div>
                        <p class="small text-muted mb-0">No users found</p>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Pagination -->
            <div class="mt-4">
                <nav aria-label="Page navigation">
                    <?= $pager->makeLinks($page, $perPage, $total, 'custom_view') ?>
                </nav>
            </div>
        </div>
    </div>
</div>

<style>
    /* Simple Girlie Colors - KEEP THIS INTACT FOR BACKUP */
    :root {
        --pink: #ff85a2;
        --pink-light: #ffe6f0;
        --pink-dark: #e91e63;
        --purple-light: #f3e5f5;
        --purple-dark: #7b1fa2;
        --blue-light: #e3f2fd;
        --blue-dark: #1565c0;
        --green-light: #e8f5e9;
        --green-dark: #2e7d32;
        --orange-light: #fff3e0;
        --orange-dark: #ef6c00;
        --red-light: #ffebee;
        --red-dark: #c62828;
    }
    
    /* Card styling */
    .card {
        border: 1px solid #ffe6f0;
    }
    
    /* Table improvements */
    .table th {
        font-weight: 600;
        font-size: 0.9rem;
    }
    
    .table td {
        font-size: 0.9rem;
    }
    
    /* Badge styling */
    .badge {
        font-weight: 500;
        border-radius: 4px;
    }
    
    /* Responsive adjustments */
    @media (max-width: 768px) {
        .card {
            margin: 10px;
            border-radius: 12px;
        }
        
        .card-body {
            padding: 15px !important;
        }
        
        .btn {
            padding: 8px 12px !important;
            font-size: 14px !important;
        }
        
        /* Mobile cards */
        .d-md-none > div {
            border-radius: 10px;
            margin-bottom: 12px;
        }
        
        /* Filter inputs on mobile */
        .form-select, .input-group {
            font-size: 14px;
        }
        
        /* Pagination on mobile */
        .pagination {
            justify-content: center;
            flex-wrap: wrap;
        }
        
        .page-link {
            padding: 6px 10px;
            margin: 2px;
            font-size: 13px;
        }
    }
    
    @media (min-width: 769px) and (max-width: 1024px) {
        .table td, .table th {
            padding: 10px 8px;
            font-size: 0.85rem;
        }
        
        .btn-sm {
            padding: 4px 8px;
            font-size: 12px;
        }
    }
    
    /* Pagination styling */
    .pagination .page-link {
        border: 1px solid #ffe6f0;
        color: #e91e63;
        margin: 0 2px;
        border-radius: 6px;
    }
    
    .pagination .active .page-link {
        background: #ff85a2;
        border-color: #ff85a2;
        color: white;
    }
    
    .pagination .page-link:hover {
        background: #ffe6f0;
        border-color: #ff85a2;
    }
    
    /* Hover effects */
    .table-hover tbody tr:hover {
        background-color: rgba(255, 230, 240, 0.3) !important;
    }
    
    /* Input focus states */
    .form-control:focus, .form-select:focus {
        border-color: #ff85a2;
        box-shadow: 0 0 0 0.2rem rgba(255, 133, 162, 0.25);
    }
</style>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Simple filtering
        const searchInput = document.getElementById('searchInput');
        const typeFilter = document.getElementById('typeFilter');
        const statusFilter = document.getElementById('statusFilter');
        
        function filterUsers() {
            const searchTerm = searchInput.value.toLowerCase();
            const typeValue = typeFilter.value;
            const statusValue = statusFilter.value;
            
            // Desktop table
            const tableRows = document.querySelectorAll('#usersTable tbody tr');
            tableRows.forEach(row => {
                if (row.querySelector('th')) {
                    const rowText = row.textContent.toLowerCase();
                    const typeBadge = row.querySelector('td:nth-child(3) .badge');
                    const statusBadge = row.querySelector('td:nth-child(4) .badge');
                    
                    let showRow = true;
                    
                    // Search filter
                    if (searchTerm && !rowText.includes(searchTerm)) {
                        showRow = false;
                    }
                    
                    // Type filter
                    if (typeValue && typeBadge) {
                        const isAdmin = typeBadge.textContent.includes('Administrator');
                        if ((typeValue == '1' && !isAdmin) || (typeValue == '2' && isAdmin)) {
                            showRow = false;
                        }
                    }
                    
                    // Status filter
                    if (statusValue && statusBadge) {
                        const statusText = statusBadge.textContent.toLowerCase();
                        let expectedStatus = '';
                        switch(statusValue) {
                            case '0': expectedStatus = 'not active'; break;
                            case '1': expectedStatus = 'active'; break;
                            case '2': expectedStatus = 'banned'; break;
                        }
                        if (!statusText.includes(expectedStatus)) {
                            showRow = false;
                        }
                    }
                    
                    row.style.display = showRow ? '' : 'none';
                }
            });
            
            // Mobile cards
            const mobileCards = document.querySelectorAll('.d-md-none > div:not(.text-center)');
            mobileCards.forEach(card => {
                const cardText = card.textContent.toLowerCase();
                const typeBadge = card.querySelector('.badge');
                const statusBadge = card.querySelectorAll('.badge')[1];
                
                let showCard = true;
                
                // Search filter
                if (searchTerm && !cardText.includes(searchTerm)) {
                    showCard = false;
                }
                
                // Type filter
                if (typeValue && typeBadge) {
                    const isAdmin = typeBadge.textContent.includes('Admin');
                    if ((typeValue == '1' && !isAdmin) || (typeValue == '2' && isAdmin)) {
                        showCard = false;
                    }
                }
                
                // Status filter
                if (statusValue && statusBadge) {
                    const statusText = statusBadge.textContent.toLowerCase();
                    let expectedStatus = '';
                    switch(statusValue) {
                        case '0': expectedStatus = 'not active'; break;
                        case '1': expectedStatus = 'active'; break;
                        case '2': expectedStatus = 'banned'; break;
                    }
                    if (!statusText.includes(expectedStatus)) {
                        showCard = false;
                    }
                }
                
                card.style.display = showCard ? '' : 'none';
            });
        }
        
        // Event listeners
        searchInput.addEventListener('input', filterUsers);
        typeFilter.addEventListener('change', filterUsers);
        statusFilter.addEventListener('change', filterUsers);
        
        // Enter key to search
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                filterUsers();
            }
        });
        
        // Add clear button to search
        const clearBtn = document.createElement('button');
        clearBtn.innerHTML = '×';
        clearBtn.type = 'button';
        clearBtn.className = 'btn btn-sm position-absolute end-0 top-50 translate-middle-y me-2';
        clearBtn.style.background = 'transparent';
        clearBtn.style.border = 'none';
        clearBtn.style.color = '#e91e63';
        clearBtn.style.display = 'none';
        clearBtn.style.cursor = 'pointer';
        
        searchInput.parentElement.style.position = 'relative';
        searchInput.parentElement.appendChild(clearBtn);
        
        searchInput.addEventListener('input', function() {
            clearBtn.style.display = this.value ? 'block' : 'none';
        });
        
        clearBtn.addEventListener('click', function() {
            searchInput.value = '';
            searchInput.focus();
            clearBtn.style.display = 'none';
            filterUsers();
        });
    });
</script>

<?= $this->endSection() ?>