<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="container-fluid py-4">
    <div class="row justify-content-center">
        <div class="col-xxl-10 col-xl-12 col-lg-12">
            <!-- Header - Made Responsive -->


            <div class="row g-4">
                <!-- Left Column - Profile Overview - Made Responsive -->
                <div class="col-12 col-lg-4">
                    <div class="card border-0 shadow-sm h-100">
                        <div class="card-body p-3 p-md-4">
                            <!-- Profile Header -->
                            <div class="text-center mb-4">
                                <div class="position-relative d-inline-block mb-3">
                                    <div class="avatar-placeholder rounded-circle" 
                                         style="width: 120px; height: 120px; background: linear-gradient(135deg, #4a1d96, #6f42c1);">
                                        <span class="display-4 text-white" style="line-height: 120px;">
                                            <?= !empty($user['name']) ? substr($user['name'], 0, 1) : 'U' ?>
                                        </span>
                                    </div>
                                    <button type="button" class="btn btn-sm btn-primary rounded-circle position-absolute bottom-0 end-0 shadow-sm">
                                        <i class="fas fa-pencil-alt"></i>
                                    </button>
                                </div>
                                <h4 class="fw-bold mb-1 h5 h4-md"><?= !empty($user['name']) ? $user['name'] : 'Your Name' ?></h4>
                                <p class="text-muted mb-3 small">
                                    <i class="fas fa-user-check me-1"></i>Verified Pensioner
                                </p>
                            </div>

                            <!-- Profile Stats -->
                            <div class="profile-stats mb-4">
                                <h6 class="text-muted text-uppercase small fw-bold mb-3">Profile Status</h6>
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <span class="small">Profile Completion</span>
                                    <span class="fw-bold text-primary">85%</span>
                                </div>
                                <div class="progress mb-3" style="height: 6px;">
                                    <div class="progress-bar bg-primary" style="width: 85%"></div>
                                </div>
                                
                                <div class="row g-2">
                                    <div class="col-6">
                                        <div class="stat-box p-2 p-md-3 text-center border rounded-3">
                                            <i class="fas fa-calendar-check text-primary mb-2"></i>
                                            <div class="fw-bold small">Member Since</div>
                                            <small class="text-muted">
                                                <?= !empty($user['created_at']) ? date('M Y', strtotime($user['created_at'])) : 'N/A' ?>
                                            </small>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="stat-box p-2 p-md-3 text-center border rounded-3">
                                            <i class="fas fa-shield-alt text-success mb-2"></i>
                                            <div class="fw-bold small">Status</div>
                                            <span class="badge bg-success bg-opacity-10 text-success">Active</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Account Details -->
                            <div class="account-details">
                                <h6 class="text-muted text-uppercase small fw-bold mb-3">Account Details</h6>
                                <div class="list-group list-group-flush">
                                    <div class="list-group-item px-0 py-2 border-0">
                                        <div class="d-flex justify-content-between">
                                            <small class="text-muted">Last Updated</small>
                                            <small class="fw-semibold">
                                                <?= !empty($user['updated_at']) ? date('d M, Y', strtotime($user['updated_at'])) : 'Never' ?>
                                            </small>
                                        </div>
                                    </div>
                                    <div class="list-group-item px-0 py-2 border-0">
                                        <div class="d-flex justify-content-between">
                                            <small class="text-muted">Email Verified</small>
                                            <span class="badge bg-success bg-opacity-10 text-success">
                                                <i class="fas fa-check-circle me-1"></i>Verified
                                            </span>
                                        </div>
                                    </div>
                                    <div class="list-group-item px-0 py-2 border-0">
                                        <div class="d-flex justify-content-between">
                                            <small class="text-muted">Security Level</small>
                                            <small class="fw-semibold text-primary">High</small>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Quick Links -->
                        </div>
                    </div>
                </div>

                <!-- Right Column - Update Form - Made Responsive -->
                <div class="col-12 col-lg-8">
                    <div class="card border-0 shadow-sm">
                        <div class="card-header bg-white py-3 border-bottom">
                            <h5 class="card-title mb-0 fw-bold h5">
                                <i class="fas fa-user-edit me-2 text-primary"></i>Update Account Information
                            </h5>
                        </div>
                        <div class="card-body p-3 p-md-4">
                            <form action="<?= base_url('update_user') ?>" method="POST" id="updateProfileForm">
                                <!-- Flash Messages -->
                                <?php if($session->getFlashdata('error')): ?>
                                    <div class="alert alert-danger alert-dismissible fade show rounded-3" role="alert">
                                        <div class="d-flex align-items-center">
                                            <i class="fas fa-exclamation-triangle me-3"></i>
                                            <div class="small">
                                                <strong>Error!</strong> <?= $session->getFlashdata('error') ?>
                                            </div>
                                        </div>
                                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                    </div>
                                <?php endif; ?>
                                
                                <?php if($session->getFlashdata('success')): ?>
                                    <div class="alert alert-success alert-dismissible fade show rounded-3" role="alert">
                                        <div class="d-flex align-items-center">
                                            <i class="fas fa-check-circle me-3"></i>
                                            <div class="small">
                                                <strong>Success!</strong> <?= $session->getFlashdata('success') ?>
                                            </div>
                                        </div>
                                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                    </div>
                                <?php endif; ?>

                                <!-- Personal Information Section -->
                                <div class="section-card mb-4 p-3 p-md-4">
                                    <div class="d-flex align-items-center mb-3">
                                        <div class="icon-circle bg-primary bg-opacity-10 text-primary p-2 rounded me-3">
                                            <i class="fas fa-id-card"></i>
                                        </div>
                                        <h6 class="mb-0 fw-bold h6">Personal Information</h6>
                                    </div>
                                    
                                    <div class="row g-3">
                                        <div class="col-12">
                                            <label for="name" class="form-label fw-semibold small">Full Name</label>
                                            <div class="input-group">
                                                <span class="input-group-text bg-light border-end-0 py-2">
                                                    <i class="fas fa-user text-primary"></i>
                                                </span>
                                                <input type="text" class="form-control py-2" id="name" name="name" 
                                                       value="<?= !empty($user['name']) ? htmlspecialchars($user['name']) : '' ?>" 
                                                       placeholder="Enter your full name" required>
                                            </div>
                                            <small class="text-muted small">Enter your name exactly as it appears on official documents</small>
                                        </div>
                                        
                                        <div class="col-12">
                                            <label for="email" class="form-label fw-semibold small">Email Address</label>
                                            <div class="input-group">
                                                <span class="input-group-text bg-light border-end-0 py-2">
                                                    <i class="fas fa-envelope text-primary"></i>
                                                </span>
                                                <input type="email" class="form-control py-2" id="email" name="email" 
                                                       value="<?= !empty($user['email']) ? htmlspecialchars($user['email']) : '' ?>" 
                                                       placeholder="your.email@example.com" required>
                                            </div>
                                            <small class="text-muted small">All system notifications will be sent to this email</small>
                                        </div>
                                    </div>
                                </div>

                                <!-- Password Update Section -->
                                <div class="section-card mb-4 p-3 p-md-4">
                                    <div class="d-flex align-items-center mb-3">
                                        <div class="icon-circle bg-warning bg-opacity-10 text-warning p-2 rounded me-3">
                                            <i class="fas fa-key"></i>
                                        </div>
                                        <h6 class="mb-0 fw-bold h6">Password Settings</h6>
                                    </div>
                                    <p class="text-muted mb-3 small">Leave password fields blank if you don't want to change your password</p>
                                    
                                    <div class="row g-3">
                                        <div class="col-12 col-md-6">
                                            <label for="password" class="form-label fw-semibold small">New Password</label>
                                            <div class="input-group">
                                                <span class="input-group-text bg-light border-end-0 py-2">
                                                    <i class="fas fa-lock text-primary"></i>
                                                </span>
                                                <input type="password" class="form-control py-2" id="password" name="password" 
                                                       placeholder="Enter new password">
                                                <button class="btn btn-outline-secondary py-2" type="button" id="togglePassword">
                                                    <i class="fas fa-eye"></i>
                                                </button>
                                            </div>
                                            <div class="password-strength mt-2">
                                                <small class="text-muted small">Password must be at least 8 characters</small>
                                            </div>
                                        </div>
                                        
                                        <div class="col-12 col-md-6">
                                            <label for="cpassword" class="form-label fw-semibold small">Confirm Password</label>
                                            <div class="input-group">
                                                <span class="input-group-text bg-light border-end-0 py-2">
                                                    <i class="fas fa-lock text-primary"></i>
                                                </span>
                                                <input type="password" class="form-control py-2" id="cpassword" name="cpassword" 
                                                       placeholder="Confirm new password">
                                            </div>
                                            <div id="passwordMatch" class="mt-2 small"></div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Security Verification -->
                                <div class="section-card mb-4 p-3 p-md-4">
                                    <div class="d-flex align-items-center mb-3">
                                        <div class="icon-circle bg-danger bg-opacity-10 text-danger p-2 rounded me-3">
                                            <i class="fas fa-shield-alt"></i>
                                        </div>
                                        <h6 class="mb-0 fw-bold h6">Security Verification</h6>
                                    </div>
                                    <div class="alert alert-warning bg-opacity-10 border-warning small">
                                        <div class="d-flex">
                                            <i class="fas fa-exclamation-circle text-warning me-3 mt-1"></i>
                                            <div>
                                                <strong>Security Notice:</strong> For security purposes, you must enter your current password to save any changes.
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="current_password" class="form-label fw-semibold small">Current Password</label>
                                        <div class="input-group">
                                            <span class="input-group-text bg-light border-end-0 py-2">
                                                <i class="fas fa-key text-primary"></i>
                                            </span>
                                            <input type="password" class="form-control py-2" id="current_password" 
                                                   name="current_password" placeholder="Enter your current password" required>
                                        </div>
                                    </div>
                                </div>

                                <!-- Form Actions - Made Responsive -->
                                <div class="d-flex flex-column flex-sm-row justify-content-between pt-3 border-top">
                                    <button type="reset" class="btn btn-outline-secondary px-3 px-sm-4 mb-2 mb-sm-0">
                                        <i class="fas fa-redo me-2"></i>Reset Form
                                    </button>
                                    <button type="submit" class="btn btn-primary px-4 px-sm-5 fw-bold">
                                        <i class="fas fa-save me-2"></i>Save Changes
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                    
                    <!-- Additional Info Card -->
                    <div class="card border-0 shadow-sm mt-4">
                        <div class="card-body p-3 p-md-4">
                            <div class="d-flex align-items-center mb-3">
                                <i class="fas fa-info-circle text-primary me-3"></i>
                                <div>
                                    <h6 class="mb-1 fw-bold h6">Important Information</h6>
                                    <p class="text-muted mb-0 small">
                                        Keeping your profile updated ensures seamless pension processing and communication. 
                                        Contact support at <a href="mailto:support@pension.gov" class="text-primary">support@pension.gov</a> 
                                        for any assistance.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .card {
        border-radius: 12px;
        border: 1px solid rgba(0,0,0,0.08);
    }
    
    .avatar-placeholder {
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: bold;
        text-transform: uppercase;
    }
    
    .section-card {
        background: #f8f9fa;
        border-radius: 10px;
        padding: 1.5rem;
    }
    
    .icon-circle {
        width: 40px;
        height: 40px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .stat-box {
        transition: transform 0.2s;
        background: white;
    }
    
    .stat-box:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }
    
    .form-control, .input-group-text {
        border-radius: 8px;
        border: 1px solid #dee2e6;
    }
    
    .form-control:focus {
        border-color: #6f42c1;
        box-shadow: 0 0 0 0.2rem rgba(111, 66, 193, 0.25);
    }
    
    .btn-primary {
        background: linear-gradient(135deg, #6f42c1, #4a1d96);
        border: none;
        border-radius: 8px;
        padding: 10px 30px;
        transition: all 0.3s ease;
    }
    
    .btn-primary:hover {
        background: linear-gradient(135deg, #5a34a1, #3a1776);
        transform: translateY(-1px);
        box-shadow: 0 5px 15px rgba(111, 66, 193, 0.3);
    }
    
    .alert {
        border-radius: 10px;
        border: none;
    }
    
    .progress {
        border-radius: 10px;
    }
    
    .progress-bar {
        border-radius: 10px;
    }
    
    /* Mobile Responsive Additions */
    @media (max-width: 768px) {
        .avatar-placeholder {
            width: 100px !important;
            height: 100px !important;
        }
        
        .avatar-placeholder span {
            font-size: 2.5rem !important;
            line-height: 100px !important;
        }
        
        .btn-primary, .btn-outline-secondary {
            width: 100% !important;
            padding: 10px 20px !important;
        }
        
        .input-group-text {
            padding: 0.5rem !important;
        }
        
        .form-control {
            padding: 0.5rem !important;
        }
        
        .icon-circle {
            width: 35px !important;
            height: 35px !important;
        }
    }
    
    @media (max-width: 576px) {
        .container-fluid {
            padding-left: 15px !important;
            padding-right: 15px !important;
        }
        
        .card {
            border-radius: 10px !important;
        }
        
        .section-card {
            padding: 1rem !important;
        }
        
        .stat-box {
            padding: 1rem !important;
        }
        
        .alert {
            padding: 1rem !important;
        }
        
        .badge {
            font-size: 0.75rem !important;
        }
    }
    
    @media (max-width: 400px) {
        .row.g-2 .col-6 {
            width: 100% !important;
            margin-bottom: 10px;
        }
        
        .avatar-placeholder {
            width: 80px !important;
            height: 80px !important;
        }
        
        .avatar-placeholder span {
            font-size: 2rem !important;
            line-height: 80px !important;
        }
    }
</style>

<script>
    // Toggle password visibility
    document.getElementById('togglePassword').addEventListener('click', function() {
        const passwordInput = document.getElementById('password');
        const icon = this.querySelector('i');
        
        if (passwordInput.type === 'password') {
            passwordInput.type = 'text';
            icon.classList.remove('fa-eye');
            icon.classList.add('fa-eye-slash');
        } else {
            passwordInput.type = 'password';
            icon.classList.remove('fa-eye-slash');
            icon.classList.add('fa-eye');
        }
    });
    
    // Password match validation
    document.getElementById('cpassword').addEventListener('input', function() {
        const password = document.getElementById('password').value;
        const confirmPassword = this.value;
        const matchDiv = document.getElementById('passwordMatch');
        
        if (confirmPassword === '') {
            matchDiv.innerHTML = '';
            return;
        }
        
        if (password === confirmPassword) {
            matchDiv.innerHTML = '<small class="text-success"><i class="fas fa-check-circle me-1"></i>Passwords match</small>';
        } else {
            matchDiv.innerHTML = '<small class="text-danger"><i class="fas fa-times-circle me-1"></i>Passwords do not match</small>';
        }
    });
    
    // Form validation
    document.getElementById('updateProfileForm').addEventListener('submit', function(e) {
        const password = document.getElementById('password').value;
        const cpassword = document.getElementById('cpassword').value;
        
        if (password && password.length < 8) {
            e.preventDefault();
            showAlert('Password must be at least 8 characters long!', 'danger');
            return false;
        }
        
        if (password && password !== cpassword) {
            e.preventDefault();
            showAlert('New passwords do not match!', 'danger');
            return false;
        }
    });
    
    function showAlert(message, type) {
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type} alert-dismissible fade show rounded-3`;
        alertDiv.innerHTML = `
            <div class="d-flex align-items-center">
                <i class="fas fa-${type === 'danger' ? 'exclamation-triangle' : 'check-circle'} me-3"></i>
                <div class="small">${message}</div>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        const form = document.getElementById('updateProfileForm');
        form.insertBefore(alertDiv, form.firstChild);
        
        setTimeout(() => {
            alertDiv.remove();
        }, 5000);
    }
</script>
<?= $this->endSection() ?>