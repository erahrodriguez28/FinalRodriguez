<?php
use App\Models\NotificationModel;
$notificationModel = new NotificationModel();
$session = session();

if (isset($session->login_id)) {
    $isAdmin = ($session->login_type == 1);
    $userId = $session->login_id;
    $unreadCount = $notificationModel->getUnreadCount($isAdmin ? null : $userId, $isAdmin);
}
?>

<li class="nav-item dropdown">
    <a class="nav-link" href="#" id="notificationDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
        <i class="bi bi-bell"></i>
        <?php if ($unreadCount > 0): ?>
            <span class="badge bg-danger rounded-pill" id="notificationBadge"><?= $unreadCount ?></span>
        <?php endif; ?>
    </a>
    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="notificationDropdown" style="width: 350px;">
        <li>
            <h6 class="dropdown-header">Notifications</h6>
        </li>
        <li>
            <div id="notificationList" style="max-height: 300px; overflow-y: auto;">
                <!-- Notifications will be loaded via AJAX -->
                <div class="text-center p-3">
                    <div class="spinner-border spinner-border-sm" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                </div>
            </div>
        </li>
        <li><hr class="dropdown-divider"></li>
        <li>
            <a class="dropdown-item text-center" href="<?= base_url('notifications') ?>">
                View all notifications
            </a>
        </li>
    </ul>
</li>

<script>
$(document).ready(function() {
    loadNotifications();
    
    // Refresh notifications every 30 seconds
    setInterval(loadNotifications, 30000);
    
    // Load notifications when dropdown is shown
    $('#notificationDropdown').on('shown.bs.dropdown', function () {
        loadNotifications();
    });
});

function loadNotifications() {
    $.ajax({
        url: '<?= base_url('notifications/getNotifications') ?>',
        method: 'GET',
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                updateNotificationList(response.notifications);
                updateNotificationBadge(response.unreadCount);
            }
        }
    });
}

function updateNotificationList(notifications) {
    var $list = $('#notificationList');
    $list.empty();
    
    if (notifications.length === 0) {
        $list.html('<div class="text-center p-3 text-muted">No new notifications</div>');
        return;
    }
    
    notifications.forEach(function(notification) {
        var item = `
            <a href="${notification.action_url ? notification.action_url : 'javascript:void(0)'}" 
               class="dropdown-item d-flex align-items-start ${notification.is_read ? '' : 'fw-bold'}" 
               onclick="markNotificationAsRead(${notification.notification_id}, this)">
                <div class="me-2">
                    <i class="bi bi-${getNotificationIcon(notification.type)} text-${notification.type}"></i>
                </div>
                <div>
                    <div class="small">${notification.title}</div>
                    <div class="text-muted" style="font-size: 0.85em;">${notification.message}</div>
                    <div class="text-muted" style="font-size: 0.75em;">${timeAgo(notification.created_at)}</div>
                </div>
            </a>
            <div class="dropdown-divider"></div>
        `;
        $list.append(item);
    });
}

function updateNotificationBadge(count) {
    var $badge = $('#notificationBadge');
    if (count > 0) {
        if ($badge.length === 0) {
            $('#notificationDropdown').append('<span class="badge bg-danger rounded-pill" id="notificationBadge">' + count + '</span>');
        } else {
            $badge.text(count);
        }
    } else {
        $badge.remove();
    }
}

function markNotificationAsRead(notificationId, element) {
    $.post('<?= base_url('notifications/markAsRead') ?>/' + notificationId, function(response) {
        if (response.success) {
            $(element).removeClass('fw-bold');
            // Update badge count
            var currentCount = parseInt($('#notificationBadge').text()) || 0;
            if (currentCount > 1) {
                $('#notificationBadge').text(currentCount - 1);
            } else {
                $('#notificationBadge').remove();
            }
        }
    });
}

function getNotificationIcon(type) {
    const icons = {
        'info': 'info-circle',
        'success': 'check-circle',
        'warning': 'exclamation-triangle',
        'error': 'x-circle',
        'system': 'gear'
    };
    return icons[type] || 'bell';
}

function timeAgo(datetime) {
    const date = new Date(datetime);
    const now = new Date();
    const diffMs = now - date;
    const diffSec = Math.floor(diffMs / 1000);
    const diffMin = Math.floor(diffSec / 60);
    const diffHour = Math.floor(diffMin / 60);
    const diffDay = Math.floor(diffHour / 24);
    
    if (diffSec < 60) return 'Just now';
    if (diffMin < 60) return diffMin + ' min ago';
    if (diffHour < 24) return diffHour + ' hour' + (diffHour > 1 ? 's' : '') + ' ago';
    if (diffDay < 7) return diffDay + ' day' + (diffDay > 1 ? 's' : '') + ' ago';
    return date.toLocaleDateString();
}
</script>