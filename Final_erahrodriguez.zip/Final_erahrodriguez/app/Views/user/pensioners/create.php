<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>

<div class="container-fluid px-3 px-md-4 py-4">
    <div class="row justify-content-center">
        <div class="col-lg-10 col-xl-8">
            <!-- Card -->
            <div class="card border">
                <div class="card-header bg-white border-bottom py-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="fw-semibold mb-0">
                            <i class="bi bi-person-plus me-2"></i>
                            <?= isset($pensioner) ? 'Edit Pensioner' : 'Add New Pensioner' ?>
                        </h5>
                        <a href="<?= site_url('/user/pensioners/view') ?>" class="btn btn-outline-secondary btn-sm">
                            <i class="bi bi-arrow-left me-1"></i>Back
                        </a>
                    </div>
                </div>
                
                <div class="card-body p-3 p-md-4">
                    <form method="POST" action="<?= isset($pensioner) ? 
                        site_url('/user/pensioners/update/' . $pensioner['pensioner_id']) : 
                        site_url('/user/pensioners/store') ?>">
                        
                        <!-- Personal Information -->
                        <div class="mb-4">
                            <h6 class="fw-semibold mb-3 border-bottom pb-2">Personal Information</h6>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label">Full Name *</label>
                                    <input type="text" class="form-control" name="full_name" 
                                           value="<?= old('full_name', $pensioner['full_name'] ?? '') ?>" required>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label">Date of Birth *</label>
                                    <input type="date" class="form-control" name="date_of_birth" 
                                           value="<?= old('date_of_birth', $pensioner['date_of_birth'] ?? '') ?>" required>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label">Gender</label>
                                    <select class="form-select" name="gender">
                                        <option value="male" <?= isset($pensioner) && $pensioner['gender'] == 'male' ? 'selected' : '' ?>>Male</option>
                                        <option value="female" <?= isset($pensioner) && $pensioner['gender'] == 'female' ? 'selected' : '' ?>>Female</option>
                                        <option value="other" <?= isset($pensioner) && $pensioner['gender'] == 'other' ? 'selected' : '' ?>>Other</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">ID Number</label>
                                    <input type="text" class="form-control" name="id_number" 
                                           value="<?= old('id_number', $pensioner['id_number'] ?? '') ?>">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Marital Status</label>
                                    <select class="form-select" name="marital_status">
                                        <option value="single" <?= isset($pensioner) && $pensioner['marital_status'] == 'single' ? 'selected' : '' ?>>Single</option>
                                        <option value="married" <?= isset($pensioner) && $pensioner['marital_status'] == 'married' ? 'selected' : '' ?>>Married</option>
                                        <option value="divorced" <?= isset($pensioner) && $pensioner['marital_status'] == 'divorced' ? 'selected' : '' ?>>Divorced</option>
                                        <option value="widowed" <?= isset($pensioner) && $pensioner['marital_status'] == 'widowed' ? 'selected' : '' ?>>Widowed</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <!-- Contact Information -->
                        <div class="mb-4">
                            <h6 class="fw-semibold mb-3 border-bottom pb-2">Contact Information</h6>
                            <div class="row g-3">
                                <div class="col-md-12">
                                    <label class="form-label">Address</label>
                                    <textarea class="form-control" name="address" rows="2"><?= old('address', $pensioner['address'] ?? '') ?></textarea>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Contact Number</label>
                                    <input type="tel" class="form-control" name="contact_number" 
                                           value="<?= old('contact_number', $pensioner['contact_number'] ?? '') ?>">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Email Address</label>
                                    <input type="email" class="form-control" name="email" 
                                           value="<?= old('email', $pensioner['email'] ?? '') ?>">
                                </div>
                            </div>
                        </div>

                        <!-- Bank Details -->
                        <div class="mb-4">
                            <h6 class="fw-semibold mb-3 border-bottom pb-2">Bank Details</h6>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label">Bank Name</label>
                                    <input type="text" class="form-control" name="bank_name" 
                                           value="<?= old('bank_name', $pensioner['bank_name'] ?? '') ?>">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Account Number</label>
                                    <input type="text" class="form-control" name="bank_account" 
                                           value="<?= old('bank_account', $pensioner['bank_account'] ?? '') ?>">
                                </div>
                            </div>
                        </div>

                        <!-- Next of Kin -->
                        <div class="mb-4">
                            <h6 class="fw-semibold mb-3 border-bottom pb-2">Next of Kin</h6>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label">Name</label>
                                    <input type="text" class="form-control" name="next_of_kin" 
                                           value="<?= old('next_of_kin', $pensioner['next_of_kin'] ?? '') ?>">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Contact Number</label>
                                    <input type="tel" class="form-control" name="next_of_kin_contact" 
                                           value="<?= old('next_of_kin_contact', $pensioner['next_of_kin_contact'] ?? '') ?>">
                                </div>
                            </div>
                        </div>

                        <!-- Pension Information -->
                        <div class="mb-4">
                            <h6 class="fw-semibold mb-3 border-bottom pb-2">Pension Information</h6>
                            <div class="row g-3">
                                <div class="col-md-4">
                                    <label class="form-label">Pension Type *</label>
                                    <select class="form-select" name="pension_type" required>
                                        <option value="retirement" <?= isset($pensioner) && $pensioner['pension_type'] == 'retirement' ? 'selected' : '' ?>>Retirement</option>
                                        <option value="disability" <?= isset($pensioner) && $pensioner['pension_type'] == 'disability' ? 'selected' : '' ?>>Disability</option>
                                        <option value="survivor" <?= isset($pensioner) && $pensioner['pension_type'] == 'survivor' ? 'selected' : '' ?>>Survivor</option>
                                        <option value="other" <?= isset($pensioner) && $pensioner['pension_type'] == 'other' ? 'selected' : '' ?>>Other</option>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">Monthly Amount</label>
                                    <div class="input-group">
                                        <span class="input-group-text">₱</span>
                                        <input type="number" class="form-control" name="pension_amount" step="0.01" 
                                               value="<?= old('pension_amount', $pensioner['pension_amount'] ?? '') ?>">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">Start Date</label>
                                    <input type="date" class="form-control" name="pension_start_date" 
                                           value="<?= old('pension_start_date', $pensioner['pension_start_date'] ?? '') ?>">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Status</label>
                                    <select class="form-select" name="status">
                                        <option value="active" <?= isset($pensioner) && $pensioner['status'] == 'active' ? 'selected' : '' ?>>Active</option>
                                        <option value="suspended" <?= isset($pensioner) && $pensioner['status'] == 'suspended' ? 'selected' : '' ?>>Suspended</option>
                                        <option value="inactive" <?= isset($pensioner) && $pensioner['status'] == 'inactive' ? 'selected' : '' ?>>Inactive</option>
                                        <option value="deceased" <?= isset($pensioner) && $pensioner['status'] == 'deceased' ? 'selected' : '' ?>>Deceased</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <!-- Additional Information -->
                        <div class="mb-4">
                            <h6 class="fw-semibold mb-3 border-bottom pb-2">Additional Information</h6>
                            <div class="row g-3">
                                <div class="col-md-12">
                                    <label class="form-label">Medical Conditions</label>
                                    <textarea class="form-control" name="medical_conditions" rows="2"><?= old('medical_conditions', $pensioner['medical_conditions'] ?? '') ?></textarea>
                                </div>
                                <div class="col-md-12">
                                    <label class="form-label">Notes</label>
                                    <textarea class="form-control" name="notes" rows="3"><?= old('notes', $pensioner['notes'] ?? '') ?></textarea>
                                </div>
                            </div>
                        </div>

                        <!-- Submit Button -->
                        <div class="d-flex justify-content-end gap-2">
                            <a href="<?= site_url('/user/pensioners/view') ?>" class="btn btn-outline-secondary">
                                Cancel
                            </a>
                            <button type="submit" class="btn btn-primary">
                                <?= isset($pensioner) ? 'Update Pensioner' : 'Save Pensioner' ?>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Form validation
        const form = document.querySelector('form');
        if (form) {
            form.addEventListener('submit', function(e) {
                const requiredFields = form.querySelectorAll('[required]');
                let isValid = true;
                
                requiredFields.forEach(field => {
                    if (!field.value.trim()) {
                        isValid = false;
                        field.classList.add('is-invalid');
                    } else {
                        field.classList.remove('is-invalid');
                    }
                });
                
                if (!isValid) {
                    e.preventDefault();
                    alert('Please fill in all required fields marked with *');
                }
            });
        }
        
        // Date validation (cannot be future date)
        const dobInput = document.querySelector('input[name="date_of_birth"]');
        if (dobInput) {
            dobInput.max = new Date().toISOString().split('T')[0];
        }
        
        const startDateInput = document.querySelector('input[name="pension_start_date"]');
        if (startDateInput) {
            startDateInput.max = new Date().toISOString().split('T')[0];
        }
    });
</script>
<?= $this->endSection() ?>