<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Pensioner | Pensioner Association Management System</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Roboto+Slab:wght@400;500;600&display=swap" rel="stylesheet">

    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">

    <style>
        :root {
            --primary-blue: #2c3e50;
            --secondary-blue: #3498db;
            --accent-blue: #2980b9;
            --light-blue: #ecf0f1;
            --dark-blue: #1a252f;
            --success-green: #27ae60;
            --warning-orange: #f39c12;
            --danger-red: #e74c3c;
            --info-teal: #1abc9c;
            --text-dark: #2c3e50;
            --text-light: #7f8c8d;
            --border-color: #dfe6e9;
            --shadow-light: rgba(44, 62, 80, 0.1);
            --shadow-medium: rgba(44, 62, 80, 0.15);
        }

        body {
            background-color: #f8f9fa;
            font-family: 'Inter', sans-serif;
            color: var(--text-dark);
            min-height: 100vh;
            padding: 0;
            margin: 0;
            line-height: 1.6;
        }

        .container-fluid {
            padding: 0 15px;
        }

        @media (min-width: 768px) {
            .container-fluid {
                padding: 0 30px;
            }
        }

        .edit-card {
            background: white;
            border-radius: 12px;
            border: 1px solid var(--border-color);
            box-shadow: 0 4px 12px var(--shadow-light);
            padding: 0;
            margin: 2rem auto;
            overflow: hidden;
            animation: fadeIn 0.5s ease-out;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @media (max-width: 768px) {
            .edit-card {
                margin: 1rem auto;
                border-radius: 8px;
            }
        }

        .card-header {
            background: linear-gradient(135deg, var(--primary-blue), var(--accent-blue));
            padding: 1.5rem 2rem;
            border-bottom: 1px solid var(--border-color);
            position: relative;
            overflow: hidden;
        }

        .card-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(45deg, transparent 30%, rgba(255,255,255,0.1) 50%, transparent 70%);
            opacity: 0.3;
        }

        @media (max-width: 768px) {
            .card-header {
                padding: 1.25rem 1.5rem;
            }
        }

        .page-title {
            font-family: 'Roboto Slab', serif;
            color: white;
            font-size: 1.8rem;
            font-weight: 600;
            margin: 0;
            display: flex;
            align-items: center;
            gap: 10px;
            position: relative;
            z-index: 1;
        }

        @media (max-width: 768px) {
            .page-title {
                font-size: 1.5rem;
            }
        }

        @media (max-width: 576px) {
            .page-title {
                font-size: 1.3rem;
            }
        }

        .page-subtitle {
            color: rgba(255, 255, 255, 0.85);
            font-size: 0.95rem;
            margin-top: 0.25rem;
            font-weight: 400;
            position: relative;
            z-index: 1;
        }

        .card-body {
            padding: 2rem;
        }

        @media (max-width: 768px) {
            .card-body {
                padding: 1.5rem;
            }
        }

        @media (max-width: 576px) {
            .card-body {
                padding: 1.25rem;
            }
        }

        .alert-success {
            background: linear-gradient(135deg, var(--success-green), #229954);
            color: white;
            border: none;
            border-radius: 6px;
            padding: 1rem 1.25rem;
            font-weight: 500;
            box-shadow: 0 2px 8px rgba(39, 174, 96, 0.2);
            margin-bottom: 1.5rem;
            animation: slideIn 0.3s ease-out;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Form Card Styles */
        .form-card {
            background: white;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            transition: all 0.3s ease;
            box-shadow: 0 2px 4px var(--shadow-light);
        }

        .form-card:hover {
            box-shadow: 0 4px 8px var(--shadow-medium);
            transform: translateY(-2px);
        }

        @media (max-width: 576px) {
            .form-card {
                padding: 1.25rem;
                margin-bottom: 1rem;
            }
        }

        .form-title {
            font-family: 'Roboto Slab', serif;
            color: var(--primary-blue);
            font-size: 1.25rem;
            font-weight: 600;
            margin-bottom: 1.25rem;
            padding-bottom: 0.5rem;
            border-bottom: 2px solid var(--secondary-blue);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        @media (max-width: 576px) {
            .form-title {
                font-size: 1.1rem;
                margin-bottom: 1rem;
            }
        }

        .form-group {
            margin-bottom: 1.5rem;
            position: relative;
        }

        .form-group:last-child {
            margin-bottom: 0;
        }

        .form-label {
            font-weight: 600;
            color: var(--text-dark);
            font-size: 0.9rem;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .form-label i {
            color: var(--secondary-blue);
            font-size: 1.1rem;
        }

        .required-field::after {
            content: ' *';
            color: var(--danger-red);
        }

        .form-control, .form-select {
            border: 1px solid var(--border-color);
            border-radius: 6px;
            padding: 0.75rem 1rem;
            font-size: 0.95rem;
            transition: all 0.2s ease;
            background-color: white;
            width: 100%;
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--secondary-blue);
            box-shadow: 0 0 0 0.25rem rgba(52, 152, 219, 0.25);
            background-color: white;
            outline: none;
        }

        .form-control::placeholder {
            color: var(--text-light);
            opacity: 0.7;
        }

        textarea.form-control {
            min-height: 100px;
            resize: vertical;
        }

        /* Custom select styling */
        .form-select {
            appearance: none;
            -webkit-appearance: none;
            -moz-appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='%233498db' viewBox='0 0 16 16'%3E%3Cpath d='M7.247 11.14 2.451 5.658C1.885 5.013 2.345 4 3.204 4h9.592a1 1 0 0 1 .753 1.659l-4.796 5.48a1 1 0 0 1-1.506 0z'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 1rem center;
            background-size: 16px 12px;
            padding-right: 2.5rem;
            cursor: pointer;
        }

        .form-select:focus {
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='%232980b9' viewBox='0 0 16 16'%3E%3Cpath d='M7.247 11.14 2.451 5.658C1.885 5.013 2.345 4 3.204 4h9.592a1 1 0 0 1 .753 1.659l-4.796 5.48a1 1 0 0 1-1.506 0z'/%3E%3C/svg%3E");
        }

        /* Validation styles */
        .is-invalid {
            border-color: var(--danger-red) !important;
        }

        .is-invalid:focus {
            box-shadow: 0 0 0 0.25rem rgba(231, 76, 60, 0.25) !important;
        }

        .invalid-feedback {
            color: var(--danger-red);
            font-size: 0.85rem;
            margin-top: 0.25rem;
            display: block;
        }

        /* Badge styles for preview */
        .info-badge {
            display: inline-block;
            padding: 0.35rem 0.75rem;
            border-radius: 20px;
            font-weight: 500;
            font-size: 0.8rem;
            text-transform: uppercase;
            letter-spacing: 0.3px;
        }

        .badge-retirement {
            background: linear-gradient(135deg, var(--success-green), #229954);
            color: white;
        }

        .badge-disability {
            background: linear-gradient(135deg, var(--warning-orange), #e67e22);
            color: white;
        }

        .badge-survivor {
            background: linear-gradient(135deg, var(--info-teal), #16a085);
            color: white;
        }

        .badge-other {
            background: linear-gradient(135deg, #95a5a6, #7f8c8d);
            color: white;
        }

        /* Quick stats */
        .quick-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 1rem;
            margin-bottom: 2rem;
        }

        @media (max-width: 576px) {
            .quick-stats {
                grid-template-columns: 1fr;
                gap: 0.75rem;
                margin-bottom: 1.5rem;
            }
        }

        .stat-card {
            background: white;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            padding: 1.25rem;
            text-align: center;
            transition: all 0.3s ease;
            box-shadow: 0 2px 4px var(--shadow-light);
        }

        .stat-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px var(--shadow-medium);
        }

        .stat-icon {
            width: 40px;
            height: 40px;
            background: var(--light-blue);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 0.75rem;
            color: var(--secondary-blue);
            font-size: 1.25rem;
        }

        .stat-value {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--primary-blue);
            margin-bottom: 0.25rem;
        }

        .stat-label {
            font-size: 0.85rem;
            color: var(--text-light);
            font-weight: 500;
        }

        /* Action buttons */
        .action-buttons {
            display: flex;
            gap: 1rem;
            justify-content: center;
            flex-wrap: wrap;
            margin-top: 2rem;
            padding-top: 2rem;
            border-top: 1px solid var(--border-color);
        }

        @media (max-width: 576px) {
            .action-buttons {
                flex-direction: column;
                gap: 0.75rem;
                margin-top: 1.5rem;
                padding-top: 1.5rem;
            }
            
            .action-buttons .btn {
                width: 100%;
            }
        }

        .btn-update {
            background: var(--secondary-blue);
            border: none;
            border-radius: 6px;
            padding: 0.75rem 2rem;
            font-weight: 600;
            color: white;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
        }

        .btn-update:hover {
            background: var(--accent-blue);
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(52, 152, 219, 0.3);
            color: white;
        }

        .btn-cancel {
            background: white;
            border: 2px solid var(--border-color);
            border-radius: 6px;
            padding: 0.75rem 2rem;
            font-weight: 600;
            color: var(--text-dark);
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
            text-decoration: none;
        }

        .btn-cancel:hover {
            background: var(--light-blue);
            border-color: var(--secondary-blue);
            color: var(--accent-blue);
        }

        .btn-reset {
            background: var(--danger-red);
            border: none;
            border-radius: 6px;
            padding: 0.75rem 2rem;
            font-weight: 600;
            color: white;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
        }

        .btn-reset:hover {
            background: #c0392b;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(231, 76, 60, 0.3);
            color: white;
        }

        /* Loading state */
        .loading-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(255, 255, 255, 0.9);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            opacity: 0;
            pointer-events: none;
            transition: opacity 0.3s ease;
        }

        .loading-overlay.active {
            opacity: 1;
            pointer-events: all;
        }

        .spinner {
            width: 40px;
            height: 40px;
            border: 3px solid var(--light-blue);
            border-top-color: var(--secondary-blue);
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        /* Mobile-specific optimizations */
        @media (max-width: 576px) {
            body {
                padding: 0;
                background: white;
            }
            
            .container-fluid {
                padding: 0;
            }
            
            .edit-card {
                border-radius: 0;
                border: none;
                box-shadow: none;
                margin: 0;
                min-height: 100vh;
            }
            
            .card-header {
                border-radius: 0;
                padding: 1rem 1.25rem;
            }
            
            .card-body {
                padding: 1rem;
            }
            
            .form-group {
                margin-bottom: 1.25rem;
            }
            
            .form-control, .form-select {
                padding: 0.875rem 1rem;
                font-size: 16px; /* Prevents zoom on iOS */
            }
            
            .action-buttons {
                padding: 1.25rem 0 1rem 0;
                margin: 1.5rem 0 0 0;
                border-top: 1px solid var(--border-color);
            }
            
            /* Stack form columns on mobile */
            .row > [class*="col-"] {
                margin-bottom: 1rem;
            }
            
            .row > [class*="col-"]:last-child {
                margin-bottom: 0;
            }
        }

        /* Tablet optimizations */
        @media (min-width: 577px) and (max-width: 768px) {
            .edit-card {
                max-width: 95%;
            }
            
            .action-buttons {
                flex-direction: column;
                gap: 1rem;
            }
        }

        /* Desktop optimizations */
        @media (min-width: 769px) {
            .edit-card {
                max-width: 1200px; /* Increased for more fields */
            }
            
            .quick-stats {
                grid-template-columns: repeat(4, 1fr);
            }
        }

        /* Animation for content */
        .content-item {
            animation: fadeInUp 0.4s ease-out forwards;
            opacity: 0;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Staggered animation delay */
        .content-item:nth-child(1) { animation-delay: 0.1s; }
        .content-item:nth-child(2) { animation-delay: 0.2s; }
        .content-item:nth-child(3) { animation-delay: 0.3s; }
        .content-item:nth-child(4) { animation-delay: 0.4s; }
        .content-item:nth-child(5) { animation-delay: 0.5s; }

        /* Form hints */
        .form-hint {
            color: var(--text-light);
            font-size: 0.85rem;
            margin-top: 0.25rem;
            display: block;
        }

        /* Character counter */
        .char-counter {
            position: absolute;
            right: 0.75rem;
            bottom: 0.75rem;
            font-size: 0.8rem;
            color: var(--text-light);
            background: white;
            padding: 0 0.25rem;
        }

        .char-counter.warning {
            color: var(--warning-orange);
        }

        .char-counter.danger {
            color: var(--danger-red);
        }

        /* Status badge styling */
        .status-badge {
            display: inline-block;
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 500;
        }
        
        .status-active {
            background: rgba(39, 174, 96, 0.1);
            color: var(--success-green);
            border: 1px solid var(--success-green);
        }
        
        .status-suspended {
            background: rgba(243, 156, 18, 0.1);
            color: var(--warning-orange);
            border: 1px solid var(--warning-orange);
        }
        
        .status-deceased {
            background: rgba(231, 76, 60, 0.1);
            color: var(--danger-red);
            border: 1px solid var(--danger-red);
        }
        
        .status-inactive {
            background: rgba(149, 165, 166, 0.1);
            color: #95a5a6;
            border: 1px solid #95a5a6;
        }
    </style>
</head>
<body>
    <!-- Loading Overlay -->
    <div class="loading-overlay" id="loadingOverlay">
        <div class="spinner"></div>
    </div>
    
    <div class="container-fluid mt-3 mt-md-4">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="edit-card">
                    <div class="card-header">
                        <div>
                            <h1 class="page-title">
                                <i class="bi bi-person-gear"></i>
                                Edit Pensioner
                            </h1>
                            <p class="page-subtitle">Update pensioner information in the association database</p>
                        </div>
                    </div>

                    <div class="card-body">
                        <?php if(session()->getFlashdata('success')): ?>
                            <div class="alert alert-success">
                                <i class="bi bi-check-circle-fill"></i>
                                <?= session()->getFlashdata('success') ?>
                            </div>
                        <?php endif; ?>

                        <?php if(session()->getFlashdata('error')): ?>
                            <div class="alert alert-danger">
                                <i class="bi bi-exclamation-circle-fill"></i>
                                <?= session()->getFlashdata('error') ?>
                            </div>
                        <?php endif; ?>

                        <!-- Quick Stats -->
                        <div class="quick-stats">
                            <div class="stat-card content-item">
                                <div class="stat-icon">
                                    <i class="bi bi-person-badge"></i>
                                </div>
                                <div class="stat-value">#<?= $pensioner['pensioner_id'] ?></div>
                                <div class="stat-label">Pensioner ID</div>
                            </div>
                            
                            <div class="stat-card content-item">
                                <div class="stat-icon">
                                    <i class="bi bi-calendar-heart"></i>
                                </div>
                                <div class="stat-value">
                                    <?php 
                                        if(!empty($pensioner['date_of_birth'])) {
                                            echo date('d/m/Y', strtotime($pensioner['date_of_birth']));
                                        } else {
                                            echo 'N/A';
                                        }
                                    ?>
                                </div>
                                <div class="stat-label">Date of Birth</div>
                            </div>
                            
                            <div class="stat-card content-item">
                                <div class="stat-icon">
                                    <i class="bi bi-cash-coin"></i>
                                </div>
                                <div class="stat-value">
                                    ₱<?= number_format($pensioner['pension_amount'] ?? 0, 2) ?>
                                </div>
                                <div class="stat-label">Pension Amount</div>
                            </div>
                            
                            <div class="stat-card content-item">
                                <div class="stat-icon">
                                    <i class="bi bi-calendar-plus"></i>
                                </div>
                                <div class="stat-value">
                                    <?= date('d/m/Y', strtotime($pensioner['created_at'])) ?>
                                </div>
                                <div class="stat-label">Date Added</div>
                            </div>
                        </div>

                        <form action="<?= site_url('/admin/pensioners/update/'.$pensioner['pensioner_id']) ?>" method="POST" id="editPensionerForm">
                            <?= csrf_field() ?>

                            <!-- Personal Information -->
                            <div class="form-card content-item">
                                <h3 class="form-title">
                                    <i class="bi bi-person-vcard"></i>
                                    Personal Information
                                </h3>
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label required-field">
                                                <i class="bi bi-person-fill"></i>
                                                Full Name
                                            </label>
                                            <input type="text" name="full_name" class="form-control" 
                                                   value="<?= htmlspecialchars($pensioner['full_name'] ?? '') ?>" 
                                                   required
                                                   placeholder="Enter full name"
                                                   maxlength="100">
                                            <div class="invalid-feedback">Please enter the pensioner's full name.</div>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label">
                                                <i class="bi bi-calendar-date"></i>
                                                Date of Birth
                                            </label>
                                            <input type="date" name="date_of_birth" class="form-control" 
                                                   value="<?= $pensioner['date_of_birth'] ?? '' ?>"
                                                   max="<?= date('Y-m-d') ?>">
                                            <div class="form-hint">Format: YYYY-MM-DD</div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label required-field">
                                                <i class="bi bi-gender-ambiguous"></i>
                                                Gender
                                            </label>
                                            <select name="gender" class="form-select" required>
                                                <option value="">Select gender</option>
                                                <option value="male" <?= ($pensioner['gender'] ?? '') == 'male' ? 'selected' : '' ?>>Male</option>
                                                <option value="female" <?= ($pensioner['gender'] ?? '') == 'female' ? 'selected' : '' ?>>Female</option>
                                                <option value="other" <?= ($pensioner['gender'] ?? '') == 'other' ? 'selected' : '' ?>>Other</option>
                                            </select>
                                            <div class="invalid-feedback">Please select gender.</div>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label">
                                                <i class="bi bi-people-fill"></i>
                                                Marital Status
                                            </label>
                                            <select name="marital_status" class="form-select">
                                                <option value="">Select status</option>
                                                <option value="single" <?= ($pensioner['marital_status'] ?? '') == 'single' ? 'selected' : '' ?>>Single</option>
                                                <option value="married" <?= ($pensioner['marital_status'] ?? '') == 'married' ? 'selected' : '' ?>>Married</option>
                                                <option value="divorced" <?= ($pensioner['marital_status'] ?? '') == 'divorced' ? 'selected' : '' ?>>Divorced</option>
                                                <option value="widowed" <?= ($pensioner['marital_status'] ?? '') == 'widowed' ? 'selected' : '' ?>>Widowed</option>
                                            </select>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label">
                                                <i class="bi bi-card-text"></i>
                                                ID Number
                                            </label>
                                            <input type="text" name="id_number" class="form-control" 
                                                   value="<?= htmlspecialchars($pensioner['id_number'] ?? '') ?>"
                                                   placeholder="Enter ID number"
                                                   maxlength="50">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Contact Information -->
                            <div class="form-card content-item">
                                <h3 class="form-title">
                                    <i class="bi bi-telephone"></i>
                                    Contact Information
                                </h3>
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label">
                                                <i class="bi bi-phone-fill"></i>
                                                Contact Number
                                            </label>
                                            <input type="tel" name="contact_number" class="form-control" 
                                                   value="<?= $pensioner['contact_number'] ?? '' ?>"
                                                   placeholder="Enter contact number"
                                                   pattern="[0-9\s\-\+\(\)]{10,20}"
                                                   maxlength="20">
                                            <div class="form-hint">Format: +1 (555) 123-4567 or 5551234567</div>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label">
                                                <i class="bi bi-envelope-fill"></i>
                                                Email Address
                                            </label>
                                            <input type="email" name="email" class="form-control" 
                                                   value="<?= $pensioner['email'] ?? '' ?>"
                                                   placeholder="Enter email address"
                                                   maxlength="100">
                                            <div class="invalid-feedback">Please enter a valid email address.</div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <label class="form-label">
                                        <i class="bi bi-house-fill"></i>
                                        Address
                                    </label>
                                    <textarea name="address" class="form-control" rows="3" 
                                              placeholder="Enter complete address"
                                              maxlength="255"><?= htmlspecialchars($pensioner['address'] ?? '') ?></textarea>
                                    <div class="form-hint">Maximum 255 characters</div>
                                </div>
                            </div>

                            <!-- Bank Information -->
                            <div class="form-card content-item">
                                <h3 class="form-title">
                                    <i class="bi bi-bank"></i>
                                    Bank Information
                                </h3>
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label">
                                                <i class="bi bi-credit-card-fill"></i>
                                                Bank Account Number
                                            </label>
                                            <input type="text" name="bank_account" class="form-control" 
                                                   value="<?= htmlspecialchars($pensioner['bank_account'] ?? '') ?>"
                                                   placeholder="Enter bank account number"
                                                   maxlength="50">
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label">
                                                <i class="bi bi-building"></i>
                                                Bank Name
                                            </label>
                                            <input type="text" name="bank_name" class="form-control" 
                                                   value="<?= htmlspecialchars($pensioner['bank_name'] ?? '') ?>"
                                                   placeholder="Enter bank name"
                                                   maxlength="100">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Next of Kin Information -->
                            <div class="form-card content-item">
                                <h3 class="form-title">
                                    <i class="bi bi-people"></i>
                                    Next of Kin Information
                                </h3>
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label">
                                                <i class="bi bi-person-heart"></i>
                                                Next of Kin Name
                                            </label>
                                            <input type="text" name="next_of_kin" class="form-control" 
                                                   value="<?= htmlspecialchars($pensioner['next_of_kin'] ?? '') ?>"
                                                   placeholder="Enter next of kin name"
                                                   maxlength="100">
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label">
                                                <i class="bi bi-telephone-forward"></i>
                                                Next of Kin Contact
                                            </label>
                                            <input type="tel" name="next_of_kin_contact" class="form-control" 
                                                   value="<?= $pensioner['next_of_kin_contact'] ?? '' ?>"
                                                   placeholder="Enter contact number"
                                                   pattern="[0-9\s\-\+\(\)]{10,20}"
                                                   maxlength="20">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Pension Information -->
                            <div class="form-card content-item">
                                <h3 class="form-title">
                                    <i class="bi bi-piggy-bank"></i>
                                    Pension Information
                                </h3>
                                
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label required-field">
                                                <i class="bi bi-credit-card-fill"></i>
                                                Pension Type
                                            </label>
                                            <select name="pension_type" class="form-select" required>
                                                <option value="">Select pension type</option>
                                                <option value="retirement" <?= ($pensioner['pension_type'] ?? '') == 'retirement' ? 'selected' : '' ?>>Retirement Pension</option>
                                                <option value="disability" <?= ($pensioner['pension_type'] ?? '') == 'disability' ? 'selected' : '' ?>>Disability Pension</option>
                                                <option value="survivor" <?= ($pensioner['pension_type'] ?? '') == 'survivor' ? 'selected' : '' ?>>Survivor Pension</option>
                                                <option value="other" <?= ($pensioner['pension_type'] ?? '') == 'other' ? 'selected' : '' ?>>Other Pension Type</option>
                                            </select>
                                            <div class="invalid-feedback">Please select a pension type.</div>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label required-field">
                                                <i class="bi bi-cash-stack"></i>
                                                Pension Amount
                                            </label>
                                            <input type="number" name="pension_amount" class="form-control" 
                                                   value="<?= $pensioner['pension_amount'] ?? '0' ?>" 
                                                   step="0.01" 
                                                   min="0"
                                                   required
                                                   placeholder="0.00">
                                            <div class="form-hint">Enter amount in Philippine Peso (₱)</div>
                                            <div class="invalid-feedback">Please enter a valid pension amount.</div>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label">
                                                <i class="bi bi-calendar-check"></i>
                                                Pension Start Date
                                            </label>
                                            <input type="date" name="pension_start_date" class="form-control" 
                                                   value="<?= $pensioner['pension_start_date'] ?? '' ?>">
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label required-field">
                                                <i class="bi bi-clipboard-check"></i>
                                                Status
                                            </label>
                                            <select name="status" class="form-select" required>
                                                <option value="">Select status</option>
                                                <option value="active" <?= ($pensioner['status'] ?? '') == 'active' ? 'selected' : '' ?>>Active</option>
                                                <option value="suspended" <?= ($pensioner['status'] ?? '') == 'suspended' ? 'selected' : '' ?>>Suspended</option>
                                                <option value="deceased" <?= ($pensioner['status'] ?? '') == 'deceased' ? 'selected' : '' ?>>Deceased</option>
                                                <option value="inactive" <?= ($pensioner['status'] ?? '') == 'inactive' ? 'selected' : '' ?>>Inactive</option>
                                            </select>
                                            <div class="invalid-feedback">Please select status.</div>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label">
                                                <i class="bi bi-heart-pulse"></i>
                                                Medical Conditions
                                            </label>
                                            <textarea name="medical_conditions" class="form-control" rows="2"
                                                      placeholder="Enter any medical conditions"
                                                      maxlength="500"><?= htmlspecialchars($pensioner['medical_conditions'] ?? '') ?></textarea>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <label class="form-label">
                                        <i class="bi bi-sticky"></i>
                                        Notes
                                    </label>
                                    <textarea name="notes" class="form-control" rows="3"
                                              placeholder="Enter any additional notes or remarks"
                                              maxlength="1000"><?= htmlspecialchars($pensioner['notes'] ?? '') ?></textarea>
                                    <div class="form-hint">Maximum 1000 characters</div>
                                </div>
                                
                                <div class="row mt-3">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label">
                                                <i class="bi bi-calendar-plus"></i>
                                                Date Added
                                            </label>
                                            <input type="text" class="form-control" 
                                                   value="<?= date('F d, Y h:i A', strtotime($pensioner['created_at'])) ?>"
                                                   disabled
                                                   readonly>
                                        </div>
                                    </div>
                                    
                                    <?php if(isset($pensioner['updated_at']) && $pensioner['updated_at'] != $pensioner['created_at']): ?>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label">
                                                <i class="bi bi-calendar-check"></i>
                                                Last Updated
                                            </label>
                                            <input type="text" class="form-control" 
                                                   value="<?= date('F d, Y h:i A', strtotime($pensioner['updated_at'])) ?>"
                                                   disabled
                                                   readonly>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <!-- Action Buttons -->
                            <div class="action-buttons">
                                <?php $isAdmin = session()->get('is_admin') ?? false; ?>
                                <?php if($isAdmin): ?>
                                    <a href="<?= site_url('/admin/pensioners') ?>" class="btn-cancel">
                                <?php else: ?>
                                    <a href="<?= site_url('/user/pensioners') ?>" class="btn-cancel">
                                <?php endif; ?>
                                    <i class="bi bi-arrow-left"></i>
                                    Cancel
                                </a>
                                
                                <button type="reset" class="btn-reset">
                                    <i class="bi bi-x-circle"></i>
                                    Reset Form
                                </button>
                                
                                <button type="submit" class="btn-update">
                                    <i class="bi bi-save"></i>
                                    Update Pensioner
                                </button>
                            </div>
                            
                            <div class="mt-3 text-center">
                                <small class="text-muted">
                                    <i class="bi bi-info-circle me-1"></i>
                                    Fields marked with <span class="text-danger">*</span> are required
                                </small>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.getElementById('editPensionerForm');
            const loadingOverlay = document.getElementById('loadingOverlay');
            
            // Real-time form validation
            function validateField(field) {
                const value = field.value.trim();
                let isValid = true;
                let message = '';
                
                field.classList.remove('is-invalid');
                
                // Remove existing error message
                const existingError = field.nextElementSibling;
                if (existingError && existingError.classList.contains('invalid-feedback')) {
                    existingError.remove();
                }
                
                // Required field validation
                if (field.hasAttribute('required') && !value) {
                    isValid = false;
                    message = 'This field is required.';
                }
                
                // Email validation
                if (field.type === 'email' && value) {
                    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                    if (!emailRegex.test(value)) {
                        isValid = false;
                        message = 'Please enter a valid email address.';
                    }
                }
                
                // Phone validation
                if ((field.name === 'contact_number' || field.name === 'next_of_kin_contact') && value) {
                    const phoneRegex = /^[\d\s\-\+\(\)]{10,20}$/;
                    if (!phoneRegex.test(value)) {
                        isValid = false;
                        message = 'Please enter a valid phone number.';
                    }
                }
                
                // Date validation
                if (field.type === 'date' && value) {
                    const selectedDate = new Date(value);
                    const today = new Date();
                    if (selectedDate > today) {
                        isValid = false;
                        message = 'Date cannot be in the future.';
                    }
                }
                
                // Pension amount validation
                if (field.name === 'pension_amount' && value) {
                    const amount = parseFloat(value);
                    if (isNaN(amount) || amount < 0) {
                        isValid = false;
                        message = 'Please enter a valid positive amount.';
                    }
                }
                
                if (!isValid) {
                    field.classList.add('is-invalid');
                    const errorDiv = document.createElement('div');
                    errorDiv.className = 'invalid-feedback';
                    errorDiv.textContent = message;
                    field.parentNode.appendChild(errorDiv);
                }
                
                return isValid;
            }
            
            // Validate all fields on form submit
            form.addEventListener('submit', function(e) {
                e.preventDefault();
                
                let isValid = true;
                const fields = form.querySelectorAll('input, select, textarea');
                
                fields.forEach(field => {
                    if (!validateField(field)) {
                        isValid = false;
                    }
                });
                
                if (!isValid) {
                    // Scroll to first error
                    const firstError = form.querySelector('.is-invalid');
                    if (firstError) {
                        firstError.scrollIntoView({ 
                            behavior: 'smooth', 
                            block: 'center' 
                        });
                        firstError.focus();
                    }
                    return;
                }
                
                // Show loading overlay
                loadingOverlay.classList.add('active');
                
                // Submit form after validation
                setTimeout(() => {
                    form.submit();
                }, 500);
            });
            
            // Real-time validation on input
            form.addEventListener('input', function(e) {
                if (e.target.matches('input, select, textarea')) {
                    validateField(e.target);
                }
            });
            
            // Real-time validation on blur
            form.addEventListener('blur', function(e) {
                if (e.target.matches('input, select, textarea')) {
                    validateField(e.target);
                }
            }, true);
            
            // Reset form handler
            form.querySelector('button[type="reset"]').addEventListener('click', function(e) {
                e.preventDefault();
                
                if (confirm('Are you sure you want to reset all form fields to their original values?')) {
                    form.reset();
                    
                    // Clear all validation errors
                    form.querySelectorAll('.is-invalid').forEach(el => {
                        el.classList.remove('is-invalid');
                        const errorDiv = el.nextElementSibling;
                        if (errorDiv && errorDiv.classList.contains('invalid-feedback')) {
                            errorDiv.remove();
                        }
                    });
                    
                    // Show success message
                    const alert = document.createElement('div');
                    alert.className = 'alert alert-success mt-3';
                    alert.innerHTML = '<i class="bi bi-check-circle-fill me-2"></i>Form has been reset.';
                    
                    const firstFormCard = document.querySelector('.form-card');
                    if (firstFormCard) {
                        firstFormCard.parentNode.insertBefore(alert, firstFormCard);
                        
                        // Remove alert after 3 seconds
                        setTimeout(() => {
                            alert.remove();
                        }, 3000);
                    }
                }
            });
            
            // Character counter for textareas
            const textareas = form.querySelectorAll('textarea[maxlength]');
            textareas.forEach(textarea => {
                const maxLength = parseInt(textarea.getAttribute('maxlength'));
                const counter = document.createElement('span');
                counter.className = 'char-counter';
                counter.textContent = `${textarea.value.length}/${maxLength}`;
                
                textarea.parentNode.style.position = 'relative';
                textarea.parentNode.appendChild(counter);
                
                textarea.addEventListener('input', function() {
                    const currentLength = this.value.length;
                    counter.textContent = `${currentLength}/${maxLength}`;
                    
                    counter.classList.remove('warning', 'danger');
                    
                    if (currentLength > maxLength * 0.9) {
                        counter.classList.add('warning');
                    }
                    
                    if (currentLength > maxLength) {
                        counter.classList.add('danger');
                        this.value = this.value.substring(0, maxLength);
                        counter.textContent = `${maxLength}/${maxLength}`;
                    }
                });
            });
            
            // Auto-format phone numbers
            const phoneInputs = form.querySelectorAll('input[type="tel"]');
            phoneInputs.forEach(input => {
                input.addEventListener('input', function(e) {
                    let value = this.value.replace(/\D/g, '');
                    if (value.length > 10) {
                        value = value.slice(0, 10);
                    }
                    
                    if (value.length > 6) {
                        value = value.slice(0, 6) + '-' + value.slice(6);
                    }
                    if (value.length > 3) {
                        value = value.slice(0, 3) + '-' + value.slice(3);
                    }
                    
                    this.value = value;
                });
            });
            
            // Mobile-specific enhancements
            if (window.innerWidth < 576) {
                // Improve date input on mobile
                const dateInputs = form.querySelectorAll('input[type="date"]');
                dateInputs.forEach(dateInput => {
                    // Add today button
                    const todayButton = document.createElement('button');
                    todayButton.type = 'button';
                    todayButton.className = 'btn btn-sm btn-outline-secondary mt-2';
                    todayButton.innerHTML = '<i class="bi bi-calendar-check me-1"></i>Set to Today';
                    todayButton.addEventListener('click', function() {
                        const today = new Date().toISOString().split('T')[0];
                        dateInput.value = today;
                        validateField(dateInput);
                    });
                    
                    dateInput.parentNode.appendChild(todayButton);
                });
                
                // Improve form focus on mobile
                form.querySelectorAll('input, select, textarea').forEach(input => {
                    input.addEventListener('focus', function() {
                        setTimeout(() => {
                            this.scrollIntoView({ 
                                behavior: 'smooth', 
                                block: 'center' 
                            });
                        }, 300);
                    });
                });
            }
            
            // Show current status badge preview
            const statusSelect = form.querySelector('select[name="status"]');
            const statusPreview = document.createElement('div');
            statusPreview.className = 'mt-2';
            statusSelect.parentNode.appendChild(statusPreview);
            
            function updateStatusPreview() {
                const selectedValue = statusSelect.value;
                const selectedText = statusSelect.options[statusSelect.selectedIndex].text;
                
                if (selectedValue) {
                    let badgeClass = '';
                    switch(selectedValue) {
                        case 'active': badgeClass = 'status-active'; break;
                        case 'suspended': badgeClass = 'status-suspended'; break;
                        case 'deceased': badgeClass = 'status-deceased'; break;
                        case 'inactive': badgeClass = 'status-inactive'; break;
                    }
                    
                    statusPreview.innerHTML = `
                        <span class="status-badge ${badgeClass}">
                            <i class="bi bi-circle-fill me-1" style="font-size: 0.6rem;"></i>
                            ${selectedText}
                        </span>
                    `;
                } else {
                    statusPreview.innerHTML = '';
                }
            }
            
            updateStatusPreview(); // Initial call
            statusSelect.addEventListener('change', updateStatusPreview);
        });
    </script>
</body>
</html>
<?= $this->endSection() ?>