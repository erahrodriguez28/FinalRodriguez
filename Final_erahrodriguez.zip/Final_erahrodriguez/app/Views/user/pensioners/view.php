<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>

<div class="container-fluid px-3 px-md-4 py-4">
    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#registerPensionerModal">
            <i class="fas fa-plus-circle me-1"></i>Add New
        </button>
    </div>

    <!-- Stats Cards -->
    <div class="row g-3 mb-4">
        <div class="col-md-3 col-sm-6">
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-users"></i>
                </div>
                <div class="stat-number"><?= $stats['total'] ?? 0 ?></div>
                <div class="stat-label">Total Pensioners</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6">
            <div class="stat-card">
                <div class="stat-icon" style="background: rgba(16, 185, 129, 0.1); color: var(--success);">
                    <i class="fas fa-user-check"></i>
                </div>
                <div class="stat-number"><?= $stats['active'] ?? 0 ?></div>
                <div class="stat-label">Active</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6">
            <div class="stat-card">
                <div class="stat-icon" style="background: rgba(59, 130, 246, 0.1); color: var(--info);">
                    <i class="fas fa-calendar-alt"></i>
                </div>
                <div class="stat-number"><?= $stats['monthly_added'] ?? 0 ?></div>
                <div class="stat-label">This Month</div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6">
            <div class="stat-card">
                <div class="stat-icon" style="background: rgba(245, 158, 11, 0.1); color: var(--warning);">
                    <i class="fas fa-money-bill-wave"></i>
                </div>
                <div class="stat-number">₱<?= number_format($stats['total_amount'] ?? 0, 2) ?></div>
                <div class="stat-label">Total Amount</div>
            </div>
        </div>
    </div>

    <!-- Pensioners Table -->
    <div class="card border">
        <div class="card-body p-0">
            <?php if(!empty($pensioners)): ?>
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Date of Birth</th>
                                <th>Gender</th>
                                <th>Contact</th>
                                <th>Pension Type</th>
                                <th>Amount</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $model = new \App\Models\PensionerModel();
                            foreach($pensioners as $p): 
                                $status = $model->getStatusLabel($p['status']);
                                $pensionType = $model->getPensionTypeLabel($p['pension_type']);
                                $gender = $model->getGenderLabel($p['gender']);
                            ?>
                                <tr>
                                    <td>#<?= $p['pensioner_id'] ?></td>
                                    <td>
                                        <div class="fw-medium"><?= $p['full_name'] ?></div>
                                        <small class="text-muted">ID: <?= $p['id_number'] ?? 'N/A' ?></small>
                                    </td>
                                    <td>
                                        <?= $p['date_of_birth'] ? date('d M Y', strtotime($p['date_of_birth'])) : 'N/A' ?>
                                    </td>
                                    <td>
                                        <span class="badge bg-light text-dark"><?= $gender ?></span>
                                    </td>
                                    <td>
                                        <?= $p['contact_number'] ?? 'N/A' ?><br>
                                        <small class="text-muted"><?= $p['email'] ?? '' ?></small>
                                    </td>
                                    <td>
                                        <?php if($p['pension_type'] == 'retirement'): ?>
                                            <span class="badge bg-success-subtle text-success">
                                                <i class="fas fa-user-tie me-1"></i><?= $pensionType ?>
                                            </span>
                                        <?php elseif($p['pension_type'] == 'disability'): ?>
                                            <span class="badge bg-warning-subtle text-warning">
                                                <i class="fas fa-wheelchair me-1"></i><?= $pensionType ?>
                                            </span>
                                        <?php elseif($p['pension_type'] == 'survivor'): ?>
                                            <span class="badge bg-danger-subtle text-danger">
                                                <i class="fas fa-user-injured me-1"></i><?= $pensionType ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-info-subtle text-info">
                                                <i class="fas fa-user me-1"></i><?= $pensionType ?>
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="fw-medium">
                                        ₱<?= number_format($p['pension_amount'] ?? 0, 2) ?>
                                    </td>
                                    <td>
                                        <span class="badge <?= $status['class'] ?>">
                                            <?= $status['label'] ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <a href="<?= site_url('user/pensioners/edit/' . $p['pensioner_id']) ?>" 
                                               class="btn btn-outline-primary" title="Edit">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <?php if($p['status'] != 'deceased'): ?>
                                            <a href="<?= site_url('admin/pensioners/delete/' . $p['pensioner_id']) ?>" 
                                               class="btn btn-outline-danger" title="Delete"
                                               onclick="return confirm('Are you sure you want to delete this pensioner?')">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="text-center py-5">
                    <i class="fas fa-people-carry text-muted" style="font-size: 3rem;"></i>
                    <h5 class="fw-semibold mt-3">No Pensioners Found</h5>
                    <p class="text-muted mb-4">You haven't registered any pensioners yet.</p>
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#registerPensionerModal">
                        <i class="fas fa-plus-circle me-1"></i>Add Your First Pensioner
                    </button>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
/* Mobile Responsive Styles */
@media (max-width: 768px) {
    /* Adjust container padding for mobile */
    .container-fluid.px-3.px-md-4.py-4 {
        padding: 1rem !important;
    }
    
    /* Page header - stack vertically */
    .d-flex.justify-content-between.align-items-center.mb-4 {
        flex-direction: column;
        align-items: stretch !important;
        gap: 1rem;
        margin-bottom: 1.5rem !important;
    }
    
    .d-flex.justify-content-between.align-items-center.mb-4 > button {
        width: 100%;
        padding: 0.75rem 1rem !important;
        font-size: 1rem !important;
    }
    
    /* Stats cards - responsive grid */
    .row.g-3.mb-4 {
        margin-left: -0.5rem !important;
        margin-right: -0.5rem !important;
        margin-bottom: 1.5rem !important;
    }
    
    .row.g-3.mb-4 > .col-md-3.col-sm-6 {
        padding-left: 0.5rem !important;
        padding-right: 0.5rem !important;
        margin-bottom: 1rem !important;
    }
    
    /* 2 cards per row on tablets, 1 on phones */
    @media (min-width: 576px) and (max-width: 768px) {
        .row.g-3.mb-4 > .col-md-3.col-sm-6 {
            width: 50% !important;
            flex: 0 0 50% !important;
            max-width: 50% !important;
        }
    }
    
    @media (max-width: 575px) {
        .row.g-3.mb-4 > .col-md-3.col-sm-6 {
            width: 100% !important;
            flex: 0 0 100% !important;
            max-width: 100% !important;
        }
    }
    
    /* Adjust stat card styling for mobile */
    .stat-card {
        padding: 1rem !important;
        text-align: center;
    }
    
    .stat-icon {
        width: 50px !important;
        height: 50px !important;
        margin: 0 auto 0.75rem !important;
        font-size: 1.25rem !important;
    }
    
    .stat-number {
        font-size: 1.5rem !important;
        font-weight: 600 !important;
        margin-bottom: 0.25rem !important;
    }
    
    .stat-label {
        font-size: 0.875rem !important;
        color: #6c757d !important;
    }
    
    /* Table responsive styles */
    .card.border {
        border-radius: 0.5rem !important;
        overflow: hidden !important;
    }
    
    .table-responsive {
        margin: 0 -1rem !important;
        padding: 0 1rem !important;
        width: calc(100% + 2rem) !important;
        overflow-x: auto !important;
        -webkit-overflow-scrolling: touch !important;
    }
    
    .table.table-hover.mb-0 {
        min-width: 900px !important;
        font-size: 0.875rem !important;
        margin-bottom: 0 !important;
    }
    
    /* Compact table cells */
    .table.table-hover.mb-0 th,
    .table.table-hover.mb-0 td {
        padding: 0.75rem 0.5rem !important;
        vertical-align: middle !important;
    }
    
    /* Responsive table headers */
    .table.table-hover.mb-0 th {
        font-size: 0.8rem !important;
        font-weight: 600 !important;
        text-transform: uppercase !important;
        letter-spacing: 0.5px !important;
        white-space: nowrap !important;
    }
    
    /* Make badges more compact */
    .badge {
        font-size: 0.75rem !important;
        padding: 0.25em 0.6em !important;
        font-weight: 500 !important;
        display: inline-block !important;
    }
    
    /* Adjust name column */
    .table.table-hover.mb-0 td .fw-medium {
        font-size: 0.9rem !important;
        font-weight: 600 !important;
        margin-bottom: 0.125rem !important;
    }
    
    .table.table-hover.mb-0 td small.text-muted {
        font-size: 0.75rem !important;
    }
    
    /* Action buttons - make touch friendly */
    .btn-group.btn-group-sm {
        display: flex !important;
        flex-wrap: nowrap !important;
    }
    
    .btn-group.btn-group-sm .btn {
        padding: 0.4rem 0.6rem !important;
        font-size: 0.8rem !important;
        min-width: 36px !important;
        min-height: 36px !important;
        display: inline-flex !important;
        align-items: center !important;
        justify-content: center !important;
    }
    
    /* Empty state adjustments */
    .text-center.py-5 {
        padding: 2rem 1rem !important;
    }
    
    .text-center.py-5 i {
        font-size: 2.5rem !important;
        margin-bottom: 1rem !important;
    }
    
    .text-center.py-5 h5.fw-semibold {
        font-size: 1.25rem !important;
        margin-bottom: 0.5rem !important;
    }
    
    .text-center.py-5 p.text-muted {
        font-size: 0.95rem !important;
        margin-bottom: 1.5rem !important;
        padding: 0 0.5rem !important;
    }
    
    .text-center.py-5 .btn-primary {
        padding: 0.75rem 1.5rem !important;
        font-size: 1rem !important;
        width: 100% !important;
        max-width: 300px !important;
    }
    
    /* Touch-friendly tap targets */
    .btn,
    a.btn {
        min-height: 44px !important;
        min-width: 44px !important;
        display: inline-flex !important;
        align-items: center !important;
        justify-content: center !important;
    }
    
    /* Font size for mobile */
    body {
        font-size: 14px !important;
    }
}

/* Tablet adjustments (768px - 992px) */
@media (min-width: 769px) and (max-width: 992px) {
    .table.table-hover.mb-0 {
        font-size: 0.9rem !important;
    }
    
    .table.table-hover.mb-0 th,
    .table.table-hover.mb-0 td {
        padding: 0.75rem 0.5rem !important;
    }
    
    .stat-card {
        padding: 1.25rem !important;
    }
    
    .stat-number {
        font-size: 1.75rem !important;
    }
}

/* Small phones (under 400px) */
@media (max-width: 400px) {
    .container-fluid.px-3.px-md-4.py-4 {
        padding: 0.75rem !important;
    }
    
    .table-responsive {
        margin: 0 -0.75rem !important;
        padding: 0 0.75rem !important;
        width: calc(100% + 1.5rem) !important;
    }
    
    .table.table-hover.mb-0 {
        min-width: 800px !important;
        font-size: 0.85rem !important;
    }
    
    .btn-group.btn-group-sm .btn {
        padding: 0.35rem 0.5rem !important;
        font-size: 0.75rem !important;
        min-width: 32px !important;
        min-height: 32px !important;
    }
    
    .badge {
        font-size: 0.7rem !important;
        padding: 0.2em 0.5em !important;
    }
}

/* Ensure icons are properly sized */
.fas, .fa {
    font-size: inherit !important;
    line-height: inherit !important;
}

/* Fix for double containers */
.container-fluid > .container-fluid {
    padding: 0 !important;
}
</style>

<?= $this->endSection() ?>